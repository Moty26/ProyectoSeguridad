/*
 * Decompiled with CFR 0_119.
 */
public interface aalz {
    public void a();

    public void a(aamd var1);

    public void a(Throwable var1);

    public void cs_();
}

