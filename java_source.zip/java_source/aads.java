/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auib
 *  com.uber.model.core.analytics.generated.platform.analytics.CanaryExperimetationMetadataV2
 *  com.uber.model.core.analytics.generated.platform.analytics.CanaryExperimetationMetadataV2$Builder
 *  com.ubercab.experiment.model.ExperimentUpdate
 *  com.ubercab.experiment.model.TreatmentGroup
 *  ehv
 *  eoc
 *  fbz
 *  hig
 *  hih
 *  hpz
 *  hqb
 *  hqg
 */
import com.uber.model.core.analytics.generated.platform.analytics.CanaryExperimetationMetadataV2;
import com.ubercab.experiment.model.ExperimentUpdate;
import com.ubercab.experiment.model.TreatmentGroup;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class aads {
    private static final hig<aadt, hqg> a = new hih().a((Object)aadt.a, (Object)aadv.CANARY_WELCOME_SCREEN).a((Object)aadt.b, (Object)aadv.CANARY_WELCOME_PHONE_TAP).a((Object)aadt.c, (Object)aadv.CANARY_WELCOME_SOCIAL_TAP).a((Object)aadt.d, (Object)aadv.CANARY_MAP_VIEW).a((Object)aadt.e, (Object)aadv.CANARY_REQUEST_RIDE_TAP).a((Object)aadt.f, (Object)aadv.CANARY_ONBOARDING_SCREEN).a((Object)aadt.g, (Object)aadv.CANARY_ONBOARDING_SUCCESSFULL).a((Object)aadt.h, (Object)aadv.CANARY_ONBOARDING_PHONE_TAP).a((Object)aadt.i, (Object)aadv.CANARY_ONBOARDING_SOCIAL_TAP).a();
    private final hqg[] b = new hqg[]{aadv.CANARY_DEVICE_GPS_ASYNC, aadv.CANARY_DEVICE_MCC_ASYNC, aadv.CANARY_DEVICE_NOGEO_ASYNC, aadv.CANARY_USER_GPS_ASYNC, aadv.CANARY_USER_MCC_ASYNC, aadv.CANARY_USER_NOGEO_ASYNC};
    private final fbz c;
    private final hqb d;
    private final hpz e;
    private final ehv<Map<hqg, ExperimentUpdate>> f = ehv.a();
    private final Set<aadt> g = Collections.newSetFromMap(Collections.synchronizedMap(new HashMap()));

    public aads(fbz fbz2, hqb hqb2, hpz hpz2) {
        this.c = fbz2;
        this.d = hqb2;
        this.e = hpz2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private byte a(hqg hqg2, boolean bl) {
        Map map;
        byte by = -1;
        if (bl) {
            TreatmentGroup treatmentGroup = this.a(this.e.a(hqg2, "tag", "untreated"));
            map = treatmentGroup;
            if (treatmentGroup != aadu.c) {
                this.e.b(hqg2, treatmentGroup);
                map = treatmentGroup;
            }
        } else {
            map = (Map)this.f.b();
            byte by2 = by;
            if (map == null) return by2;
            hqg2 = (ExperimentUpdate)map.get((Object)hqg2);
            by2 = by;
            if (hqg2 == null) return by2;
            map = this.a(hqg2.getStringParameter("tag", "untreated"));
            if (map != aadu.c) {
                hqg2.sendDynamicInclusionEvent((TreatmentGroup)map);
            }
        }
        if (map == aadu.a) {
            return (byte)0;
        }
        if (map != aadu.b) return (byte)-1;
        return (byte)1;
    }

    private TreatmentGroup a(String string) {
        if (string == null) {
            return aadu.c;
        }
        if (string.equalsIgnoreCase("treatment")) {
            return aadu.b;
        }
        if (string.equalsIgnoreCase("control")) {
            return aadu.a;
        }
        return aadu.c;
    }

    public ayku a() {
        return this.d.a(this.b).a(new auib<Map<hqg, ExperimentUpdate>>(){

            public void a(Map<hqg, ExperimentUpdate> map) {
                super.onNext(map);
                aads.this.f.call(map);
            }

            public /* synthetic */ void onNext(Object object) {
                this.a((Map)object);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(aadt aadt2) {
        if (!this.g.add(aadt2)) {
            return;
        }
        CanaryExperimetationMetadataV2 canaryExperimetationMetadataV2 = CanaryExperimetationMetadataV2.builder().deviceGPSAsync(Byte.valueOf(this.a(aadv.CANARY_DEVICE_GPS_ASYNC, false))).deviceMCCAsync(Byte.valueOf(this.a(aadv.CANARY_DEVICE_MCC_ASYNC, false))).deviceNoGeoAsync(Byte.valueOf(this.a(aadv.CANARY_DEVICE_NOGEO_ASYNC, false))).userGPSAsync(Byte.valueOf(this.a(aadv.CANARY_USER_GPS_ASYNC, false))).userMCCAsync(Byte.valueOf(this.a(aadv.CANARY_USER_MCC_ASYNC, false))).userNoGeoAsync(Byte.valueOf(this.a(aadv.CANARY_USER_NOGEO_ASYNC, false))).deviceGPSSync(Byte.valueOf(this.a(aadv.CANARY_DEVICE_GPS_ASYNC, true))).deviceMCCSync(Byte.valueOf(this.a(aadv.CANARY_DEVICE_MCC_ASYNC, true))).deviceNoGeoSync(Byte.valueOf(this.a(aadv.CANARY_DEVICE_NOGEO_ASYNC, true))).userGPSSync(Byte.valueOf(this.a(aadv.CANARY_USER_GPS_ASYNC, true))).userMCCSync(Byte.valueOf(this.a(aadv.CANARY_USER_MCC_ASYNC, true))).userNoGeoSync(Byte.valueOf(this.a(aadv.CANARY_USER_NOGEO_ASYNC, true))).build();
        this.c.d(aadt2.a(), (eoc)canaryExperimetationMetadataV2);
        if ((aadt2 = (hqg)a.get((Object)aadt2)) == null) return;
        this.a((hqg)aadt2, true);
    }

}

