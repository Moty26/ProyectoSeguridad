/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.ui.core.UCardView
 *  exl
 *  llg
 *  llw
 */
import android.view.View;
import com.ubercab.ui.core.UCardView;

public class aaej<InnerView extends View, CardView extends UCardView>
extends exl<CardView> {
    private final InnerView a;
    private int b;

    public aaej(CardView CardView) {
        super(CardView);
        this.a = CardView.findViewById(aaef.a);
    }

    protected InnerView cF_() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKswILl1EyH4IGGnbMDJdFbTEaGYfDYAgz/QVl88TIxKtFqjS5sYPWkGR83/w0COAXA==", "enc::TdALMc9DJ1fvq6Iz+VuFTJnMY3CCWnbyBmv2f85Ltfwzj/f+dvjIUzCuViknYXHM", 2366547142336553411L, -8016678155487736001L, 3660060071688525446L, 1953763409102406465L, null, "enc::CMRbTA9e5dEIvh7g2NHtGX8eV25J6ZtU2NZOIPVBifg=", 31);
        }
        InnerView InnerView = this.a;
        if (llw2 != null) {
            llw2.i();
        }
        return InnerView;
    }

    public void c_(int n) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKswILl1EyH4IGGnbMDJdFbTEaGYfDYAgz/QVl88TIxKtFqjS5sYPWkGR83/w0COAXA==", "enc::6zPym8PAlabnL6Y+tudypNogPdMJs28gxSuxLmThFo8=", 2366547142336553411L, -8016678155487736001L, -6230448775847944856L, 1953763409102406465L, null, "enc::CMRbTA9e5dEIvh7g2NHtGX8eV25J6ZtU2NZOIPVBifg=", 46);
        }
        this.b = n;
        if (llw2 != null) {
            llw2.i();
        }
    }

    public int j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKswILl1EyH4IGGnbMDJdFbTEaGYfDYAgz/QVl88TIxKtFqjS5sYPWkGR83/w0COAXA==", "enc::W95qr1eSDAetj3RTwM+k9mKjAgko7VczkkFR4gzjKFY=", 2366547142336553411L, -8016678155487736001L, -4206112231261539462L, 1953763409102406465L, null, "enc::CMRbTA9e5dEIvh7g2NHtGX8eV25J6ZtU2NZOIPVBifg=", 39);
        }
        int n = this.b;
        if (llw2 != null) {
            llw2.i();
        }
        return n;
    }
}

