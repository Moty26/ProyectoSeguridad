/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awlq
 *  axss
 */
public final class aarz
implements awdv<aarx> {
    static final /* synthetic */ boolean a;
    private final axss<aaqd> b;
    private final axss<awlq> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarz.class.desiredAssertionStatus();
        a = bl;
    }

    public aarz(axss<aaqd> axss2, axss<awlq> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdv<aarx> a(axss<aaqd> axss2, axss<awlq> axss3) {
        return new aarz(axss2, axss3);
    }

    public aarx a() {
        return new aarx((aaqd)this.b.get(), (awlq)this.c.get());
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

