/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  awdr
 *  awdv
 *  awea
 *  axss
 *  ejv
 */
import android.view.LayoutInflater;

public final class aarw
implements awdv<aarv> {
    static final /* synthetic */ boolean a;
    private final awdr<aarv> b;
    private final axss<LayoutInflater> c;
    private final axss<aaqg> d;
    private final axss<ejv> e;
    private final axss<aavl> f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarw.class.desiredAssertionStatus();
        a = bl;
    }

    public aarw(awdr<aarv> awdr2, axss<LayoutInflater> axss2, axss<aaqg> axss3, axss<ejv> axss4, axss<aavl> axss5) {
        if (!a && awdr2 == null) {
            throw new AssertionError();
        }
        this.b = awdr2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.e = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.f = axss5;
    }

    public static awdv<aarv> a(awdr<aarv> awdr2, axss<LayoutInflater> axss2, axss<aaqg> axss3, axss<ejv> axss4, axss<aavl> axss5) {
        return new aarw(awdr2, axss2, axss3, axss4, axss5);
    }

    public aarv a() {
        return (aarv)((Object)awea.a(this.b, (Object)((Object)new aarv((LayoutInflater)this.c.get(), (aaqg)this.d.get(), (ejv)this.e.get(), (aavl)((Object)this.f.get())))));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

