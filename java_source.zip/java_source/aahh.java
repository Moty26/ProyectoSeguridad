/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 */
public final class aahh
implements awdv<aahl> {
    static final /* synthetic */ boolean a;
    private final aahe b;
    private final axss<aahv> c;
    private final axss<aagq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aahh.class.desiredAssertionStatus();
        a = bl;
    }

    public aahh(aahe aahe2, axss<aahv> axss2, axss<aagq> axss3) {
        if (!a && aahe2 == null) {
            throw new AssertionError();
        }
        this.b = aahe2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aahl> a(aahe aahe2, axss<aahv> axss2, axss<aagq> axss3) {
        return new aahh(aahe2, axss2, axss3);
    }

    public aahl a() {
        return (aahl)awec.a((Object)this.b.a((aahv)((Object)this.c.get()), (aagq)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

