/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aapm
implements axss<aaob> {
    private final aapr a;

    aapm(aapr aapr2) {
        this.a = aapr2;
    }

    public aaob a() {
        return (aaob)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

