/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  eyq
 */
public final class aahi
implements awdv<aahn> {
    static final /* synthetic */ boolean a;
    private final aahe b;
    private final axss<aahd> c;
    private final axss<eyq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aahi.class.desiredAssertionStatus();
        a = bl;
    }

    public aahi(aahe aahe2, axss<aahd> axss2, axss<eyq> axss3) {
        if (!a && aahe2 == null) {
            throw new AssertionError();
        }
        this.b = aahe2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aahn> a(aahe aahe2, axss<aahd> axss2, axss<eyq> axss3) {
        return new aahi(aahe2, axss2, axss3);
    }

    public aahn a() {
        return (aahn)((Object)awec.a((Object)((Object)this.b.a((aahd)this.c.get(), (eyq)this.d.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

