/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView
 *  ewj
 *  ewl
 *  eww
 *  ewz
 *  exm
 *  eyq
 *  ezc
 *  llg
 *  llw
 */
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView;

public class aaij
extends exm<CobrandCardFinancialInfoView, aaif, aahz> {
    private final eyq a;
    private final aajs b;

    public aaij(CobrandCardFinancialInfoView cobrandCardFinancialInfoView, aaif aaif2, aahz aahz2, eyq eyq2, aajs aajs2) {
        super((View)cobrandCardFinancialInfoView, (ewj)aaif2, (ewl)aahz2);
        this.a = eyq2;
        this.b = aajs2;
    }

    public void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqGjDOyiZT50y39gUtCaEu5mN6aJnz9QbVL4tl7AtGWRi", "enc::MW1qpwovHmeQo3067P3+5lc0PUnPWwDzd8Vuy8gcISQ=", -3295476322921135584L, -3201302779072840353L, -2859438141256472459L, 4285526870058266813L, null, "enc::atEfgvPYLktmgAD18YGYTQqwwj6f6zGVAPI41l1qqgLnAdM8UuXYNyyz2iMWeFnP", 33);
        }
        this.a.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqGjDOyiZT50y39gUtCaEu5mN6aJnz9QbVL4tl7AtGWRi", "enc::bXC8/OVj0F68NSBpBy+718qwk43WwQXfBbusbFbEcDE=", -3295476322921135584L, -3201302779072840353L, 3988689529125049728L, 4285526870058266813L, null, "enc::atEfgvPYLktmgAD18YGYTQqwwj6f6zGVAPI41l1qqgLnAdM8UuXYNyyz2iMWeFnP", 37);
        }
        this.a.a((ezc)new eww((ewz)this){

            public exm a(ViewGroup viewGroup) {
                return aaij.this.b.b(viewGroup);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

}

