/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aage
implements awdv<aagq> {
    static final /* synthetic */ boolean a;
    private final aagc b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aage.class.desiredAssertionStatus();
        a = bl;
    }

    public aage(aagc aagc2) {
        if (!a && aagc2 == null) {
            throw new AssertionError();
        }
        this.b = aagc2;
    }

    public static awdv<aagq> a(aagc aagc2) {
        return new aage(aagc2);
    }

    public aagq a() {
        return (aagq)awec.a((Object)this.b.b(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

