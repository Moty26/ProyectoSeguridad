/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apaq
 *  awdr
 *  axss
 *  ewj
 *  ewo
 */
public final class aajc
implements awdr<aajb> {
    static final /* synthetic */ boolean a;
    private final axss<aajd> b;
    private final axss<aagq> c;
    private final axss<apaq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aajc.class.desiredAssertionStatus();
        a = bl;
    }

    public aajc(axss<aajd> axss2, axss<aagq> axss3, axss<apaq> axss4) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
    }

    public static awdr<aajb> a(axss<aajd> axss2, axss<aagq> axss3, axss<apaq> axss4) {
        return new aajc(axss2, axss3, axss4);
    }

    public void a(aajb aajb2) {
        if (aajb2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aajb2, this.b);
        aajb2.a = (aajd)this.b.get();
        aajb2.b = (aagq)this.c.get();
        aajb2.c = (apaq)this.d.get();
    }
}

