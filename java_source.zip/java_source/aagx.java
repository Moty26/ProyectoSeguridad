/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  ewc
 */
class aagx
implements axss<ewc> {
    private final aagd a;

    aagx(aagd aagd2) {
        this.a = aagd2;
    }

    public ewc a() {
        return (ewc)awec.a((Object)this.a.d(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

