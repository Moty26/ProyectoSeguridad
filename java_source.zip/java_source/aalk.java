/*
 * Decompiled with CFR 0_119.
 */
public enum aalk {
    a,
    b,
    c,
    d,
    e,
    f,
    g,
    h,
    i,
    j,
    k,
    l,
    m,
    n,
    o,
    p,
    q,
    r,
    s;
    

    private aalk() {
    }
}

