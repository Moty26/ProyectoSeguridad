/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afg
 *  agi
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  ejv
 *  hie
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.Collection;

public class aart
extends afg<aata> {
    private static final int b = aaqr.ub__contact_picker_contact_row;
    private static final int c = aaqr.ub__contact_picker_header_row;
    protected final LayoutInflater a;
    private final aaqg d;
    private final ejv e;
    private final int f;
    private final int g;
    private hie<aatb> h = hie.c();

    public aart(LayoutInflater layoutInflater, aaqg aaqg2, ejv ejv2) {
        this(layoutInflater, aaqg2, ejv2, c, b);
    }

    public aart(LayoutInflater layoutInflater, aaqg aaqg2, ejv ejv2, int n, int n2) {
        this.a = layoutInflater;
        this.d = aaqg2;
        this.e = ejv2;
        this.g = n;
        this.f = n2;
    }

    private aasc a(ViewGroup viewGroup) {
        return new aasc(this.d, this.e, this.a.inflate(this.f, viewGroup, false));
    }

    private aask b(ViewGroup viewGroup) {
        return new aask((TextView)this.a.inflate(this.g, viewGroup, false));
    }

    private aasr c(ViewGroup viewGroup) {
        return new aasr(this.a.inflate(this.f, viewGroup, false));
    }

    public int a() {
        return this.h.size();
    }

    public aata a(ViewGroup viewGroup, int n) {
        switch (n) {
            default: {
                throw new IllegalArgumentException("Unrecognized view type: " + n);
            }
            case 0: {
                return this.a(viewGroup);
            }
            case 1: {
                return this.b(viewGroup);
            }
            case 3: 
        }
        return this.c(viewGroup);
    }

    public void a(aata aata2, int n) {
        aata2.a((aatb)this.h.get(n));
    }

    public void a(Collection<aatb> collection) {
        this.h = hie.a(collection);
        this.e();
    }

    public int b(int n) {
        return ((aatb)this.h.get((int)n)).g;
    }

    public /* synthetic */ agi b(ViewGroup viewGroup, int n) {
        return this.a(viewGroup, n);
    }
}

