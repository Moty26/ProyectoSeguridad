/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  ewc
 */
class aaio
implements axss<ewc> {
    private final aaib a;

    aaio(aaib aaib2) {
        this.a = aaib2;
    }

    public ewc a() {
        return (ewc)awec.a((Object)this.a.i(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

