/*
 * Decompiled with CFR 0_119.
 */
interface aahm {
    public void a(String var1, String var2, String var3, String var4, String var5);

    public void d();
}

