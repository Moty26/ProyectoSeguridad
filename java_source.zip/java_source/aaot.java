/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.model.core.generated.rtapi.services.marketplacerider.Contact
 */
import com.uber.model.core.generated.rtapi.services.marketplacerider.Contact;

public interface aaot {
    public void a(String var1, Contact var2);

    public void d();
}

