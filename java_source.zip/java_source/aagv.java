/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  apaq
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  esc
 *  ewc
 *  ewj
 *  ewq
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;

public final class aagv
implements aagb {
    static final /* synthetic */ boolean a;
    private axss<aagn> b;
    private axss<esc<apap>> c;
    private axss<CobrandCardDataTransactions<apap>> d;
    private axss<CobrandCardClient<apap>> e;
    private axss<Boolean> f;
    private awdr<aagl> g;
    private axss<aagb> h;
    private axss<eyq> i;
    private axss<aagp> j;
    private axss<apaq> k;
    private axss<aagq> l;
    private axss<OfferResponse> m;
    private axss<ewc> n;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aagv.class.desiredAssertionStatus();
        a = bl;
    }

    private aagv(aagw aagw2) {
        if (!a && aagw2 == null) {
            throw new AssertionError();
        }
        this.a(aagw2);
    }

    private void a(aagw aagw2) {
        this.b = awdu.a(aagj.a(aagw.a(aagw2)));
        this.c = new aagy(aagw.b(aagw2));
        this.d = awdu.a(aagg.b());
        this.e = awdu.a(aagf.a(aagw.a(aagw2), this.c, this.d));
        this.f = awdu.a(aagh.a(aagw.a(aagw2)));
        this.g = aagm.a(this.b, this.e, this.f);
        this.h = awdw.a((Object)this);
        this.i = new aaha(aagw.b(aagw2));
        this.j = awdu.a(aagk.a(aagw.a(aagw2), this.h, this.i));
        this.k = new aagz(aagw.b(aagw2));
        this.l = awdu.a(aage.a(aagw.a(aagw2)));
        this.m = awdu.a(aagi.a(aagw.a(aagw2)));
        this.n = new aagx(aagw.b(aagw2));
    }

    public static aagw b() {
        return new aagw(null);
    }

    public /* synthetic */ ewq O_() {
        return this.d();
    }

    @Override
    public aagp a() {
        return (aagp)((Object)this.j.get());
    }

    public void a(aagl aagl2) {
        this.g.a((Object)aagl2);
    }

    public aagn d() {
        return (aagn)this.b.get();
    }

    @Override
    public apaq e() {
        return (apaq)this.k.get();
    }

    @Override
    public aagq f() {
        return (aagq)this.l.get();
    }

    @Override
    public eyq g() {
        return (eyq)this.i.get();
    }

    @Override
    public OfferResponse h() {
        return (OfferResponse)this.m.get();
    }

    @Override
    public ewc i() {
        return (ewc)this.n.get();
    }

}

