/*
 * Decompiled with CFR 0_119.
 */
interface aanj {
    public aanv b();
}

