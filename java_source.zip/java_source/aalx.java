/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.ViewGroup
 *  auhz
 *  auig
 *  auii
 *  avwt
 *  avwu
 *  awlc
 *  awle
 *  awlg
 *  awlj
 *  awln
 *  awlq
 *  awlv
 *  awlx
 *  awmh
 *  awmo
 *  awnf
 *  awnk
 *  axre
 *  axrg
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.core.support.v7.app.CoreAppCompatActivity
 *  eop
 *  eoq
 *  eos
 *  epb
 *  epd
 *  ewe
 *  ewf
 *  ewj
 *  ewz
 *  hhy
 *  hlc
 *  hlk
 *  llg
 *  llw
 *  lms
 */
import android.content.Context;
import android.view.ViewGroup;
import com.uber.rib.core.RibActivity;
import com.ubercab.core.support.v7.app.CoreAppCompatActivity;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class aalx
extends ewj<ewf, aame>
implements aans {
    aalu a;
    aamb b;
    ViewGroup c;
    aalz d;
    RibActivity e;
    lms f;
    aalj g;
    private awmo i;
    private awmo j;
    private awmo k;
    private aamf l = new aamf(false, false, false);

    static /* synthetic */ void a(aalx aalx2, aanh aanh2) {
        aalx2.c(aanh2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(aanh aanh2, hhy<Boolean> hhy2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::pZ+dagik7Jwaphn/V6LsTad+5dElHQKMOJddyZqNAEaT/jxZkk+S8raiDWO3L1L0KS8oVSjoYu1qE7dFJCyt8aUgaDJO3DhZ1mevA9vPNRmIUSrB5BPZgLXz6/fs5Whqgk/Ylz6dtj2DWoOWHjqpJOwJMwXqS48jlK1De1isYmw=", 2512309377846186838L, 2113803341035351170L, -5770468242710383772L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 275) : null;
        final aamd aamd2 = this.b(aanh2, hhy2);
        auii.a((awmo)this.k);
        this.k = (awmo)((epd)this.b.b(this.a, this.b(aanh2, hhy2)).a(awmh.a()).j((awnk)new epb((eop)this))).b((awlx)new axrg<auhz>(){

            public void a(auhz auhz2) {
                aalx.this.d.a(aamd2);
            }

            public /* synthetic */ void a_(Object object) {
                this.a((auhz)object);
            }

            public void onError(Throwable throwable) {
                kly.a("consent_interactor").b("onConsentPrimerAction", throwable);
                aalx.this.d.a(aamd2);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(aanp aanp2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::/6zAkfn8D+ujQt7cpSQ0Jz/wRmiTcMGCOkQ6ccDiL24aCDftmF2D40FfEwRgiSsyQtO5d4o6wPVyYo2bsQSGo7Jlof+5gke/RcBkicJwCrQ=", 2512309377846186838L, 2113803341035351170L, 5020600983653832936L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 226) : null;
        String string = this.g.a();
        if ((aanp2 = aanp2.x().a(string).a(this.g.b(this.a, this.l)).b(string).b(this.g.c(this.a, this.l)).c(string).c(this.g.d(this.a, this.l)).d(string).d(this.g.e(this.a, this.l)).e(string).e(this.g.f(this.a, this.l)).a()).a() == aanw.b) {
            ((aame)this.h()).a(aanp2);
        } else {
            ((aame)this.h()).b(aanp2);
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private aamd b(aanh object, hhy<Boolean> hhy2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::ETfxwB/pzR9eyPJX1kRR0I62+2KELridyQTzK15wecSkJDG9eZb4HJXkjHB7tIZKA/9So0PEV708rfnCoCDlC/LvjiAPrLH5MgVPifS2iy495PFUgaElVrU+WHWA7I5N66PO+dpEIrDDWwfiO3K84bMc7w4yR7qhxuzclU1cdhoaq4Ee0bDkssRV245JPxD+a2lsbSsU30dq2QF/gn6B1A==", 2512309377846186838L, 2113803341035351170L, -765732021891710955L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 388) : null;
        boolean bl = this.f();
        boolean bl2 = this.m() && this.a.c() != null;
        boolean bl3 = this.l.a() || (bl || this.a.j()) && object == aanh.a;
        boolean bl4 = !bl3 && bl && object == aanh.b;
        boolean bl5 = bl2 && object == aanh.a;
        object = new aamd((aanh)((Object)object), bl, bl2, new aamf(bl3, bl4, bl5), hhy2);
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    private aanp b(aanp aanp2) {
        aanq aanq2;
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::cnMcbKVWmS3LeWSd0+9NX5yoanWYlT1RBkyEklgHMLrWgAQOMzM/Yj8nsIKfLibj0JWBYiE0b9+AnCpH1H+kDSQFr8OZdMOP+b79abDA//+3Hlfv+pbiUYBtD9Z357H/D7KPbB/u2Uemsk1P6ZVbM1aZjSiEU18BbdsKuHouOTA=", 2512309377846186838L, 2113803341035351170L, -1624814726433221247L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 266);
        }
        aanq aanq3 = aanq2 = aanp2.x();
        if (aanp2.f() > 0) {
            aanq3 = aanq2;
            if (this.e()) {
                aanq3 = aanq2.c(aanp2.f());
            }
        }
        aanp2 = aanq3.a();
        if (llw2 != null) {
            llw2.i();
        }
        return aanp2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(final aanh aanh2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::rxoIPvLBclobwe/IiCVfzjpKJkcvOEh9ZY5VCBjVl36Jkqkp27LA/MtDIW5iZ9kF4LaH1c3PEyAKP1HNzmVd4Jczni9qLMHpupIIIE9v/nPuu7hXHdm7z5kOxXmO1HQK", 2512309377846186838L, 2113803341035351170L, 199479794663876282L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 298) : null;
        auii.a((awmo)this.i);
        this.i = (awmo)((eos)this.f.b(this.a.a(), (CoreAppCompatActivity)this.e, 2322, this.a.l()).f((awnk)new awnk<Map<String, hlc>, Boolean>(){

            public Boolean a(Map<String, hlc> object) throws Exception {
                object = object.entrySet().iterator();
                boolean bl = true;
                while (object.hasNext()) {
                    if (((hlc)((Map.Entry)object.next()).getValue()).a()) continue;
                    bl = false;
                }
                return bl;
            }
        }).a(awmh.a()).g((awnk)new eoq((eop)this))).b((awle)new axre<Boolean>(){

            /*
             * Enabled aggressive block sorting
             */
            public void a(Boolean bl) {
                aalx aalx2 = aalx.this;
                aanh aanh22 = aanh2;
                bl = bl != false ? hhy.b((Object)true) : hhy.e();
                aalx2.a(aanh22, (hhy)bl);
            }

            public /* synthetic */ void a_(Object object) {
                this.a((Boolean)object);
            }

            public void onComplete() {
            }

            public void onError(Throwable throwable) {
                aalx.this.d.a(throwable);
                kly.a("consent_interactor").b("Could not request app settings", throwable);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void c(final aanh aanh2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::trTLq0kwTMBxtUSRrYpJ5vOiQqvT5Uy33uzWg2t2duADGxYj3xLLCgQZdC1dukmsWxNgc9GIoDJg+NJhCZxaFc2G0PujQmc9W09+LGumNL9HPj2tNJPAxM6hsCR+BGKa", 2512309377846186838L, 2113803341035351170L, 2088675497382685350L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 341) : null;
        final avwt avwt2 = avwt.a((Context)this.c.getContext()).a(this.a.e()).b(false).b(this.a.f()).d(this.a.g()).c(this.a.h()).a();
        ((eos)avwt2.f().mergeWith((awln)avwt2.d()).map((awnk)new awnk<auhz, aaly>(){

            public aaly a(auhz auhz2) throws Exception {
                return aaly.b;
            }
        }).mergeWith((awln)avwt2.c().map((awnk)new awnk<auhz, aaly>(){

            public aaly a(auhz auhz2) throws Exception {
                return aaly.a;
            }
        })).firstElement().a(awmh.a()).g((awnk)new eoq((eop)this))).a((awle)new auig<aaly>(){

            public void a(aaly aaly2) throws Exception {
                avwt2.b();
                switch (aaly2) {
                    default: {
                        aalx.this.d.a(aalx.this.b(aanh2, hhy.e()));
                        return;
                    }
                    case a: 
                }
                aalx.this.b(aanh2);
            }

            public /* synthetic */ void b(Object object) throws Exception {
                this.a((aaly)((Object)object));
            }
        });
        avwt2.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

    private aamd d(aanh object) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::ETfxwB/pzR9eyPJX1kRR0I62+2KELridyQTzK15wecSkJDG9eZb4HJXkjHB7tIZKA/9So0PEV708rfnCoCDlC3nQ6/5cPpGc2csZRbgPwrNzGOvTefYY6AbKjjw1D1Zx9zzeeF1m1EwSrJqj8in8c7bT+oZRSGFxGvUmVPMJUVU=", 2512309377846186838L, 2113803341035351170L, -5215613171324831457L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 384);
        }
        object = this.b((aanh)((Object)object), hhy.e());
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    private void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::BjWypSyQzp7wEeIOVKMvov7VwzhMoryZsK9uNugnc+g=", 2512309377846186838L, 2113803341035351170L, -5039234531978195159L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 251);
        }
        this.d.cs_();
        ((aame)this.h()).h();
        ((aame)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean e() {
        boolean bl;
        llw llw2;
        block4 : {
            llw2 = null;
            bl = false;
            if (llg.b()) {
                llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::JyQUPB7getK5uttHuO5Qq2eB4KTJfCTXTWDD62mKhmU=", 2512309377846186838L, 2113803341035351170L, 7849758076374221807L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 257);
            }
            for (String string : this.a.l()) {
                if (this.f.a((Context)this.e, string)) {
                    continue;
                }
                break block4;
            }
            bl = true;
        }
        if (llw2 != null) {
            llw2.i();
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::avsQ84TXCPWO24rvr9Y4d4dBPAzsxYNTI4i9jo/+reg=", 2512309377846186838L, 2113803341035351170L, -4114634583524894341L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 406);
        }
        boolean bl = !this.a.j() && !this.l.a() && (!this.l.b() || this.a.i());
        if (llw2 != null) {
            llw2.i();
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::HG8YmadoqYYrlIYkcnMK9e0Owb+WfiZ0lS90ORCpTvYOMM9kkgswwmwW7VHMFYSp", 2512309377846186838L, 2113803341035351170L, -103836936452518670L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 411);
        }
        boolean bl = !this.f() && !this.l.c();
        if (llw2 != null) {
            llw2.i();
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(final aanh aanh2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::hYGEAJR62qsCjJUL7yRcaAnsunVDgXKX5bByrIPu3ws5/Ek/82BKqNgir9+AvIk7BexhA4Lfe0pMQ/b7dB0eGg2/HWhQNBcC/c1Kgy6GlEw=", 2512309377846186838L, 2113803341035351170L, -2580910855217343783L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 121) : null;
        auii.a((awmo)this.j);
        switch (aanh2) {
            default: {
                this.j = (awmo)((epd)this.b.a(this.a, this.d(aanh2)).a(awmh.a()).j((awnk)new epb((eop)this))).b((awlx)new axrg<auhz>(){

                    /*
                     * Enabled aggressive block sorting
                     */
                    public void a(auhz auhz2) {
                        aalx.this.d();
                        aalz aalz2 = aalx.this.d;
                        aalx aalx2 = aalx.this;
                        aanh aanh22 = aanh2;
                        auhz2 = aalx.this.e() ? hhy.b((Object)true) : hhy.e();
                        aalz2.a(aalx2.b(aanh22, (hhy)auhz2));
                    }

                    public /* synthetic */ void a_(Object object) {
                        this.a((auhz)object);
                    }

                    public void onError(Throwable throwable) {
                        aalx.this.d();
                        aalx.this.d.a(throwable);
                        kly.a("consent_interactor").b("onConsentPrimerAction", throwable);
                    }
                });
                break;
            }
            case a: {
                this.j = (awmo)((eos)awlc.a((awlg)this.b.a(this.a, this.d(aanh2)).e(), (awlg)this.f.a(this.a.a(), (CoreAppCompatActivity)this.e, 121, this.a.l()), (awnf)new awnf<auhz, Map<String, hlk>, Map<String, hlk>>(){

                    public Map<String, hlk> a(auhz auhz2, Map<String, hlk> map) throws Exception {
                        return map;
                    }
                }).a(awmh.a()).g((awnk)new eoq((eop)this))).b((awle)new axre<Map<String, hlk>>(){

                    /*
                     * Enabled force condition propagation
                     * Lifted jumps to return sites
                     */
                    public void a(Map<String, hlk> object) {
                        aalx.this.d();
                        LinkedList linkedList = new LinkedList();
                        LinkedList<Object> linkedList2 = new LinkedList<Object>();
                        object = object.entrySet().iterator();
                        boolean bl = true;
                        while (object.hasNext()) {
                            Map.Entry entry = (Map.Entry)object.next();
                            String string = (String)entry.getKey();
                            if ((entry = (hlk)entry.getValue()).a()) continue;
                            if (!entry.e()) {
                                linkedList.add(string);
                            }
                            if (!entry.b()) {
                                linkedList2.add(string);
                            }
                            bl = false;
                        }
                        aalx.this.a(aanh2, hhy.b((Object)true));
                    }

                    public /* synthetic */ void a_(Object object) {
                        this.a((Map)object);
                    }

                    public void onComplete() {
                    }

                    public void onError(Throwable throwable) {
                        aalx.this.d();
                        aalx.this.d.a(throwable);
                        kly.a("consent_interactor").b("onConsentPrimerAction/permissionRequest", throwable);
                    }
                });
            }
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ewe ewe2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", 2512309377846186838L, 2113803341035351170L, -8133349418566419115L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 74) : null;
        super.a(ewe2);
        this.d.a();
        ((epd)this.b.a(this.a).a(awmh.a()).j((awnk)new epb((eop)this))).b((awlx)new axrg<aamf>(){

            /*
             * Enabled aggressive block sorting
             */
            public void a(aamf aamf2) {
                aalx.this.l = aamf2;
                if (aalx.this.f()) {
                    aalx.this.g.b(aalx.this.a);
                    aalx.this.a(aalx.this.b(aalx.this.a.b()));
                } else if (aalx.this.m() && aalx.this.a.c() != null) {
                    aalx.this.g.c(aalx.this.a);
                    aalx.this.a(aalx.this.b(aalx.this.a.c()));
                } else if (aalx.this.a.j()) {
                    aalx.this.g.e(aalx.this.a);
                    aalx.this.a(aanh.a);
                } else {
                    aalx.this.g.d(aalx.this.a);
                    aalx.this.a(aanh.d);
                }
                aalx.this.d.cs_();
            }

            public /* synthetic */ void a_(Object object) {
                this.a((aamf)object);
            }

            public void onError(Throwable throwable) {
                aalx.this.d.cs_();
                aalx.this.d.a(throwable);
                kly.a("consent_interactor").b("consent check", throwable);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", 2512309377846186838L, 2113803341035351170L, -6923720291955140451L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 220);
        }
        this.d();
        this.d.a(this.b(aanh.c, hhy.e()));
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }

    protected void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJNZRnrqXVWC6hROP0akVg3", "enc::WD/7tN4wkeSoBb9ZkEP7FDkPfmQPXKZAVeV40pbq6/I=", 2512309377846186838L, 2113803341035351170L, -6590376132571480863L, 6165381391493657874L, null, "enc::053ZWR5vo+kzq/BslgVpkYQSnrzFnvUBJ2bD0TgZOgU=", 110);
        }
        super.j();
        this.d();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

