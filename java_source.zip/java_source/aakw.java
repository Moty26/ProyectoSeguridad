/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlj
 *  awnk
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInPickupData
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInPickupData$Builder
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState
 *  eih
 *  hpz
 *  hqg
 */
import com.uber.model.core.generated.rtapi.models.commute.CommuteOptInPickupData;
import com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState;

public class aakw
implements aakv,
aakx {
    private final eih<CommuteOptInState> a;
    private final Integer b;
    private final String c;

    /*
     * Enabled aggressive block sorting
     */
    public aakw(hpz hpz2) {
        Object var4_2 = null;
        this.a = eih.a();
        boolean bl = aaky.a(hpz2);
        Object object = bl ? this.a(hpz2) : null;
        this.b = object;
        object = var4_2;
        if (bl) {
            object = this.b(hpz2);
        }
        this.c = object;
    }

    private Integer a(hpz hpz2) {
        long l = hpz2.a((hqg)aakt.DXC_COMMUTE_RIDER_MASTER, "opt_in_dialog_auto_dismiss_time_interval", (long)-1);
        if (l > 0) {
            return (int)l;
        }
        return null;
    }

    private String b(hpz hpz2) {
        return hpz2.a((hqg)aakt.DXC_COMMUTE_RIDER_MASTER, "opt_in_flow");
    }

    @Override
    public awlj<CommuteOptInState> a() {
        return this.a.hide();
    }

    @Override
    public void a(CommuteOptInState commuteOptInState) {
        this.a.a((Object)commuteOptInState);
    }

    @Override
    public awlj<CommuteOptInPickupData> b() {
        return this.a().map((awnk)new awnk<CommuteOptInState, CommuteOptInPickupData>(){

            public CommuteOptInPickupData a(CommuteOptInState commuteOptInState) {
                return CommuteOptInPickupData.builder().optInState(commuteOptInState).optInTimeoutSeconds(aakw.this.b).optInType(aakw.this.c).build();
            }
        });
    }

}

