/*
 * Decompiled with CFR 0_119.
 */
public interface aans {
    public void a(aanh var1);
}

