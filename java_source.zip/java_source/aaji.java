/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aaji {
    private aaiv a;
    private aaiw b;

    private aaji() {
    }

    static /* synthetic */ aaiv a(aaji aaji2) {
        return aaji2.a;
    }

    static /* synthetic */ aaiw b(aaji aaji2) {
        return aaji2.b;
    }

    public aaiu a() {
        if (this.a == null) {
            throw new IllegalStateException(aaiv.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aaiw.class.getCanonicalName() + " must be set");
        }
        return new aajh(this);
    }

    public aaji a(aaiv aaiv2) {
        this.a = (aaiv)((Object)awec.a((Object)((Object)aaiv2)));
        return this;
    }

    public aaji a(aaiw aaiw2) {
        this.b = (aaiw)awec.a((Object)aaiw2);
        return this;
    }
}

