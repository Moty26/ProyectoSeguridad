/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewj
 */
public abstract class aaeh<Presenter extends aaej, Router extends aaek>
extends ewj<Presenter, Router> {
    Presenter g;
}

