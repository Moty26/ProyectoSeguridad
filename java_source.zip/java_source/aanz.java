/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 */
import android.view.ViewGroup;

public class aanz
implements aanx {
    @Override
    public aaox a(aaow aaow2, ViewGroup viewGroup) {
        return new aaoh(aaow2).a(viewGroup);
    }
}

