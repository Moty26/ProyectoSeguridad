/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  avyy
 *  avyz
 *  com.ubercab.ui.FloatingLabelEditText
 */
import com.ubercab.ui.FloatingLabelEditText;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class aajp
implements avyz<FloatingLabelEditText, avyy> {
    private static final long a = TimeUnit.DAYS.toMillis(365);
    private final int b;
    private final avyy c;
    private Long d;

    public aajp(int n, avyy avyy2) {
        this.b = n;
        this.c = avyy2;
    }

    public avyy a(FloatingLabelEditText floatingLabelEditText) {
        if (this.d != null && (int)(Math.abs(new Date().getTime() - this.d) / a) < this.b) {
            return this.c;
        }
        return null;
    }

    public void a(Long l) {
        this.d = l;
    }
}

