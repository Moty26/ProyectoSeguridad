/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 *  ewc
 *  eyq
 */
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

public final class aafb
implements awdv<aafh> {
    static final /* synthetic */ boolean a;
    private final axss<aaev> b;
    private final axss<CobrandCardOfferView> c;
    private final axss<aafc> d;
    private final axss<eyq> e;
    private final axss<ewc> f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aafb.class.desiredAssertionStatus();
        a = bl;
    }

    public aafb(axss<aaev> axss2, axss<CobrandCardOfferView> axss3, axss<aafc> axss4, axss<eyq> axss5, axss<ewc> axss6) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
    }

    public static awdv<aafh> a(axss<aaev> axss2, axss<CobrandCardOfferView> axss3, axss<aafc> axss4, axss<eyq> axss5, axss<ewc> axss6) {
        return new aafb(axss2, axss3, axss4, axss5, axss6);
    }

    public aafh a() {
        return (aafh)((Object)awec.a((Object)((Object)aaex.a((aaev)this.b.get(), (CobrandCardOfferView)this.c.get(), (aafc)this.d.get(), (eyq)this.e.get(), (ewc)this.f.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

