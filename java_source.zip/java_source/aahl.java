/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  auhz
 *  auif
 *  avxl
 *  avyy
 *  avyz
 *  avzb
 *  avze
 *  avzg
 *  awlj
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView
 *  com.ubercab.presidio.cobrandcard.application.personalinfo.DropDownLikeEditTextField
 *  com.ubercab.presidio.payment.base.ui.util.ClickableFloatingLabelEditText
 *  com.ubercab.ui.FloatingLabelEditText
 *  com.ubercab.ui.core.UButton
 *  eih
 *  eot
 *  eov
 *  eox
 *  exl
 *  gsq
 *  llg
 *  llw
 */
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView;
import com.ubercab.presidio.cobrandcard.application.personalinfo.DropDownLikeEditTextField;
import com.ubercab.presidio.payment.base.ui.util.ClickableFloatingLabelEditText;
import com.ubercab.ui.FloatingLabelEditText;
import com.ubercab.ui.core.UButton;
import java.util.List;
import java.util.Locale;

public class aahl
extends exl<CobrandCardAddressView>
implements aaho {
    private static final String[] a = new String[]{"AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY"};
    private final aahv b;
    private final aahm c;
    private final aagq d;
    private eih<Boolean> e;

    public aahl(CobrandCardAddressView cobrandCardAddressView, aahm aahm2, aahv aahv2, aagq aagq2) {
        super((View)cobrandCardAddressView);
        this.d = aagq2;
        ((CobrandCardAddressView)this.i()).a((aaho)this);
        this.b = aahv2;
        this.c = aahm2;
    }

    private void b() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::PEqM7SmtsGHRNuY95Y1gVABEk+5h5QxN0pVTC0yssGI=", -1445367778186893929L, 5708913831203429456L, 7917008305137517131L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 91);
        }
        this.l();
        this.m();
        this.k();
        this.j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::i3QjaNV65HYUV0vC0SkK6dvvl8JzBoeFfeFfwCZgdfU=", -1445367778186893929L, 5708913831203429456L, -5370545716216592912L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 99);
        }
        ((eov)this.d.a().observeOn(awmh.a()).to((awnk)new eot((eox)this))).a((awlp)new auif<aagr>(){

            public void a(aagr aagr2) throws Exception {
                ((CobrandCardAddressView)aahl.this.i()).c().d((CharSequence)aagr2.a());
                ((CobrandCardAddressView)aahl.this.i()).d().d((CharSequence)aagr2.b());
                ((CobrandCardAddressView)aahl.this.i()).e().d((CharSequence)aagr2.c());
                ((CobrandCardAddressView)aahl.this.i()).g().b(aagr2.d());
                ((CobrandCardAddressView)aahl.this.i()).f().d((CharSequence)aagr2.e());
                aahl.this.n();
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::oEOE4Eko1tJUUZjrbJkjEvx9XUN65qOLBVM9n5zm3aI=", -1445367778186893929L, 5708913831203429456L, -7171068847808750571L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 117) : null;
        Drawable drawable = avxl.a((Context)((CobrandCardAddressView)this.i()).getContext(), (int)aafu.ub__cobrandcard_help_icon, (int)aaft.ub__ui_core_brand_grey_80);
        ((CobrandCardAddressView)this.i()).c().a(null, drawable);
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void l() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::r6Ns3C+EqMzl+lFIp66fFTIXYDEqwpJ2ZDb2jW4H5MA=", -1445367778186893929L, 5708913831203429456L, 125490928547692315L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 126) : null;
        Object object = ((CobrandCardAddressView)this.i()).getResources().getString(aafx.cobrandcard_address_validation_maximumAddressLength, new Object[]{32});
        this.b.a(new aahw(32, new avyy((CharSequence)object)), (FloatingLabelEditText)((CobrandCardAddressView)this.i()).c(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_address_validation_addressIsValid)), (FloatingLabelEditText)((CobrandCardAddressView)this.i()).c(), true);
        object = new avzb(){

            public CharSequence a() {
                return Locale.US.getCountry();
            }
        };
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avzg((avzb)object, (Object)new avyy(aafx.cobrandcard_address_validation_zipCodeIsValid)), (FloatingLabelEditText)((CobrandCardAddressView)this.i()).f(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_address_validation_cityIsValid)), (FloatingLabelEditText)((CobrandCardAddressView)this.i()).e(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_address_validation_stateIsValid)), ((CobrandCardAddressView)this.i()).g().b(), false);
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::KbrII09E6NuGH6JQ+mBqkbRQ6hE0x9aVkyjwtJDe2EU=", -1445367778186893929L, 5708913831203429456L, 8727261037778022271L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 160);
        }
        this.e = eih.b((Object)false);
        ((eov)this.e.to((awnk)new eot((eox)this))).a((awlp)new auif<Boolean>(){

            public void a(Boolean bl) throws Exception {
                ((CobrandCardAddressView)aahl.this.i()).a(bl);
            }
        });
        ((eov)((CobrandCardAddressView)this.i()).c().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aahl.this.n();
            }
        });
        ((eov)((CobrandCardAddressView)this.i()).d().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aahl.this.n();
            }
        });
        ((eov)((CobrandCardAddressView)this.i()).e().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aahl.this.n();
            }
        });
        ((eov)((CobrandCardAddressView)this.i()).g().b().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aahl.this.n();
            }
        });
        ((eov)((CobrandCardAddressView)this.i()).f().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aahl.this.n();
            }
        });
        ((eov)((CobrandCardAddressView)this.i()).h().i().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                if (aahl.this.b.a().isEmpty()) {
                    gsq.b((Context)((CobrandCardAddressView)aahl.this.i()).getContext(), (View)aahl.this.i());
                    aahl.this.c.a(((CobrandCardAddressView)aahl.this.i()).c().e().toString(), ((CobrandCardAddressView)aahl.this.i()).d().e().toString(), ((CobrandCardAddressView)aahl.this.i()).e().e().toString(), ((CobrandCardAddressView)aahl.this.i()).g().b().e().toString(), ((CobrandCardAddressView)aahl.this.i()).f().e().toString());
                }
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void n() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::Xb1prVOKAitqEVSeADgD/1iTzqeVhAxv97RyJcd7iOZJ1Qj0MFpfhwmAxqniIemh", -1445367778186893929L, 5708913831203429456L, -5383437497431032144L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 254);
        }
        eih<Boolean> eih2 = this.e;
        boolean bl = this.b.b().size() == 0;
        eih2.a((Object)bl);
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::jV2L8m+ZRR9jHepxQoiiVEVc/L+ptOZW9Nevss1XAqA=", -1445367778186893929L, 5708913831203429456L, -6183974371888929634L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 238);
        }
        ((eov)aakr.a(((CobrandCardAddressView)this.i()).getContext()).a(a).a(aafx.cobrandcard_done).b().b().to((awnk)new eot((eox)this))).a((awlp)new auif<String>(){

            public void a(String string) throws Exception {
                ((CobrandCardAddressView)aahl.this.i()).g().b(string);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::mHjNXpidAhZ1UI8Bj9wOhNESYLsWWaNS+Ga0pIiMDWk=", -1445367778186893929L, 5708913831203429456L, 8792004404122595672L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 74);
        }
        super.f();
        ((eov)((CobrandCardAddressView)this.i()).b().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                gsq.b((Context)((CobrandCardAddressView)aahl.this.i()).getContext(), (View)aahl.this.i());
                aahl.this.c.d();
            }
        });
        this.b();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void g() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtVoU+pGgPCdSMIoJE5N2C6oR47+it+XCGT5ih8Ozprj", "enc::LIu0KBS4aHqYF90tspXATwkCV1XhZpU1szXsfmGftnU=", -1445367778186893929L, 5708913831203429456L, -5669698541601424854L, 1953763409102406465L, null, "enc::Rw2kQHiSRuVukVtkMBkEvUMFhqBhcSc/fVB0dy6vek4kJdzLcQ3yUBFpoXdGpyhu", 68) : null;
        super.g();
        ((CobrandCardAddressView)this.i()).a(null);
        if (llw2 != null) {
            llw2.i();
        }
    }

}

