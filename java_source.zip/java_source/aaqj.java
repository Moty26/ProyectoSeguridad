/*
 * Decompiled with CFR 0_119.
 */
public enum aaqj {
    a,
    b,
    c;
    

    private aaqj() {
    }
}

