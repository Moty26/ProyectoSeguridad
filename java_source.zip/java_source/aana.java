/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  awnk
 */
import android.net.Uri;
import java.util.Map;

final class aana
extends aanq {
    private aanw a;
    private Boolean b;
    private Integer c;
    private Integer d;
    private Integer e;
    private Integer f;
    private Integer g;
    private Integer h;
    private String i;
    private String j;
    private String k;
    private String l;
    private String m;
    private awnk<String, Map<String, String>> n;
    private awnk<String, Map<String, String>> o;
    private awnk<String, Map<String, String>> p;
    private awnk<String, Map<String, String>> q;
    private awnk<String, Map<String, String>> r;
    private Integer s;
    private Integer t;
    private String u;
    private Integer v;
    private Uri w;

    aana() {
    }

    private aana(aanp aanp2) {
        this.a = aanp2.a();
        this.b = aanp2.b();
        this.c = aanp2.c();
        this.d = aanp2.d();
        this.e = aanp2.e();
        this.f = aanp2.f();
        this.g = aanp2.g();
        this.h = aanp2.h();
        this.i = aanp2.i();
        this.j = aanp2.j();
        this.k = aanp2.k();
        this.l = aanp2.l();
        this.m = aanp2.m();
        this.n = aanp2.n();
        this.o = aanp2.o();
        this.p = aanp2.p();
        this.q = aanp2.q();
        this.r = aanp2.r();
        this.s = aanp2.s();
        this.t = aanp2.t();
        this.u = aanp2.u();
        this.v = aanp2.v();
        this.w = aanp2.w();
    }

    @Override
    public aanp a() {
        String string = "";
        if (this.a == null) {
            string = "" + " type";
        }
        String string2 = string;
        if (this.b == null) {
            string2 = string + " deferrable";
        }
        string = string2;
        if (this.c == null) {
            string = string2 + " title";
        }
        string2 = string;
        if (this.d == null) {
            string2 = string + " message";
        }
        string = string2;
        if (this.e == null) {
            string = string2 + " acceptButtonText";
        }
        string2 = string;
        if (this.f == null) {
            string2 = string + " acceptButtonPermissionGrantedText";
        }
        string = string2;
        if (this.g == null) {
            string = string2 + " deferButtonText";
        }
        string2 = string;
        if (this.h == null) {
            string2 = string + " cancelButtonText";
        }
        string = string2;
        if (this.s == null) {
            string = string2 + " legalText";
        }
        string2 = string;
        if (this.t == null) {
            string2 = string + " learnMoreLinkText";
        }
        string = string2;
        if (this.v == null) {
            string = string2 + " illustration";
        }
        if (!string.isEmpty()) {
            throw new IllegalStateException("Missing required properties:" + string);
        }
        return new aamz(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w);
    }

    @Override
    public aanq a(int n) {
        this.c = n;
        return this;
    }

    @Override
    public aanq a(aanw aanw2) {
        if (aanw2 == null) {
            throw new NullPointerException("Null type");
        }
        this.a = aanw2;
        return this;
    }

    @Override
    public aanq a(awnk<String, Map<String, String>> awnk2) {
        this.n = awnk2;
        return this;
    }

    @Override
    public aanq a(Boolean bl) {
        if (bl == null) {
            throw new NullPointerException("Null deferrable");
        }
        this.b = bl;
        return this;
    }

    @Override
    public aanq a(String string) {
        this.i = string;
        return this;
    }

    @Override
    public aanq b(int n) {
        this.d = n;
        return this;
    }

    @Override
    public aanq b(awnk<String, Map<String, String>> awnk2) {
        this.o = awnk2;
        return this;
    }

    @Override
    public aanq b(String string) {
        this.j = string;
        return this;
    }

    @Override
    public aanq c(int n) {
        this.e = n;
        return this;
    }

    @Override
    public aanq c(awnk<String, Map<String, String>> awnk2) {
        this.p = awnk2;
        return this;
    }

    @Override
    public aanq c(String string) {
        this.k = string;
        return this;
    }

    @Override
    public aanq d(int n) {
        this.f = n;
        return this;
    }

    @Override
    public aanq d(awnk<String, Map<String, String>> awnk2) {
        this.q = awnk2;
        return this;
    }

    @Override
    public aanq d(String string) {
        this.l = string;
        return this;
    }

    @Override
    public aanq e(int n) {
        this.g = n;
        return this;
    }

    @Override
    public aanq e(awnk<String, Map<String, String>> awnk2) {
        this.r = awnk2;
        return this;
    }

    @Override
    public aanq e(String string) {
        this.m = string;
        return this;
    }

    @Override
    public aanq f(int n) {
        this.h = n;
        return this;
    }

    @Override
    public aanq f(String string) {
        this.u = string;
        return this;
    }

    @Override
    public aanq g(int n) {
        this.s = n;
        return this;
    }

    @Override
    public aanq h(int n) {
        this.t = n;
        return this;
    }

    @Override
    public aanq i(int n) {
        this.v = n;
        return this;
    }
}

