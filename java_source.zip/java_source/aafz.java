/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView;

public class aafz
extends exk<CobrandCardApplicationView, aagp, aagd> {
    public aafz(aagd aagd2) {
        super((Object)aagd2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aagp a(ViewGroup object, OfferResponse offerResponse) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qmza+abMdFa63BuivhucOEyQ=", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymlqnz8Q6uTgNMaeDlYmBzdt/iIWiLS5SWYXTBSIe+3/hoGafe8L4j/qbKqFijl89v00xdg+xlwIifc1wVljDnehe1hcmLfhyUvGOV7idiQaN+vSmoHiaLIvDil7VCEvvKC9V+JQBFoM6VkU+nP3zzDt0n1208U5X+TfA0RdKa+WtvNkU+Vf+bvu/EoMLHw28ZCQ3dzJPAjlN4x0JKQvOZBR", 7963966960560010407L, -750066343294057651L, -8928912998763966577L, 7185931817553012858L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcHwDuamWqrTDIETTqnKWkrx/BwVASQoQkIxvQoYKN7NZ", 52) : null;
        object = (CobrandCardApplicationView)this.a_((ViewGroup)object);
        aagl aagl2 = new aagl();
        object = aagv.b().a((aagd)this.bS_()).a(new aagc(aagl2, (CobrandCardApplicationView)object, offerResponse)).a().a();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected CobrandCardApplicationView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qmza+abMdFa63BuivhucOEyQ=", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zMmvnVZyy2ZVqacok3gBZFoFG8gT2jHUs1nJbm5oeMcbwqed1uOAB4d3PHVOyxLnTzhmDubNMAYQv5Dg9XcMIRQ==", 7963966960560010407L, -750066343294057651L, 923028787648278312L, 7185931817553012858L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcHwDuamWqrTDIETTqnKWkrx/BwVASQoQkIxvQoYKN7NZ", 63) : null;
        layoutInflater = (CobrandCardApplicationView)layoutInflater.inflate(aafw.ub__cobrandcard_application, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

