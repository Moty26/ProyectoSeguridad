/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aain {
    private aaia a;
    private aaib b;

    private aain() {
    }

    static /* synthetic */ aaia a(aain aain2) {
        return aain2.a;
    }

    static /* synthetic */ aaib b(aain aain2) {
        return aain2.b;
    }

    public aahz a() {
        if (this.a == null) {
            throw new IllegalStateException(aaia.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aaib.class.getCanonicalName() + " must be set");
        }
        return new aaim(this);
    }

    public aain a(aaia aaia2) {
        this.a = (aaia)((Object)awec.a((Object)((Object)aaia2)));
        return this;
    }

    public aain a(aaib aaib2) {
        this.b = (aaib)awec.a((Object)aaib2);
        return this;
    }
}

