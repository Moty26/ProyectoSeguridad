/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  android.view.View
 *  android.view.ViewGroup
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 *  ewc
 *  ewj
 *  ewl
 *  eww
 *  ewz
 *  exm
 *  eyq
 *  eys
 *  ezc
 *  ezi
 *  ezj
 *  ezl
 *  llg
 *  llw
 */
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

public class aafh
extends exm<CobrandCardOfferView, aafc, aaev> {
    private aafz a;
    private final eyq b;
    private final ewc c;

    public aafh(aafz aafz2, CobrandCardOfferView cobrandCardOfferView, aafc aafc2, aaev aaev2, eyq eyq2, ewc ewc2) {
        super((View)cobrandCardOfferView, (ewj)aafc2, (ewl)aaev2);
        this.a = aafz2;
        this.b = eyq2;
        this.c = ewc2;
    }

    void a(Uri uri) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOft+F/ir7M9drNelX9gEDTLZQ==", "enc::4/LUclrTthywEWD7DFqon1LyIqjMlJInkR9tYB4YDAo=", 3892689495945724297L, -1331350984892171566L, 8091821050864579205L, 4285526870058266813L, null, "enc::AV00HDwcdxyM9iF6Lm5WD/PVYw8lJGe2fjs+5ik7tBg=", 68);
        }
        this.c.startActivity(new Intent("android.intent.action.VIEW", uri));
        if (llw2 != null) {
            llw2.i();
        }
    }

    void a(final OfferResponse offerResponse) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOft+F/ir7M9drNelX9gEDTLZQ==", "enc::aS6De7dYtF+QBhoUvIy6INiJQ05qydH6yWw9eakr8sFEzbZxyo0wdJ7TH1KAVKuzTOca0jF5cHzFKYDis+A1kT2rQR/gOe1LLUH/ftgNfcX2FxzXi23KGf5TqIE4aoHv", 3892689495945724297L, -1331350984892171566L, -7220257061159899079L, 4285526870058266813L, null, "enc::AV00HDwcdxyM9iF6Lm5WD/PVYw8lJGe2fjs+5ik7tBg=", 52);
        }
        offerResponse = eys.a((ezc)new eww((ewz)this){

            public exm a(ViewGroup viewGroup) {
                return aafh.this.a.a(viewGroup, offerResponse);
            }
        }, (ezi)ezj.b((ezl)ezl.a).a()).a();
        this.b.a((eys)offerResponse);
        if (llw2 != null) {
            llw2.i();
        }
    }

    void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOft+F/ir7M9drNelX9gEDTLZQ==", "enc::oHYtXTcMl6QQZMVxNFlM/w==", 3892689495945724297L, -1331350984892171566L, -5992012014774016169L, 4285526870058266813L, null, "enc::AV00HDwcdxyM9iF6Lm5WD/PVYw8lJGe2fjs+5ik7tBg=", 45);
        }
        this.b.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

