/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  ewc
 */
class aajj
implements axss<ewc> {
    private final aaiw a;

    aajj(aaiw aaiw2) {
        this.a = aaiw2;
    }

    public ewc a() {
        return (ewc)awec.a((Object)this.a.i(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

