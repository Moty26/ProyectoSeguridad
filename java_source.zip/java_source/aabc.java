/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  dze
 */
public final class aabc
implements awdv<dze> {
    static final /* synthetic */ boolean a;
    private final aaay b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aabc.class.desiredAssertionStatus();
        a = bl;
    }

    public aabc(aaay aaay2) {
        if (!a && aaay2 == null) {
            throw new AssertionError();
        }
        this.b = aaay2;
    }

    public static awdv<dze> a(aaay aaay2) {
        return new aabc(aaay2);
    }

    public dze a() {
        return (dze)awec.a((Object)this.b.b(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

