/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  ewj
 *  ewo
 *  fbz
 */
public final class aanu
implements awdr<aanr> {
    static final /* synthetic */ boolean a;
    private final axss<aant> b;
    private final axss<aanp> c;
    private final axss<aans> d;
    private final axss<fbz> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aanu.class.desiredAssertionStatus();
        a = bl;
    }

    public aanu(axss<aant> axss2, axss<aanp> axss3, axss<aans> axss4, axss<fbz> axss5) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
    }

    public static awdr<aanr> a(axss<aant> axss2, axss<aanp> axss3, axss<aans> axss4, axss<fbz> axss5) {
        return new aanu(axss2, axss3, axss4, axss5);
    }

    public void a(aanr aanr2) {
        if (aanr2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aanr2, this.b);
        aanr2.a = (aant)this.b.get();
        aanr2.b = (aanp)this.c.get();
        aanr2.c = (aans)this.d.get();
        aanr2.d = (fbz)this.e.get();
    }
}

