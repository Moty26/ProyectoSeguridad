/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactDetail$Type
 *  gss
 */
import com.ubercab.presidio.contacts.model.ContactDetail;

public class aaqg {
    private String a;

    public aaqg(String string) {
        this.a = string;
    }

    public String a(ContactDetail contactDetail) {
        if (contactDetail.type() == ContactDetail.Type.EMAIL) {
            return contactDetail.value();
        }
        return gss.b((String)contactDetail.value(), (String)this.a);
    }
}

