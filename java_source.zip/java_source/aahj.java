/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewj
 *  ewz
 *  llg
 *  llw
 */
public class aahj
extends ewj<aahl, aahn>
implements aahm {
    aahl a;
    aagq b;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(String object, String string, String string2, String string3, String string4) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtODGoBcaaz/6Ohj4svnvA7n7XCbblA69HW6mP7KM67w", "enc::+h1tLDd02ucW+8SvFzR68yipevNYxS5ycOcu00bMpvlj7gGb0deyoHi1sndNSDAgnn9R6U4C+S51b+wd0utVUNBgiBJvM2K2OzeWccIBhNgTdGe0wyHztCmnp6ogDsqshNBOZiYot6m5BkbWafrxwOlEC+sUaH7tk8iYGRaLcAU=", -1445367778186893929L, -9219816095241657076L, 4647515687270466941L, 6165381391493657874L, null, "enc::Rw2kQHiSRuVukVtkMBkEvcSj9HAOBtT9+mn2v/zkegrkfs/mvh4tyegNyts/qxg/", 32) : null;
        object = new aagr((String)object, string, string2, string3, string4);
        this.b.a((aagr)object);
        ((aahn)this.h()).j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtODGoBcaaz/6Ohj4svnvA7n7XCbblA69HW6mP7KM67w", "enc::uU+BkhZsHDaU/gtvAJ2vy7SxXQ57Z4DaudwJi2tPMFE=", -1445367778186893929L, -9219816095241657076L, -3564081918521942663L, 6165381391493657874L, null, "enc::Rw2kQHiSRuVukVtkMBkEvcSj9HAOBtT9+mn2v/zkegrkfs/mvh4tyegNyts/qxg/", 22);
        }
        ((aahn)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPtODGoBcaaz/6Ohj4svnvA7n7XCbblA69HW6mP7KM67w", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", -1445367778186893929L, -9219816095241657076L, -6923720291955140451L, 6165381391493657874L, null, "enc::Rw2kQHiSRuVukVtkMBkEvcSj9HAOBtT9+mn2v/zkegrkfs/mvh4tyegNyts/qxg/", 45);
        }
        ((aahn)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }
}

