/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afg
 *  agi
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.uber.model.core.generated.crack.cobrandcard.OfferBenefit
 *  ejv
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.uber.model.core.generated.crack.cobrandcard.OfferBenefit;
import java.util.Collections;
import java.util.List;

public class aafo
extends afg<aafq> {
    private List<OfferBenefit> a = Collections.emptyList();
    private final ejv b;
    private final aafp c;

    public aafo(ejv ejv2, aafp aafp2) {
        this.b = ejv2;
        this.c = aafp2;
    }

    public int a() {
        return this.a.size();
    }

    public aafq a(ViewGroup viewGroup, int n) {
        return new aafq(LayoutInflater.from((Context)viewGroup.getContext()).inflate(aafw.ub__cobrandcard_offer_benefit_item, viewGroup, false));
    }

    public void a(aafq aafq2, int n) {
        OfferBenefit offerBenefit = this.a.get(n);
        aafq2.a(this.b, offerBenefit, this.c);
    }

    public void a(List<OfferBenefit> list) {
        this.a = list;
        this.e();
    }

    public /* synthetic */ agi b(ViewGroup viewGroup, int n) {
        return this.a(viewGroup, n);
    }
}

