/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  awdr
 *  axss
 *  com.uber.rib.core.RibActivity
 *  ewf
 *  ewj
 *  ewo
 *  lms
 */
import android.view.ViewGroup;
import com.uber.rib.core.RibActivity;

public final class aama
implements awdr<aalx> {
    static final /* synthetic */ boolean a;
    private final axss<ewf> b;
    private final axss<aalu> c;
    private final axss<aamb> d;
    private final axss<ViewGroup> e;
    private final axss<aalz> f;
    private final axss<RibActivity> g;
    private final axss<lms> h;
    private final axss<aalj> i;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aama.class.desiredAssertionStatus();
        a = bl;
    }

    public aama(axss<ewf> axss2, axss<aalu> axss3, axss<aamb> axss4, axss<ViewGroup> axss5, axss<aalz> axss6, axss<RibActivity> axss7, axss<lms> axss8, axss<aalj> axss9) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
        if (!a && axss7 == null) {
            throw new AssertionError();
        }
        this.g = axss7;
        if (!a && axss8 == null) {
            throw new AssertionError();
        }
        this.h = axss8;
        if (!a && axss9 == null) {
            throw new AssertionError();
        }
        this.i = axss9;
    }

    public static awdr<aalx> a(axss<ewf> axss2, axss<aalu> axss3, axss<aamb> axss4, axss<ViewGroup> axss5, axss<aalz> axss6, axss<RibActivity> axss7, axss<lms> axss8, axss<aalj> axss9) {
        return new aama(axss2, axss3, axss4, axss5, axss6, axss7, axss8, axss9);
    }

    public void a(aalx aalx2) {
        if (aalx2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aalx2, this.b);
        aalx2.a = (aalu)this.c.get();
        aalx2.b = (aamb)this.d.get();
        aalx2.c = (ViewGroup)this.e.get();
        aalx2.d = (aalz)this.f.get();
        aalx2.e = (RibActivity)this.g.get();
        aalx2.f = (lms)this.h.get();
        aalx2.g = (aalj)this.i.get();
    }
}

