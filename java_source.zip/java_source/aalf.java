/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apbi
 *  auif
 *  awlj
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInPickupData
 *  com.ubercab.presidio.request_middleware.core.model.MutablePickupRequest
 *  eot
 *  eov
 *  eox
 *  exp
 */
import com.uber.model.core.generated.rtapi.models.commute.CommuteOptInPickupData;
import com.ubercab.presidio.request_middleware.core.model.MutablePickupRequest;

class aalf
extends apbi {
    private final aakx a;

    aalf(MutablePickupRequest mutablePickupRequest, aakx aakx2) {
        super(mutablePickupRequest);
        this.a = aakx2;
    }

    public void a(exp exp2) {
        super.a(exp2);
        ((eov)this.a.b().observeOn(awmh.a()).to((awnk)new eot((eox)exp2))).a((awlp)new auif<CommuteOptInPickupData>(){

            public void a(CommuteOptInPickupData commuteOptInPickupData) throws Exception {
                aalf.this.c().setCommuteOptInPickupData(commuteOptInPickupData);
            }
        });
    }

}

