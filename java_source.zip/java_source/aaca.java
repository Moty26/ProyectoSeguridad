/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alww
 *  alxc
 *  axss
 *  com.uber.rib.core.RibActivity
 *  exn
 *  fbz
 *  hpz
 *  iro
 */
import com.uber.rib.core.RibActivity;

public class aaca
implements alws<alww, exn> {
    private final axss<hpz> a;
    private final axss<RibActivity> b;
    private final axss<aabw> c;
    private final axss<fbz> d;
    private final axss<aacj> e;

    aaca(axss<hpz> axss2, axss<RibActivity> axss3, axss<aabw> axss4, axss<fbz> axss5, axss<aacj> axss6) {
        this.a = axss2;
        this.b = axss3;
        this.c = axss4;
        this.d = axss5;
        this.e = axss6;
    }

    public alxc a() {
        return iro.a;
    }

    public exn a(alww alww2) {
        return new aacb((hpz)this.a.get(), (RibActivity)this.b.get(), (aabw)this.c.get(), (fbz)this.d.get(), (aacj)this.e.get());
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((alww)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((alww)object);
    }

    public String b() {
        return "e5b7deda-b0c9-4a43-b3f5-e54824c4756f";
    }

    public boolean b(alww alww2) {
        return true;
    }
}

