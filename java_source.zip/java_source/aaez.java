/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awdv
 *  awec
 *  axss
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  esc
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;

public final class aaez
implements awdv<CobrandCardClient<apap>> {
    static final /* synthetic */ boolean a;
    private final axss<esc<apap>> b;
    private final axss<CobrandCardDataTransactions<apap>> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaez.class.desiredAssertionStatus();
        a = bl;
    }

    public aaez(axss<esc<apap>> axss2, axss<CobrandCardDataTransactions<apap>> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdv<CobrandCardClient<apap>> a(axss<esc<apap>> axss2, axss<CobrandCardDataTransactions<apap>> axss3) {
        return new aaez(axss2, axss3);
    }

    public CobrandCardClient<apap> a() {
        return (CobrandCardClient)awec.a(aaex.a((esc)this.b.get(), (CobrandCardDataTransactions)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

