/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aaps
implements awdv<aapw> {
    static final /* synthetic */ boolean a;
    private final aapq b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaps.class.desiredAssertionStatus();
        a = bl;
    }

    public aaps(aapq aapq2) {
        if (!a && aapq2 == null) {
            throw new AssertionError();
        }
        this.b = aapq2;
    }

    public static awdv<aapw> a(aapq aapq2) {
        return new aaps(aapq2);
    }

    public aapw a() {
        return (aapw)((Object)awec.a((Object)((Object)this.b.a()), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

