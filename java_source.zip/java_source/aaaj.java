/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Bundle
 *  auif
 *  awlj
 *  awlo
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  bcs
 *  bdu
 *  bgl
 *  bgn
 *  bgo
 *  bgp
 *  com.google.android.gms.common.ConnectionResult
 *  eop
 *  eot
 *  eov
 *  ewe
 *  ewf
 *  ewj
 *  ewz
 *  exu
 *  llg
 *  llw
 *  yzp
 *  zdf
 *  zql
 *  zqu
 *  zyb
 */
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

class aaaj
extends ewj<ewf, aaal>
implements bgn,
bgo {
    awlj<exu> a;
    aaai b;
    bgl c;
    zql d;
    zyb e;
    Context f;

    aaaj() {
    }

    public void a(int n) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1T5Fkc2AyN831TSN0napO55Et72g3/z296o371cvFU5ynGHdDGpG5o35RLA2O3UGbc", "enc::EolqmtfARBAxnva+T9G6HI0vMX81BFa8IjvIUaL/18kxicJPcb+h6qGFwOuJ1Us2", -5263566877833729371L, -2333908290555295200L, -7290031501619350844L, 6165381391493657874L, null, "enc::LJn2elW7IWsObjauAF0j+BK0/FkFMjgEIgClYZwgMaY=", 60);
        }
        kly.b("Google Login: Google Play Services was suspended. (Code: " + n + ")", new Object[0]);
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Bundle bundle) {
        bundle = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1T5Fkc2AyN831TSN0napO55Et72g3/z296o371cvFU5ynGHdDGpG5o35RLA2O3UGbc", "enc::EolqmtfARBAxnva+T9G6HAc43Pq+DqXdv6+mumsAIC3cr8oBYkVwiTj6ATjuVxek", -5263566877833729371L, -2333908290555295200L, 5666017772819456386L, 6165381391493657874L, null, "enc::LJn2elW7IWsObjauAF0j+BK0/FkFMjgEIgClYZwgMaY=", 45) : null;
        kly.b("Google Login: Google API Client is connected.", new Object[0]);
        ((aaal)this.h()).h();
        if (bundle != null) {
            bundle.i();
        }
    }

    public void a(ConnectionResult connectionResult) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1T5Fkc2AyN831TSN0napO55Et72g3/z296o371cvFU5ynGHdDGpG5o35RLA2O3UGbc", "enc::EolqmtfARBAxnva+T9G6HAUSUvzV/2dUkbFlVqyaIH7EURbybzm0JeRQjI2jlB9Tz/GDiuqMA51KwRE37ZWaj+vQnjOvbgr6NFjSnoS45Sg=", -5263566877833729371L, -2333908290555295200L, 6020586226036218511L, 6165381391493657874L, null, "enc::LJn2elW7IWsObjauAF0j+BK0/FkFMjgEIgClYZwgMaY=", 65);
        }
        aaai.b(connectionResult);
        connectionResult = this.b.a(connectionResult);
        this.d.a((zqu)connectionResult, this.f.getResources().getString(yzp.general_error));
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ewe ewe2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1T5Fkc2AyN831TSN0napO55Et72g3/z296o371cvFU5ynGHdDGpG5o35RLA2O3UGbc", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", -5263566877833729371L, -2333908290555295200L, -8133349418566419115L, 6165381391493657874L, null, "enc::LJn2elW7IWsObjauAF0j+BK0/FkFMjgEIgClYZwgMaY=", 72) : null;
        super.a(ewe2);
        ((eov)this.a.compose((awlo)this.e).observeOn(awmh.a()).to((awnk)new eot((eop)this))).a((awlp)new auif<zqu>(){

            public void a(zqu zqu2) throws Exception {
                if (aaaj.this.c.j()) {
                    kly.b("Google Login: Social result received. Signing out of selected profile.", new Object[0]);
                    bcs.h.b(aaaj.this.c);
                }
                switch (zqu2.f()) {
                    default: {
                        kly.a((kmc)zdf.i).b(new RuntimeException("Unknown social auth state."), "Google Login: State not handled! - Value was %d", zqu2.f());
                        return;
                    }
                    case 0: {
                        aaaj.this.d.a(zqu2);
                        return;
                    }
                    case 1: {
                        aaaj.this.d.a(zqu2, aaaj.this.f.getResources().getString(yzp.general_error));
                        return;
                    }
                    case 2: 
                }
                aaaj.this.d.b(zqu2);
            }
        });
        kly.b("Google Login: Connecting to Google API.", new Object[0]);
        this.c.e();
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1T5Fkc2AyN831TSN0napO55Et72g3/z296o371cvFU5ynGHdDGpG5o35RLA2O3UGbc", "enc::WD/7tN4wkeSoBb9ZkEP7FDkPfmQPXKZAVeV40pbq6/I=", -5263566877833729371L, -2333908290555295200L, -6590376132571480863L, 6165381391493657874L, null, "enc::LJn2elW7IWsObjauAF0j+BK0/FkFMjgEIgClYZwgMaY=", 118);
        }
        super.j();
        kly.b("Google Login: Tearing down GoogleInteractor RIB.", new Object[0]);
        this.c.b((bgn)this);
        this.c.b((bgo)this);
        this.c.g();
        kly.b("Google Login: Google API Client disconnected.", new Object[0]);
        if (llw2 != null) {
            llw2.i();
        }
    }

}

