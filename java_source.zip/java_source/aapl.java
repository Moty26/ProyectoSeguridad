/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aapl
implements axss<aapu> {
    private final aapr a;

    aapl(aapr aapr2) {
        this.a = aapr2;
    }

    public aapu a() {
        return (aapu)awec.a((Object)this.a.e(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

