/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnFocusChangeListener
 *  aspo
 *  avyx
 *  avyy
 *  avyz
 *  avzm
 *  com.ubercab.ui.FloatingLabelEditText
 */
import android.view.View;
import com.ubercab.ui.FloatingLabelEditText;

public class aajq
extends avzm {
    public aajq a(avyz<FloatingLabelEditText, avyy> avyz2, final FloatingLabelEditText floatingLabelEditText, boolean bl) {
        super.a((View)floatingLabelEditText, avyz2);
        if (bl) {
            floatingLabelEditText.setOnFocusChangeListener(new View.OnFocusChangeListener(){

                public void onFocusChange(View view, boolean bl) {
                    if (!bl && !aspo.a((CharSequence)floatingLabelEditText.b())) {
                        aajq.this.a((Object)floatingLabelEditText);
                    }
                }
            });
        }
        return this;
    }

}

