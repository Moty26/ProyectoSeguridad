/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactDetail
 */
import com.ubercab.presidio.contacts.model.ContactDetail;

public interface aaqf {
    public int a();

    public int a(aary var1);

    public boolean a(ContactDetail var1);

    public boolean a(String var1);

    public String b(String var1);
}

