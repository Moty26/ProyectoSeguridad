/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awdv
 *  awec
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;

public final class aafa
implements awdv<CobrandCardDataTransactions<apap>> {
    private static final aafa a = new aafa();

    public static awdv<CobrandCardDataTransactions<apap>> b() {
        return a;
    }

    public CobrandCardDataTransactions<apap> a() {
        return (CobrandCardDataTransactions)awec.a(aaex.a(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

