/*
 * Decompiled with CFR 0_119.
 */
interface aalm {
    public aame a();
}

