/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdr
 *  axss
 *  ewc
 *  ewf
 *  ewj
 *  ewo
 *  hpz
 *  zql
 */
import android.content.Context;

public final class aabi
implements awdr<aabh> {
    static final /* synthetic */ boolean a;
    private final axss<ewf> b;
    private final axss<ewc> c;
    private final axss<hpz> d;
    private final axss<aabd> e;
    private final axss<aabg> f;
    private final axss<Context> g;
    private final axss<zql> h;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aabi.class.desiredAssertionStatus();
        a = bl;
    }

    public aabi(axss<ewf> axss2, axss<ewc> axss3, axss<hpz> axss4, axss<aabd> axss5, axss<aabg> axss6, axss<Context> axss7, axss<zql> axss8) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
        if (!a && axss7 == null) {
            throw new AssertionError();
        }
        this.g = axss7;
        if (!a && axss8 == null) {
            throw new AssertionError();
        }
        this.h = axss8;
    }

    public static awdr<aabh> a(axss<ewf> axss2, axss<ewc> axss3, axss<hpz> axss4, axss<aabd> axss5, axss<aabg> axss6, axss<Context> axss7, axss<zql> axss8) {
        return new aabi(axss2, axss3, axss4, axss5, axss6, axss7, axss8);
    }

    public void a(aabh aabh2) {
        if (aabh2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aabh2, this.b);
        aabh2.a = (ewc)this.c.get();
        aabh2.b = (hpz)this.d.get();
        aabh2.c = (aabd)this.e.get();
        aabh2.d = (aabg)this.f.get();
        aabh2.e = (Context)this.g.get();
        aabh2.f = (zql)this.h.get();
    }
}

