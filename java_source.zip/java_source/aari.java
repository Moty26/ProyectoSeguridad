/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactSelection
 */
import com.ubercab.presidio.contacts.model.ContactSelection;

public interface aari {
    public void a(ContactSelection var1);
}

