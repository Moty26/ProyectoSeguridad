/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView
 *  ewj
 *  ewl
 *  eww
 *  ewz
 *  exm
 *  eyq
 *  ezc
 *  llg
 *  llw
 */
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView;

public class aahn
extends exm<CobrandCardAddressView, aahj, aahd> {
    private aahx a;
    private final eyq b;

    public aahn(CobrandCardAddressView cobrandCardAddressView, aahj aahj2, aahd aahd2, eyq eyq2, aahx aahx2) {
        super((View)cobrandCardAddressView, (ewj)aahj2, (ewl)aahd2);
        this.a = aahx2;
        this.b = eyq2;
    }

    public void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPostAyvqJSkAD+3HD87I1tA=", "enc::MW1qpwovHmeQo3067P3+5lc0PUnPWwDzd8Vuy8gcISQ=", -1445367778186893929L, -8829646659816339055L, -2859438141256472459L, 4285526870058266813L, null, "enc::Rw2kQHiSRuVukVtkMBkEvSXmtDgVjWWibuIx6wHOngs=", 33);
        }
        this.b.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPostAyvqJSkAD+3HD87I1tA=", "enc::bXC8/OVj0F68NSBpBy+718qwk43WwQXfBbusbFbEcDE=", -1445367778186893929L, -8829646659816339055L, 3988689529125049728L, 4285526870058266813L, null, "enc::Rw2kQHiSRuVukVtkMBkEvSXmtDgVjWWibuIx6wHOngs=", 37);
        }
        this.b.a((ezc)new eww((ewz)this){

            public exm a(ViewGroup viewGroup) {
                return aahn.this.a.b(viewGroup);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

}

