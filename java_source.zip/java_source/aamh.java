/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hpz
 *  hqg
 */
import java.util.HashSet;
import java.util.Set;

public class aamh {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static aalv a(String object, aanp aanp2, aanp aanp3, hpz hpz2) {
        boolean bl;
        object = aalu.k().a((String)object).a(aamy.ub__contacts_consent_app_settings_modal_title).b(aamy.ub__contacts_consent_app_settings_modal_message).c(aamy.ub__contacts_consent_app_settings_modal_primary_button_text).d(aamy.ub__contacts_consent_app_settings_modal_close).a(new HashSet<String>(){}).a(aanp2).b(aanp3);
        if (!hpz2.a((hqg)aalw.CONTACTS_SYNC)) {
            bl = true;
            do {
                return object.b(bl);
                break;
            } while (true);
        }
        bl = false;
        return object.b(bl);
    }

    public static aalv a(String string, aanp aanp2, hpz hpz2) {
        return aamh.a(string, aanp2, null, hpz2);
    }

    public static aalv a(String string, boolean bl, aanw aanw2, hpz hpz2) {
        return aamh.a(string, aamh.a(aanw2, bl).a(), hpz2);
    }

    public static aanq a(aanw aanw2, boolean bl) {
        return aanp.y().a(aanw2).a(bl).c(aamy.ub__contacts_consent_connect).e(aamy.ub__contacts_consent_skip).f(aamy.ub__contacts_consent_cancel).h(aamy.ub__contacts_consent_learn_more_link).g(aamy.ub__contacts_consent_legal).a(aamy.ub__contacts_consent_title).b(aamy.ub__contacts_consent_message).i(0).f("53db4865-a606-4c99-8468-3f33a85c5e04");
    }

}

