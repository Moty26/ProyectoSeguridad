/*
 * Decompiled with CFR 0_119.
 */
public class aaer {
    private final int a;
    private final int b;

    private aaer(int n, int n2) {
        this.a = n;
        this.b = n2;
    }

    public static aaer a(int n, int n2) {
        return new aaer(n, n2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof aaer)) {
            return false;
        }
        object = (aaer)object;
        if (this.a != object.a) return false;
        if (this.b == object.b) return true;
        return false;
    }

    public int hashCode() {
        return (this.a + 629) * 37 + this.b;
    }

    public String toString() {
        return "ScrollEvent{dx=" + this.a + ", dy=" + this.b + '}';
    }
}

