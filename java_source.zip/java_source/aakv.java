/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState
 */
import com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState;

public interface aakv {
    public void a(CommuteOptInState var1);
}

