/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewc
 *  ewj
 *  ewl
 *  ewz
 */
public class aabj
extends ewz<aabh, aaax> {
    private final ewc a;
    private final aabg b;

    public aabj(aabh aabh2, aaax aaax2) {
        super((ewj)aabh2, (ewl)aaax2);
        this.a = aaax2.d();
        this.b = aaax2.e();
    }
}

