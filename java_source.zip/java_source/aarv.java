/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agi
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  ejv
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class aarv
extends aart {
    private static final int b = aaqr.ub__contact_picker_v2_contact_row;
    private static final int c = aaqr.ub__contact_picker_v2_header_row;
    private static final int d = aaqr.ub__contact_picker_v2_invalid_raw_contact_row;
    private static final int e = aaqr.ub__contact_picker_v2_raw_contact_row;
    private static final int f = aaqr.ub__contact_picker_v2_suggestions_row;
    private final aavl g;

    public aarv(LayoutInflater layoutInflater, aaqg aaqg2, ejv ejv2, aavl aavl2) {
        super(layoutInflater, aaqg2, ejv2, c, b);
        this.g = aavl2;
    }

    private aasm a(ViewGroup viewGroup) {
        return new aasm(this.a.inflate(d, viewGroup, false));
    }

    private aasp b(ViewGroup viewGroup) {
        return new aasp(this.a.inflate(e, viewGroup, false));
    }

    private aasx c(ViewGroup viewGroup) {
        return new aasx(this.a.inflate(f, viewGroup, false), this.g);
    }

    private aasv d(ViewGroup viewGroup) {
        return new aasv(this.a.inflate(f, viewGroup, false));
    }

    @Override
    public aata a(ViewGroup viewGroup, int n) {
        switch (n) {
            default: {
                return super.a(viewGroup, n);
            }
            case 4: {
                return this.c(viewGroup);
            }
            case 2: {
                return this.a(viewGroup);
            }
            case 3: {
                return this.b(viewGroup);
            }
            case 5: 
        }
        return this.d(viewGroup);
    }

    @Override
    public /* synthetic */ agi b(ViewGroup viewGroup, int n) {
        return this.a(viewGroup, n);
    }
}

