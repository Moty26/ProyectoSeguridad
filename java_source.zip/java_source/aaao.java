/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alxc
 *  android.content.Context
 *  hhy
 *  yzr
 *  zqk
 *  zye
 */
import android.content.Context;

public class aaao
implements alws<hhy<Void>, zqk> {
    private final zye a;

    public aaao(zye zye2) {
        this.a = zye2;
    }

    public alxc a() {
        return yzr.c;
    }

    public zqk a(hhy<Void> hhy2) {
        return new aaan(this.a);
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((hhy)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((hhy)object);
    }

    public String b() {
        return "ac546a21-4132-4d44-8fc9-656c5b1d2735";
    }

    public boolean b(hhy<Void> hhy2) {
        return aaai.b(this.a.f());
    }
}

