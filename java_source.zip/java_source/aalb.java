/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  com.uber.model.core.generated.rtapi.services.commute.CommuteDataTransactions
 *  com.uber.model.core.generated.rtapi.services.commute.CommuteOptInStateResponse
 *  com.uber.model.core.generated.rtapi.services.commute.UpdateCommuteOptInStateErrors
 *  erj
 *  esi
 */
import com.uber.model.core.generated.rtapi.services.commute.CommuteDataTransactions;
import com.uber.model.core.generated.rtapi.services.commute.CommuteOptInStateResponse;
import com.uber.model.core.generated.rtapi.services.commute.UpdateCommuteOptInStateErrors;

public class aalb
extends CommuteDataTransactions<apap> {
    public void a(apap apap2, esi<CommuteOptInStateResponse, UpdateCommuteOptInStateErrors> esi2) {
    }

    public /* synthetic */ void updateCommuteOptInStateTransaction(erj erj2, esi esi2) {
        this.a((apap)erj2, esi2);
    }
}

