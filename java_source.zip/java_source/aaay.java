/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdq
 *  axug
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineModelsAdapterFactory
 *  dze
 *  dzg
 *  dzx
 *  ewf
 *  ewj
 *  ewn
 */
import android.content.Context;
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineModelsAdapterFactory;

public class aaay
extends ewn<aabh> {
    public aaay(aabh aabh2) {
        super((ewj)aabh2);
    }

    aabd a(awdq<axug> awdq2, dze dze2) {
        return new aabd(awdq2, dze2);
    }

    aabg a(Context context) {
        return new aabg(context);
    }

    ewf a() {
        return new ewf();
    }

    dze b() {
        return new dzg().a((dzx)LineModelsAdapterFactory.create()).b();
    }
}

