/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  com.uber.model.core.generated.crack.cobrandcard.ApplyResponse
 *  com.uber.model.core.generated.crack.cobrandcard.ProvisionCardResponse
 *  com.uber.model.core.generated.crack.cobrandcard.RedeemResponse
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.ApplyErrors
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.ProvisionCardErrors
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.RedeemErrors
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.StatusErrors
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.StatusPushResponse
 *  erj
 *  esi
 */
import com.uber.model.core.generated.crack.cobrandcard.ApplyResponse;
import com.uber.model.core.generated.crack.cobrandcard.ProvisionCardResponse;
import com.uber.model.core.generated.crack.cobrandcard.RedeemResponse;
import com.uber.model.core.generated.rtapi.services.cobrandcard.ApplyErrors;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;
import com.uber.model.core.generated.rtapi.services.cobrandcard.ProvisionCardErrors;
import com.uber.model.core.generated.rtapi.services.cobrandcard.RedeemErrors;
import com.uber.model.core.generated.rtapi.services.cobrandcard.StatusErrors;
import com.uber.model.core.generated.rtapi.services.cobrandcard.StatusPushResponse;

public class aakn
extends CobrandCardDataTransactions<apap> {
    public void a(apap apap2, esi<StatusPushResponse, StatusErrors> esi2) {
    }

    public /* synthetic */ void applyTransaction(erj erj2, esi esi2) {
        this.b((apap)erj2, esi2);
    }

    public void b(apap apap2, esi<ApplyResponse, ApplyErrors> esi2) {
    }

    public void c(apap apap2, esi<ProvisionCardResponse, ProvisionCardErrors> esi2) {
    }

    public void d(apap apap2, esi<RedeemResponse, RedeemErrors> esi2) {
    }

    public /* synthetic */ void provisionCardTransaction(erj erj2, esi esi2) {
        this.c((apap)erj2, esi2);
    }

    public /* synthetic */ void redeemTransaction(erj erj2, esi esi2) {
        this.d((apap)erj2, esi2);
    }

    public /* synthetic */ void statusTransaction(erj erj2, esi esi2) {
        this.a((apap)erj2, esi2);
    }
}

