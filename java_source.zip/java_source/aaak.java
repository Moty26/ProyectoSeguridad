/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdr
 *  awlj
 *  axss
 *  bgl
 *  ewf
 *  ewj
 *  ewo
 *  exu
 *  zql
 *  zyb
 */
import android.content.Context;

public final class aaak
implements awdr<aaaj> {
    static final /* synthetic */ boolean a;
    private final axss<ewf> b;
    private final axss<awlj<exu>> c;
    private final axss<aaai> d;
    private final axss<bgl> e;
    private final axss<zql> f;
    private final axss<zyb> g;
    private final axss<Context> h;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaak.class.desiredAssertionStatus();
        a = bl;
    }

    public aaak(axss<ewf> axss2, axss<awlj<exu>> axss3, axss<aaai> axss4, axss<bgl> axss5, axss<zql> axss6, axss<zyb> axss7, axss<Context> axss8) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
        if (!a && axss7 == null) {
            throw new AssertionError();
        }
        this.g = axss7;
        if (!a && axss8 == null) {
            throw new AssertionError();
        }
        this.h = axss8;
    }

    public static awdr<aaaj> a(axss<ewf> axss2, axss<awlj<exu>> axss3, axss<aaai> axss4, axss<bgl> axss5, axss<zql> axss6, axss<zyb> axss7, axss<Context> axss8) {
        return new aaak(axss2, axss3, axss4, axss5, axss6, axss7, axss8);
    }

    public void a(aaaj aaaj2) {
        if (aaaj2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aaaj2, this.b);
        aaaj2.a = (awlj)this.c.get();
        aaaj2.b = (aaai)this.d.get();
        aaaj2.c = (bgl)this.e.get();
        aaaj2.d = (zql)this.f.get();
        aaaj2.e = (zyb)this.g.get();
        aaaj2.f = (Context)this.h.get();
    }
}

