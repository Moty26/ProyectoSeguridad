/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.View
 *  android.view.View$OnClickListener
 *  aspo
 *  awlj
 *  awln
 *  awnf
 *  com.ubercab.presidio.contacts.model.Contact
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  com.ubercab.presidio.contacts.model.ContactSelection
 *  com.ubercab.presidio.contacts.model.RawContact
 *  eih
 *  hhx
 *  hie
 *  hif
 *  hik
 *  hil
 *  hiu
 */
import android.content.res.Resources;
import android.view.View;
import com.ubercab.presidio.contacts.model.Contact;
import com.ubercab.presidio.contacts.model.ContactDetail;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;
import com.ubercab.presidio.contacts.model.ContactSelection;
import com.ubercab.presidio.contacts.model.RawContact;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.MissingFormatArgumentException;

public class aase {
    private final ContactPickerCustomization a;
    private final aasf b;
    private final Resources c;
    private final eih<aary> d = eih.a();
    private final eih<ContactSelection> e = eih.a();

    public aase(ContactPickerCustomization contactPickerCustomization, aasf aasf2, Resources resources) {
        this.a = contactPickerCustomization;
        this.b = aasf2;
        this.c = resources;
    }

    /*
     * Enabled aggressive block sorting
     */
    private hie<aatb> a(aary aary2, ContactSelection contactSelection) {
        boolean bl = true;
        hif hif2 = new hif();
        boolean bl2 = !aspo.a((String)aary2.c);
        if (bl2 || this.a.getHideHeaders()) {
            bl = false;
        }
        if (bl2 && !this.a.getHideHeaders()) {
            hif2.a((Object)new aasl(this.c.getString(aaqs.ub__contact_picker_search_results)));
        }
        this.a(aary2.c, contactSelection, hif2, bl);
        if (!bl2) {
            this.a(aary2, contactSelection, hif2);
        }
        this.a(aary2, contactSelection, hif2, bl);
        this.a(aary2, hif2);
        return hif2.a();
    }

    private hik<RawContact> a(hik<RawContact> hiu2, String string) {
        hil hil2 = new hil();
        hiu2 = hiu2.a();
        while (hiu2.hasNext()) {
            RawContact rawContact = (RawContact)hiu2.next();
            if (!this.a(rawContact, string)) continue;
            hil2.a((Object)rawContact);
        }
        return hil2.a();
    }

    private String a(Contact contact) {
        return contact.displayName().substring(0, 1).toLowerCase(Locale.US);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(aary var1_1, ContactSelection var2_2, hif<aatb> var3_3) {
        if (var1_1.b.isEmpty()) {
            return;
        }
        var3_3.a((Object)new aasl(this.c.getString(aaqs.ub__contact_picker_suggested_contacts)));
        var5_4 = var1_1.b.a();
        block0 : do lbl-1000: // 3 sources:
        {
            if (var5_4.hasNext() == false) return;
            var6_6 = (String)var5_4.next();
            if ((var6_6 = var1_1.a.get(var6_6)) == null) ** GOTO lbl-1000
            var7_7 = var6_6.details().a();
            do {
                if (!var7_7.hasNext()) continue block0;
                var8_8 = (ContactDetail)var7_7.next();
                var9_9 = new View.OnClickListener(){

                    public void onClick(View view) {
                        aase.this.b.a(var8_8);
                    }
                };
                var4_5 = this.a.getShouldShowProfilePicture() != false ? 0 : 8;
                var3_3.a((Object)new aasd((Contact)var6_6, var8_8, var9_9, var4_5, var2_2.getContactDetails().contains((Object)var8_8)));
            } while (true);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(aary var1_1, ContactSelection var2_2, hif<aatb> var3_3, boolean var4_4) {
        var6_5 = null;
        var7_6 = var1_1.a.values().iterator();
        while (var7_6.hasNext() != false) {
            var8_8 = var7_6.next();
            var1_1 = var6_5;
            if (!var4_4) ** GOTO lbl12
            if (var6_5 == null) ** GOTO lbl-1000
            var1_1 = var6_5;
            if (!hhx.a((Object)var6_5, (Object)this.a(var8_8))) lbl-1000: // 2 sources:
            {
                var1_1 = this.a(var8_8);
                var3_3.a((Object)new aasl((String)var1_1));
            }
lbl12: // 4 sources:
            var6_5 = var8_8.details().a();
            while (var6_5.hasNext()) {
                var9_9 = (ContactDetail)var6_5.next();
                var10_10 = new View.OnClickListener(){

                    public void onClick(View view) {
                        aase.this.b.a(var9_9);
                    }
                };
                var5_7 = this.a.getShouldShowProfilePicture() != false ? 0 : 8;
                var3_3.a((Object)new aasd(var8_8, var9_9, var10_10, var5_7, var2_2.getContactDetails().contains((Object)var9_9)));
            }
            var6_5 = var1_1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(final aary aary2, hif<aatb> hif2) {
        int n;
        if (!aspo.a((String)aary2.c) && (n = this.a.getContactFilter().a(aary2)) != 0) {
            String string;
            String string2;
            try {
                string2 = this.c.getString(n, new Object[0]);
                string = aary2.c;
            }
            catch (MissingFormatArgumentException missingFormatArgumentException) {
                string2 = this.c.getString(n, new Object[]{aary2.c});
                string = null;
            }
            hif2.a((Object)new aass(string2, string, this.b(aary2), new View.OnClickListener(){

                public void onClick(View view) {
                    aase.this.b.b(aary2.c);
                }
            }));
        }
    }

    private void a(String hiu2, ContactSelection contactSelection, hif<aatb> hif2, boolean bl) {
        hiu2 = this.a(contactSelection.getRawContacts(), (String)hiu2);
        if (!hiu2.isEmpty()) {
            if (bl) {
                hif2.a((Object)new aasl(this.c.getString(aaqs.ub__contact_picker_manual_contacts)));
            }
            hiu2 = hiu2.a();
            while (hiu2.hasNext()) {
                contactSelection = (RawContact)hiu2.next();
                hif2.a((Object)new aass(contactSelection.getValue(), aast.c, new View.OnClickListener((RawContact)contactSelection){
                    final /* synthetic */ RawContact a;

                    public void onClick(View view) {
                        aase.this.b.a(this.a);
                    }
                }));
            }
        }
    }

    private boolean a(RawContact rawContact, String string) {
        if (aspo.a((String)string)) {
            return true;
        }
        string = string.toLowerCase(Locale.US);
        return rawContact.getValue().toLowerCase(Locale.US).contains(string);
    }

    private aast b(aary aary2) {
        if (this.a.getContactFilter().a(aary2.c)) {
            return aast.b;
        }
        return aast.a;
    }

    public awlj<hie<aatb>> a() {
        return awlj.combineLatest((awln)this.d.hide(), (awln)this.e.startWith((Object)ContactSelection.EMPTY), (awnf)new awnf<aary, ContactSelection, hie<aatb>>(){

            public hie<aatb> a(aary aary2, ContactSelection contactSelection) throws Exception {
                return aase.this.a(aary2, contactSelection);
            }
        });
    }

    public void a(aary aary2) {
        this.d.a((Object)aary2);
    }

    public void a(ContactSelection contactSelection) {
        this.e.a((Object)contactSelection);
    }

}

