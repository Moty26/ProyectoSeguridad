/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  yzl
 *  yzp
 *  zpr
 *  zqk
 *  zqq
 *  zye
 */
import java.util.HashMap;
import java.util.Map;

class aaan
implements zqk {
    public static final zpr a = zpr.a;
    private final Map<String, String> b = new HashMap<String, String>();
    private final zye c;

    aaan(zye zye2) {
        this.c = zye2;
        this.b.put("auth_source", a.name());
        this.b.put("social_provider", "google");
    }

    public int a() {
        return 50002;
    }

    public int b() {
        return yzp.login_with_google;
    }

    public int c() {
        return yzp.login_with_google_description;
    }

    public Map<String, String> d() {
        return this.b;
    }

    public int e() {
        return yzl.ub__google_logo;
    }

    public zqq f() {
        return new aaam(this.c);
    }

    public int g() {
        return 0;
    }
}

