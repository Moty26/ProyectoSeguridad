/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.RawContact
 */
import com.ubercab.presidio.contacts.model.ContactDetail;
import com.ubercab.presidio.contacts.model.RawContact;

public interface aasf {
    public void a(ContactDetail var1);

    public void a(RawContact var1);

    public void b(String var1);
}

