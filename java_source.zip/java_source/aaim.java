/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  ewc
 *  ewj
 *  ewq
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public final class aaim
implements aahz {
    static final /* synthetic */ boolean a;
    private axss<aaik> b;
    private axss<aagq> c;
    private axss<aaih> d;
    private awdr<aaif> e;
    private axss<aahz> f;
    private axss<eyq> g;
    private axss<aaij> h;
    private axss<OfferResponse> i;
    private axss<ewc> j;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaim.class.desiredAssertionStatus();
        a = bl;
    }

    private aaim(aain aain2) {
        if (!a && aain2 == null) {
            throw new AssertionError();
        }
        this.a(aain2);
    }

    private void a(aain aain2) {
        this.b = awdu.a(aaic.a(aain.a(aain2)));
        this.c = new aaip(aain.b(aain2));
        this.d = awdu.a(aaid.a(aain.a(aain2), this.b, this.c));
        this.e = aaig.a(this.d, this.c);
        this.f = awdw.a((Object)this);
        this.g = new aair(aain.b(aain2));
        this.h = awdu.a(aaie.a(aain.a(aain2), this.f, this.g));
        this.i = new aaiq(aain.b(aain2));
        this.j = new aaio(aain.b(aain2));
    }

    public static aain b() {
        return new aain(null);
    }

    public /* synthetic */ ewq O_() {
        return this.d();
    }

    @Override
    public aaij a() {
        return (aaij)((Object)this.h.get());
    }

    public void a(aaif aaif2) {
        this.e.a((Object)aaif2);
    }

    public aaih d() {
        return (aaih)this.d.get();
    }

    @Override
    public aagq e() {
        return (aagq)this.c.get();
    }

    @Override
    public eyq f() {
        return (eyq)this.g.get();
    }

    @Override
    public OfferResponse g() {
        return (OfferResponse)this.i.get();
    }

    @Override
    public ewc h() {
        return (ewc)this.j.get();
    }

}

