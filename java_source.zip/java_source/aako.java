/*
 * Decompiled with CFR 0_119.
 */
public interface aako {
    public void a(String var1, String var2);
}

