/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alwv
 *  alwy
 *  hhy
 *  hpz
 */
import java.util.Collections;
import java.util.List;

public class aaoa
extends alwv<hhy<Void>, aanx> {
    public aaoa(hpz hpz2, alwy alwy2) {
        super(hpz2, alwy2);
    }

    protected List<alws<hhy<Void>, aanx>> getInternalPluginFactories() {
        return Collections.singletonList(new aany());
    }
}

