/*
 * Decompiled with CFR 0_119.
 */
public interface aadd {
    public int n();

    public int o();
}

