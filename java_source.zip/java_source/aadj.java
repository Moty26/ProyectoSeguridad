/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior
 *  com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior$1
 *  rw
 *  wy
 */
import android.view.View;
import com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior;

public class aadj
extends wy {
    final /* synthetic */ ExpandingBottomSheetBehavior a;

    private aadj(ExpandingBottomSheetBehavior expandingBottomSheetBehavior) {
        this.a = expandingBottomSheetBehavior;
    }

    public /* synthetic */ aadj(ExpandingBottomSheetBehavior expandingBottomSheetBehavior, ExpandingBottomSheetBehavior.1 var2_2) {
        this(expandingBottomSheetBehavior);
    }

    public int a(View view) {
        return ExpandingBottomSheetBehavior.access$600((ExpandingBottomSheetBehavior)this.a) - ExpandingBottomSheetBehavior.access$1800((ExpandingBottomSheetBehavior)this.a);
    }

    public int a(View view, int n, int n2) {
        n2 = n;
        if (n < ExpandingBottomSheetBehavior.access$1800((ExpandingBottomSheetBehavior)this.a)) {
            n2 = ExpandingBottomSheetBehavior.access$1800((ExpandingBottomSheetBehavior)this.a);
        }
        return n2;
    }

    public void a(int n) {
        if (n == 1) {
            ExpandingBottomSheetBehavior.access$900((ExpandingBottomSheetBehavior)this.a, (int)1);
        }
    }

    public void a(View view, float f, float f2) {
        aadi aadi2 = ExpandingBottomSheetBehavior.access$1600((ExpandingBottomSheetBehavior)this.a, (View)view, (float)f2);
        if (ExpandingBottomSheetBehavior.access$700((ExpandingBottomSheetBehavior)this.a).settleCapturedViewAt(view.getLeft(), aadi.a(aadi2))) {
            ExpandingBottomSheetBehavior.access$900((ExpandingBottomSheetBehavior)this.a, (int)2);
            rw.a((View)view, (Runnable)ExpandingBottomSheetBehavior.access$1700((ExpandingBottomSheetBehavior)this.a, (View)view, (int)aadi.b(aadi2)));
            return;
        }
        ExpandingBottomSheetBehavior.access$900((ExpandingBottomSheetBehavior)this.a, (int)aadi.b(aadi2));
    }

    public void a(View view, int n, int n2, int n3, int n4) {
        ExpandingBottomSheetBehavior.access$1500((ExpandingBottomSheetBehavior)this.a, (int)n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean a(View view, int n) {
        if (ExpandingBottomSheetBehavior.access$1000((ExpandingBottomSheetBehavior)this.a) == 1) {
            return false;
        }
        if (ExpandingBottomSheetBehavior.access$1100((ExpandingBottomSheetBehavior)this.a)) return false;
        if (ExpandingBottomSheetBehavior.access$1000((ExpandingBottomSheetBehavior)this.a) == 4 && ExpandingBottomSheetBehavior.access$1200((ExpandingBottomSheetBehavior)this.a) == n) {
            View view2 = ExpandingBottomSheetBehavior.access$1300((ExpandingBottomSheetBehavior)this.a) != null ? (View)ExpandingBottomSheetBehavior.access$1300((ExpandingBottomSheetBehavior)this.a).get() : null;
            if (view2 != null) {
                if (rw.a((View)view2, (int)-1)) return false;
            }
        }
        if (ExpandingBottomSheetBehavior.access$1400((ExpandingBottomSheetBehavior)this.a) == null) return false;
        if (ExpandingBottomSheetBehavior.access$1400((ExpandingBottomSheetBehavior)this.a).get() != view) return false;
        return true;
    }

    public int b(View view, int n, int n2) {
        return view.getLeft();
    }
}

