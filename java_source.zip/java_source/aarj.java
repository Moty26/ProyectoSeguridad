/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  ewj
 *  ewo
 */
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public final class aarj
implements awdr<aarh> {
    static final /* synthetic */ boolean a;
    private final axss<aark> b;
    private final axss<aaqh> c;
    private final axss<ContactPickerCustomization> d;
    private final axss<aarx> e;
    private final axss<aase> f;
    private final axss<aari> g;
    private final axss<hlg> h;
    private final axss<RibActivity> i;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarj.class.desiredAssertionStatus();
        a = bl;
    }

    public aarj(axss<aark> axss2, axss<aaqh> axss3, axss<ContactPickerCustomization> axss4, axss<aarx> axss5, axss<aase> axss6, axss<aari> axss7, axss<hlg> axss8, axss<RibActivity> axss9) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
        if (!a && axss7 == null) {
            throw new AssertionError();
        }
        this.g = axss7;
        if (!a && axss8 == null) {
            throw new AssertionError();
        }
        this.h = axss8;
        if (!a && axss9 == null) {
            throw new AssertionError();
        }
        this.i = axss9;
    }

    public static awdr<aarh> a(axss<aark> axss2, axss<aaqh> axss3, axss<ContactPickerCustomization> axss4, axss<aarx> axss5, axss<aase> axss6, axss<aari> axss7, axss<hlg> axss8, axss<RibActivity> axss9) {
        return new aarj(axss2, axss3, axss4, axss5, axss6, axss7, axss8, axss9);
    }

    public void a(aarh aarh2) {
        if (aarh2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aarh2, this.b);
        aarh2.a = (aaqh)this.c.get();
        aarh2.b = (ContactPickerCustomization)this.d.get();
        aarh2.c = (aark)((Object)this.b.get());
        aarh2.d = (aarx)this.e.get();
        aarh2.e = (aase)this.f.get();
        aarh2.f = (aari)this.g.get();
        aarh2.g = (hlg)this.h.get();
        aarh2.i = (RibActivity)this.i.get();
    }
}

