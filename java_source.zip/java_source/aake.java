/*
 * Decompiled with CFR 0_119.
 */
public interface aake {
    public void a(String var1);
}

