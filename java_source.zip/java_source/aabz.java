/*
 * Decompiled with CFR 0_119.
 */
enum aabz implements kmc
{
    a,
    b;
    

    private aabz() {
    }
}

