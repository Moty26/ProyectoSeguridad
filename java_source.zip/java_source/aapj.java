/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  awdu
 *  axss
 *  ewj
 *  ewq
 *  fbz
 */
public final class aapj
implements aapp {
    static final /* synthetic */ boolean a;
    private axss<aapw> b;
    private axss<aapu> c;
    private axss<aaob> d;
    private axss<fbz> e;
    private awdr<aapt> f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aapj.class.desiredAssertionStatus();
        a = bl;
    }

    private aapj(aapk aapk2) {
        if (!a && aapk2 == null) {
            throw new AssertionError();
        }
        this.a(aapk2);
    }

    public static aapk a() {
        return new aapk(null);
    }

    private void a(aapk aapk2) {
        this.b = awdu.a(aaps.a(aapk.a(aapk2)));
        this.c = new aapl(aapk.b(aapk2));
        this.d = new aapm(aapk.b(aapk2));
        this.e = new aapn(aapk.b(aapk2));
        this.f = aapv.a(this.b, this.c, this.d, this.e);
    }

    public /* synthetic */ ewq O_() {
        return this.b();
    }

    public void a(aapt aapt2) {
        this.f.a((Object)aapt2);
    }

    public aapw b() {
        return (aapw)((Object)this.b.get());
    }

}

