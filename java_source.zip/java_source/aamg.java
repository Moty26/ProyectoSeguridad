/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.ViewGroup
 *  auhz
 *  awlv
 *  awnf
 *  awnl
 */
import android.content.Context;
import android.view.ViewGroup;

public class aamg
implements aamb {
    private final aavt a;
    private final aamq b;
    private final Context c;
    private final aalj d;

    public aamg(aavt aavt2, aamq aamq2, Context context, aalj aalj2) {
        this.a = aavt2;
        this.b = aamq2;
        this.c = context;
        this.d = aalj2;
    }

    public aame a(aamc aamc2, ViewGroup viewGroup, aalu aalu2) {
        this.d.a(aalu2);
        return new aall(aamc2).a(viewGroup, aalu2, this);
    }

    @Override
    public awlv<aamf> a(final aalu aalu2) {
        return awlv.a(this.b(aalu2), this.c(aalu2), this.d(aalu2), (awnl)new awnl<Boolean, Boolean, Boolean, aamf>(){

            public aamf a(Boolean object, Boolean bl, Boolean bl2) throws Exception {
                object = new aamf(object.booleanValue(), bl, bl2);
                aamg.this.d.a(aalu2, (aamf)object);
                return object;
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public awlv<auhz> a(aalu aalu2, aamd aamd2) {
        this.d.a(aalu2, aamd2);
        if (aamd2.b()) {
            switch (.a[aamd2.a().ordinal()]) {
                default: {
                    return awlv.b((Object)auhz.a);
                }
                case 1: {
                    return awlv.a(this.b.a(aalu2.a(), true), this.a.a(aalu2.a(), true, this.c.getString(aalu2.b().s())), (awnf)new awnf<auhz, auhz, auhz>(){

                        public auhz a(auhz auhz2, auhz auhz3) throws Exception {
                            return auhz.a;
                        }
                    });
                }
                case 2: 
            }
            return awlv.a(this.b.a(aalu2.a(), true), this.a.b(aalu2.a(), true), (awnf)new awnf<auhz, auhz, auhz>(){

                public auhz a(auhz auhz2, auhz auhz3) throws Exception {
                    return auhz.a;
                }
            });
        }
        if (!aamd2.c()) return awlv.b((Object)auhz.a);
        switch (aamd2.a()) {
            default: {
                return awlv.b((Object)auhz.a);
            }
            case a: 
        }
        return this.b.a(aalu2.a(), true);
    }

    public awlv<Boolean> b(aalu aalu2) {
        return this.a.c(aalu2.a());
    }

    @Override
    public awlv<auhz> b(aalu aalu2, aamd aamd2) {
        this.d.b(aalu2, aamd2);
        if (aamd2.a() == aanh.a && aamd2.b()) {
            this.a.a(aalu2.a(), (Boolean)aamd2.e());
        }
        return awlv.b((Object)auhz.a);
    }

    public awlv<Boolean> c(aalu aalu2) {
        return this.a.e(aalu2.a());
    }

    public awlv<Boolean> d(aalu aalu2) {
        return this.b.a(aalu2.a());
    }

}

