/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.support.v7.view.menu.ListMenuItemView
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.BaseAdapter
 *  yu
 */
import android.support.v7.view.menu.ListMenuItemView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class aas
extends BaseAdapter {
    static final int a = yu.abc_popup_menu_item_layout;
    aat b;
    private int c = -1;
    private boolean d;
    private final boolean e;
    private final LayoutInflater f;

    public aas(aat aat2, LayoutInflater layoutInflater, boolean bl) {
        this.e = bl;
        this.f = layoutInflater;
        this.b = aat2;
        this.b();
    }

    public aat a() {
        return this.b;
    }

    /*
     * Enabled aggressive block sorting
     */
    public aax a(int n) {
        ArrayList<aax> arrayList = this.e ? this.b.l() : this.b.i();
        int n2 = n;
        if (this.c >= 0) {
            n2 = n;
            if (n >= this.c) {
                n2 = n + 1;
            }
        }
        return arrayList.get(n2);
    }

    public void a(boolean bl) {
        this.d = bl;
    }

    void b() {
        aax aax2 = this.b.r();
        if (aax2 != null) {
            ArrayList<aax> arrayList = this.b.l();
            int n = arrayList.size();
            for (int i = 0; i < n; ++i) {
                if (arrayList.get(i) != aax2) continue;
                this.c = i;
                return;
            }
        }
        this.c = -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int getCount() {
        ArrayList<aax> arrayList = this.e ? this.b.l() : this.b.i();
        if (this.c < 0) {
            return arrayList.size();
        }
        return arrayList.size() - 1;
    }

    public /* synthetic */ Object getItem(int n) {
        return this.a(n);
    }

    public long getItemId(int n) {
        return n;
    }

    public View getView(int n, View view, ViewGroup object) {
        if (view == null) {
            view = this.f.inflate(a, (ViewGroup)object, false);
        }
        object = (abk)view;
        if (this.d) {
            ((ListMenuItemView)view).a(true);
        }
        object.a(this.a(n), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        this.b();
        super.notifyDataSetChanged();
    }
}

