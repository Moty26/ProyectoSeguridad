/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 */
public final class aaiz
implements awdv<aajd> {
    static final /* synthetic */ boolean a;
    private final aaiv b;
    private final axss<aajq> c;
    private final axss<aagq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaiz.class.desiredAssertionStatus();
        a = bl;
    }

    public aaiz(aaiv aaiv2, axss<aajq> axss2, axss<aagq> axss3) {
        if (!a && aaiv2 == null) {
            throw new AssertionError();
        }
        this.b = aaiv2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aajd> a(aaiv aaiv2, axss<aajq> axss2, axss<aagq> axss3) {
        return new aaiz(aaiv2, axss2, axss3);
    }

    public aajd a() {
        return (aajd)awec.a((Object)this.b.a((aajq)((Object)this.c.get()), (aagq)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

