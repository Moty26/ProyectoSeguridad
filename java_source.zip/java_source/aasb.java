/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  awdv
 *  awea
 *  awlq
 *  axss
 *  lms
 */
public final class aasb
implements awdv<aasa> {
    static final /* synthetic */ boolean a;
    private final awdr<aasa> b;
    private final axss<aaqd> c;
    private final axss<awlq> d;
    private final axss<lms> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aasb.class.desiredAssertionStatus();
        a = bl;
    }

    public aasb(awdr<aasa> awdr2, axss<aaqd> axss2, axss<awlq> axss3, axss<lms> axss4) {
        if (!a && awdr2 == null) {
            throw new AssertionError();
        }
        this.b = awdr2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.e = axss4;
    }

    public static awdv<aasa> a(awdr<aasa> awdr2, axss<aaqd> axss2, axss<awlq> axss3, axss<lms> axss4) {
        return new aasb(awdr2, axss2, axss3, axss4);
    }

    public aasa a() {
        return (aasa)awea.a(this.b, (Object)new aasa((aaqd)this.c.get(), (awlq)this.d.get(), (lms)this.e.get()));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

