/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  ewc
 *  eyq
 */
public final class aajy
implements awdv<aakd> {
    static final /* synthetic */ boolean a;
    private final aajv b;
    private final axss<aaju> c;
    private final axss<eyq> d;
    private final axss<ewc> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aajy.class.desiredAssertionStatus();
        a = bl;
    }

    public aajy(aajv aajv2, axss<aaju> axss2, axss<eyq> axss3, axss<ewc> axss4) {
        if (!a && aajv2 == null) {
            throw new AssertionError();
        }
        this.b = aajv2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.e = axss4;
    }

    public static awdv<aakd> a(aajv aajv2, axss<aaju> axss2, axss<eyq> axss3, axss<ewc> axss4) {
        return new aajy(aajv2, axss2, axss3, axss4);
    }

    public aakd a() {
        return (aakd)((Object)awec.a((Object)((Object)this.b.a((aaju)this.c.get(), (eyq)this.d.get(), (ewc)this.e.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

