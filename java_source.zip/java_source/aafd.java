/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  ewz
 */
import android.net.Uri;

class aafd
implements aafp {
    final /* synthetic */ aafc a;

    private aafd(aafc aafc2) {
        this.a = aafc2;
    }

    @Override
    public void a(String string, String string2) {
        ((aafh)this.a.h()).a(Uri.parse((String)string2));
    }
}

