/*
 * Decompiled with CFR 0_119.
 */
interface aaoi {
    public aaox a();
}

