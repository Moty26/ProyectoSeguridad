/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agi
 */
public class aadw
extends ads {
    private final aaee i;

    public aadw(aaee aaee2) {
        this.i = aaee2;
    }

    public void g(agi agi2) {
        super.g(agi2);
        this.i.a(agi2);
    }
}

