/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agi
 *  android.graphics.Rect
 *  android.view.View
 *  android.view.ViewParent
 *  auhz
 *  auij
 *  awlj
 *  awln
 *  awlq
 *  awmh
 *  awnk
 *  awnt
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView
 *  ega
 *  hhy
 *  hpz
 *  hqg
 *  irn
 */
import android.graphics.Rect;
import android.view.View;
import android.view.ViewParent;
import com.ubercab.presidio.cards.core.card.CardsRecyclerView;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public class aadz
implements aadx {
    private final double a;
    private final CardsRecyclerView b;
    private final awlj<Map<Integer, aady>> c;
    private int d;

    public aadz(final hpz hpz2, CardsRecyclerView cardsRecyclerView, aaes aaes2) {
        this.b = cardsRecyclerView;
        this.a = hpz2.a((hqg)irn.HELIX_FEED_ANALYTICS, "viewport_min_percent", 1.0);
        long l = hpz2.a((hqg)irn.HELIX_FEED_ANALYTICS, "scroll_debounce", 1000);
        final long l2 = hpz2.a((hqg)irn.HELIX_FEED_ANALYTICS, "viewport_min_pixel_change", 0);
        this.c = awlj.merge(aaes2.b(), (awln)cardsRecyclerView.J().filter((awnt)new awnt<ega>(){

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public boolean a(ega ega2) {
                if (!hpz2.a((hqg)irn.HELIX_FEED_ANALYTICS) || !hpz2.a((hqg)irn.HELIX_FEED_SCROLL_STREAM_MIN_PIXELS)) return true;
                aadz.this.d = aadz.this.d + ega2.c();
                if ((long)aadz.this.d < l2) return false;
                aadz.this.d = 0;
                return true;
            }
        }).map(auij.a())).debounce(l, TimeUnit.MILLISECONDS).observeOn(awmh.a()).map((awnk)new awnk<auhz, Map<Integer, aady>>(){

            public Map<Integer, aady> a(auhz auhz2) {
                return aadz.this.b();
            }
        });
    }

    private hhy<agi> a(int n) {
        agi agi2 = this.b.f(n);
        if (agi2 == null) {
            return hhy.e();
        }
        return hhy.b((Object)agi2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private Map<Integer, aady> b() {
        var5_1 = new TreeMap<Integer, aady>();
        var2_2 = 0;
        while (var2_2 < this.b.getChildCount()) {
            var6_6 = new Rect();
            var7_7 = this.b.getChildAt(var2_2);
            var4_5 = var7_7.getGlobalVisibleRect(var6_6);
            if (!var4_5 || var7_7.getParent() == null) ** GOTO lbl16
            var8_8 = this.a(var2_2);
            if (!var8_8.b()) {
                kly.d("Error getting FeedCard for position", new Object[0]);
            } else {
                var3_4 = var7_7.getHeight();
                var1_3 = ((View)var7_7.getParent().getParent().getParent()).getScaleX();
                if ((double)(var1_3 = (float)(var6_6.bottom - var6_6.top) / (float)var3_4 / var1_3) >= this.a) {
                    var5_1.put(var2_2, new aady((agi)var8_8.c(), var2_2, var3_4, var1_3));
lbl16: // 2 sources:
                    if (var5_1.size() > 0 && !var4_5) {
                        return var5_1;
                    }
                }
            }
            ++var2_2;
        }
        return var5_1;
    }

    @Override
    public awlj<Map<Integer, aady>> a() {
        return this.c;
    }

}

