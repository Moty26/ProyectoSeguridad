/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  axun
 *  axuq
 *  retrofit2.Converter
 *  retrofit2.Converter$Factory
 *  retrofit2.Retrofit
 */
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import retrofit2.Converter;
import retrofit2.Retrofit;

class aabe
extends Converter.Factory {
    private aabe() {
    }

    static aabe a() {
        return new aabe();
    }

    public Converter<?, axun> requestBodyConverter(Type type, Annotation[] arrannotation, Annotation[] arrannotation2, Retrofit retrofit) {
        if (String.class == type) {
            return aabf.a();
        }
        return retrofit.nextRequestBodyConverter((Converter.Factory)this, type, arrannotation, arrannotation2);
    }

    public Converter<axuq, ?> responseBodyConverter(Type type, Annotation[] arrannotation, Retrofit retrofit) {
        return retrofit.nextResponseBodyConverter((Converter.Factory)this, type, arrannotation);
    }
}

