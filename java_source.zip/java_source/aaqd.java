/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.provider.ContactsContract
 *  android.provider.ContactsContract$Contacts
 *  android.provider.ContactsContract$Data
 *  aspo
 *  ayxi
 *  com.ubercab.presidio.contacts.model.Contact
 *  com.ubercab.presidio.contacts.model.Contact$Builder
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactDetail$Builder
 *  com.ubercab.presidio.contacts.model.ContactDetail$Type
 *  hhx
 *  hhy
 *  hie
 *  hiu
 *  hpz
 *  hqg
 */
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import com.ubercab.presidio.contacts.model.Contact;
import com.ubercab.presidio.contacts.model.ContactDetail;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class aaqd {
    private static final String[] a = new String[]{"_id", "display_name"};
    private static final String[] b = new String[]{"contact_id", "display_name", "data1", "photo_thumb_uri"};
    private static final String[] c = new String[]{"_id", "contact_id", "display_name", "mimetype", "data1", "data2"};
    private static final String[] d = new String[]{"vnd.android.cursor.item/phone_v2", "vnd.android.cursor.item/email_v2"};
    private final hpz e;
    private final aaqb f;
    private final aaqh g;

    public aaqd(hpz hpz2, aaqb aaqb2, aaqh aaqh2) {
        this.e = hpz2;
        this.f = aaqb2;
        this.g = aaqh2;
    }

    private Cursor a(Context context) {
        return context.getContentResolver().query(ContactsContract.Data.CONTENT_URI, c, "mimetype in ( ? , ? ) AND data1 is not null AND in_visible_group = 1", d, null);
    }

    private Uri a(String string) {
        try {
            Uri uri = Uri.withAppendedPath((Uri)ContentUris.withAppendedId((Uri)ContactsContract.Contacts.CONTENT_URI, (long)Long.valueOf(string)), (String)"photo");
            return uri;
        }
        catch (NumberFormatException numberFormatException) {
            ayxi.c((Throwable)numberFormatException, (String)"Failed to convert contact id %s to a Long", (Object[])new Object[]{string});
            return null;
        }
    }

    private String a(String string, String string2) {
        if (string2.equals("vnd.android.cursor.item/email_v2")) {
            return this.g.a(string);
        }
        return this.g.b(string);
    }

    private LinkedHashMap<String, Contact> a(Cursor object, Cursor cursor, aaqf object2) {
        LinkedHashMap<String, Contact> linkedHashMap = new LinkedHashMap<String, Contact>();
        object = this.a((Cursor)object, (aaqf)object2);
        int n = cursor.getColumnIndex("_id");
        int n2 = cursor.getColumnIndex("display_name");
        while (cursor.moveToNext()) {
            object2 = cursor.getString(n);
            String string = cursor.getString(n2);
            Set set = (Set)object.get(object2);
            if (object2 == null || string == null || set == null || !this.a((Contact)(object2 = Contact.builder().id((String)object2).displayName(string).photoThumbnailUri(hhy.c((Object)this.a((String)object2))).details(hie.a((Collection)set)).build()))) continue;
            linkedHashMap.put(object2.id(), (Contact)object2);
        }
        return linkedHashMap;
    }

    private Map<String, Set<ContactDetail>> a(Cursor cursor, aaqf aaqf2) {
        HashMap<String, Set<ContactDetail>> hashMap = new HashMap<String, Set<ContactDetail>>();
        int n = cursor.getColumnIndex("_id");
        int n2 = cursor.getColumnIndex("contact_id");
        int n3 = cursor.getColumnIndex("data1");
        int n4 = cursor.getColumnIndex("mimetype");
        int n5 = cursor.getColumnIndex("data2");
        int n6 = cursor.getColumnIndex("display_name");
        while (cursor.moveToNext()) {
            String string = cursor.getString(n2);
            String string2 = cursor.getString(n4);
            String string3 = this.a(cursor.getString(n3), string2);
            hhy hhy2 = hhy.e();
            if (this.e.a((hqg)aaqk.EMI_PROPAGATE_PHOTO_IN_CONTACT_DETAIL)) {
                hhy2 = hhy.c((Object)this.a(string));
            }
            if (!aaqf2.a((ContactDetail)(hhy2 = ContactDetail.builder().id(cursor.getString(n)).value(string3).photoThumbnailUri(hhy2).type(this.b(string2)).detailType(cursor.getInt(n5)).displayName(cursor.getString(n6)).build()))) continue;
            this.a(hashMap, string, (ContactDetail)hhy2);
        }
        return this.f.a(hashMap);
    }

    private void a(Map<String, Set<ContactDetail>> map, String string, ContactDetail contactDetail) {
        Set<ContactDetail> set;
        Set<ContactDetail> set2 = set = map.get(string);
        if (set == null) {
            set2 = new HashSet<ContactDetail>();
            map.put(string, set2);
        }
        set2.add(contactDetail);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Contact contact) {
        hiu hiu2 = contact.details().a();
        while (hiu2.hasNext()) {
            ContactDetail contactDetail = (ContactDetail)hiu2.next();
            if (hhx.a((Object)contact.displayName(), (Object)contactDetail.displayName())) continue;
            return false;
        }
        if (aspo.a((String)contact.displayName())) return false;
        if (contact.details().size() <= 0) return false;
        return true;
    }

    private Cursor b(Context context) {
        return context.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, a, "display_name is not null AND in_visible_group = 1", null, "display_name COLLATE NOCASE ASC");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private ContactDetail.Type b(String var1_1) {
        var2_2 = -1;
        switch (var1_1.hashCode()) {
            case -1569536764: {
                if (var1_1.equals("vnd.android.cursor.item/email_v2")) {
                    var2_2 = 0;
                }
            }
            default: {
                ** GOTO lbl11
            }
            case 684173810: 
        }
        if (var1_1.equals("vnd.android.cursor.item/phone_v2")) {
            var2_2 = 1;
        }
lbl11: // 4 sources:
        switch (var2_2) {
            default: {
                throw new IllegalArgumentException("Unexpected mime type: " + var1_1);
            }
            case 0: {
                return ContactDetail.Type.EMAIL;
            }
            case 1: 
        }
        return ContactDetail.Type.PHONE_NUMBER;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public Map<String, Contact> a(Context linkedHashMap, aaqf linkedHashMap2) {
        Cursor cursor3;
        Cursor cursor;
        Cursor cursor2;
        block11 : {
            block9 : {
                block10 : {
                    block7 : {
                        block8 : {
                            cursor3 = null;
                            cursor2 = null;
                            cursor = this.a((Context)linkedHashMap);
                            if (cursor != null) break block7;
                            cursor2 = cursor3;
                            linkedHashMap = new LinkedHashMap();
                            if (cursor == null) break block8;
                            {
                                catch (Throwable throwable) {}
                            }
                            cursor.close();
                        }
                        if (!false) return linkedHashMap;
                        throw new NullPointerException();
                    }
                    cursor2 = cursor3;
                    cursor3 = this.b((Context)linkedHashMap);
                    if (cursor3 != null) break block9;
                    cursor2 = cursor3;
                    linkedHashMap2 = new LinkedHashMap();
                    if (cursor == null) break block10;
                    cursor.close();
                }
                linkedHashMap = linkedHashMap2;
                if (cursor3 == null) return linkedHashMap;
                cursor3.close();
                return linkedHashMap2;
            }
            cursor2 = cursor3;
            linkedHashMap2 = this.a(cursor, cursor3, (aaqf)((Object)linkedHashMap2));
            if (cursor == null) break block11;
            cursor.close();
        }
        linkedHashMap = linkedHashMap2;
        if (cursor3 == null) return linkedHashMap;
        cursor3.close();
        return linkedHashMap2;
        catch (Throwable throwable) {
            void var1_3;
            cursor = null;
            if (cursor != null) {
                cursor.close();
            }
            if (cursor2 == null) throw var1_3;
            cursor2.close();
            throw var1_3;
        }
    }
}

