/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService
 *  exn
 *  exp
 *  fbz
 *  hpz
 *  hqg
 *  iwy
 */
import android.content.Context;
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService;

class aacb
implements exn {
    private final hpz a;
    private final RibActivity b;
    private final aabw c;
    private final fbz d;
    private final aacj e;

    aacb(hpz hpz2, RibActivity ribActivity, aabw aabw2, fbz fbz2, aacj aacj2) {
        this.a = hpz2;
        this.b = ribActivity;
        this.c = aabw2;
        this.d = fbz2;
        this.e = aacj2;
    }

    public void a() {
        if (this.a.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER)) {
            this.c.b();
        }
    }

    void a(Context context) {
        if (this.a.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER)) {
            String string = this.a.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER, "geofences_in_experiment");
            this.e.a(string);
            this.e.a(true);
            long l = this.a.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER, "geofences_loitering_delay_in_second", 1);
            this.e.a(l);
            l = this.a.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER, "geofences_trigger_delay_in_hours", aacj.a.longValue());
            this.e.b(l);
            try {
                aabw.a(context, GeofenceTransitionsIntentService.class, true);
                this.c.a();
                this.d.a("9acab9a9-7dab");
                return;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                kly.a((kmc)iwy.bc).b(illegalArgumentException, "Failed to start arrival notification manager", new Object[0]);
                return;
            }
        }
        this.e.a(false);
        aabw.a(context, GeofenceTransitionsIntentService.class, false);
        this.d.a("4c39ba1e-dea8");
    }

    public void a(exp exp2) {
        if (this.a.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER)) {
            this.a(this.b.getApplicationContext());
        }
    }
}

