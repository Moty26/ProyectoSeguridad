/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aaoz {
    private aaok a;
    private aaow b;

    private aaoz() {
    }

    static /* synthetic */ aaok a(aaoz aaoz2) {
        return aaoz2.a;
    }

    static /* synthetic */ aaow b(aaoz aaoz2) {
        return aaoz2.b;
    }

    public aaoj a() {
        if (this.a == null) {
            throw new IllegalStateException(aaok.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aaow.class.getCanonicalName() + " must be set");
        }
        return new aaoy(this);
    }

    public aaoz a(aaok aaok2) {
        this.a = (aaok)((Object)awec.a((Object)((Object)aaok2)));
        return this;
    }

    public aaoz a(aaow aaow2) {
        this.b = (aaow)awec.a((Object)aaow2);
        return this;
    }
}

