/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  eyq
 */
public final class aaie
implements awdv<aaij> {
    static final /* synthetic */ boolean a;
    private final aaia b;
    private final axss<aahz> c;
    private final axss<eyq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaie.class.desiredAssertionStatus();
        a = bl;
    }

    public aaie(aaia aaia2, axss<aahz> axss2, axss<eyq> axss3) {
        if (!a && aaia2 == null) {
            throw new AssertionError();
        }
        this.b = aaia2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aaij> a(aaia aaia2, axss<aahz> axss2, axss<eyq> axss3) {
        return new aaie(aaia2, axss2, axss3);
    }

    public aaij a() {
        return (aaij)((Object)awec.a((Object)((Object)this.b.a((aahz)this.c.get(), (eyq)this.d.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

