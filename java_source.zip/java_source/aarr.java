/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aarr
implements axss<hlg> {
    private final aaqy a;

    aarr(aaqy aaqy2) {
        this.a = aaqy2;
    }

    public hlg a() {
        return (hlg)awec.a((Object)this.a.t(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

