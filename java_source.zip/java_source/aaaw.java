/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewd
 *  llg
 *  llw
 *  zye
 */
public class aaaw
extends ewd<aabj, zye> {
    aaaw(zye zye2) {
        super((Object)zye2);
    }

    public aabj b() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1TtbCs0XLJ7pZ07EMQGqzCTQEB1titDp5tezdFFWJYxpU=", "enc::Nouhsb0ajXkowj8WKoOaeg8HrbuMRNSbvxGE+FBqodMlQKPQvbWAH7ac/xrE5sGQ0T3yMyIT3ykG8A1d/Q+NxXBThsgwAndsHtF8JeQtoRqSkZO2ujcSsHx422Ngoh+P", -3883737660415490358L, 7003551069234408074L, 6884581177363239875L, 7185931817553012858L, null, "enc::vwrG5IY86M5TX32dWNbiaWDZgBbjRILyxcNnHvq9cyI=", 41);
        }
        Object object = new aabh();
        object = new aabj((aabh)((Object)object), aaap.a().a((zye)this.bS_()).a(new aaay((aabh)((Object)object))).a());
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }
}

