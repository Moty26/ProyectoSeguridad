/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  auhz
 *  auif
 *  avwt
 *  awlj
 *  awlp
 *  awnk
 *  com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView
 *  eot
 *  eov
 *  eox
 *  exl
 *  gsq
 *  llg
 *  llw
 */
import android.content.Context;
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView;

public class aagn
extends exl<CobrandCardApplicationView>
implements aagu {
    private final aago a;

    public aagn(CobrandCardApplicationView cobrandCardApplicationView, aago aago2) {
        super((View)cobrandCardApplicationView);
        this.a = aago2;
        ((CobrandCardApplicationView)this.i()).a((aagu)this);
    }

    @Override
    public void a() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::WJ6hE05nLd94rWOcNQ/foez+wVtu/lLmKxbeyMsG360=", 7963966960560010407L, 8509553950572382509L, 6577556923684017193L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 44);
        }
        this.a.f();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void b() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::3xJKj48S1cxlfNooymkT0Zj9epfl0EzUIDnxsmK94XA=", 7963966960560010407L, 8509553950572382509L, 4074728006917608332L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 48);
        }
        ((CobrandCardApplicationView)this.i()).c();
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::mHjNXpidAhZ1UI8Bj9wOhNESYLsWWaNS+Ga0pIiMDWk=", 7963966960560010407L, 8509553950572382509L, 8792004404122595672L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 38);
        }
        super.f();
        this.j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void g() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::LIu0KBS4aHqYF90tspXATwkCV1XhZpU1szXsfmGftnU=", 7963966960560010407L, 8509553950572382509L, -5669698541601424854L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 32) : null;
        super.g();
        ((CobrandCardApplicationView)this.i()).a(null);
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::I1Tlbs0wsYx+B7wT0YBkoRMjS001Jx9ZxITDmlQQibw=", 7963966960560010407L, 8509553950572382509L, -6090035429947012084L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 52);
        }
        ((eov)((CobrandCardApplicationView)this.i()).b().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                gsq.b((Context)((CobrandCardApplicationView)aagn.this.i()).getContext(), (View)aagn.this.i());
                aagn.this.k();
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void k() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::Iz+INwt3TXY78KcnWq0/d1x9+v+fL1nT+dJDYfUtesY=", 7963966960560010407L, 8509553950572382509L, 5012718550285852219L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 64);
        }
        ((eov)((CobrandCardApplicationView)this.i()).d().c().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                aagn.this.a.d();
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void l() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm50OMHHgQiSOKcCG8nFZc9Y=", "enc::/mkgRdeC7MGzqtPn5fpT5eVx+g83yQqF9WTI9cTP43w=", 7963966960560010407L, 8509553950572382509L, 8309630610015005788L, 1953763409102406465L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcGri6N5sdimKYfxDnbHna6ngtbLArVRvZb2UOEjco/3O", 76);
        }
        ((CobrandCardApplicationView)this.i()).e();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

