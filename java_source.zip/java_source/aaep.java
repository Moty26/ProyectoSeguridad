/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.GestureDetector
 *  android.view.GestureDetector$SimpleOnGestureListener
 *  android.view.MotionEvent
 *  auhz
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView$1
 */
import android.view.GestureDetector;
import android.view.MotionEvent;
import com.ubercab.presidio.cards.core.card.CardsRecyclerView;

public class aaep
extends GestureDetector.SimpleOnGestureListener {
    final /* synthetic */ CardsRecyclerView a;

    private aaep(CardsRecyclerView cardsRecyclerView) {
        this.a = cardsRecyclerView;
    }

    public /* synthetic */ aaep(CardsRecyclerView cardsRecyclerView, CardsRecyclerView.1 var2_2) {
        this(cardsRecyclerView);
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        CardsRecyclerView.a((CardsRecyclerView)this.a).a((Object)auhz.a);
        return super.onSingleTapUp(motionEvent);
    }
}

