/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awdr
 *  axss
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  ewj
 *  ewo
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;

public final class aagm
implements awdr<aagl> {
    static final /* synthetic */ boolean a;
    private final axss<aagn> b;
    private final axss<CobrandCardClient<apap>> c;
    private final axss<Boolean> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aagm.class.desiredAssertionStatus();
        a = bl;
    }

    public aagm(axss<aagn> axss2, axss<CobrandCardClient<apap>> axss3, axss<Boolean> axss4) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
    }

    public static awdr<aagl> a(axss<aagn> axss2, axss<CobrandCardClient<apap>> axss3, axss<Boolean> axss4) {
        return new aagm(axss2, axss3, axss4);
    }

    public void a(aagl aagl2) {
        if (aagl2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aagl2, this.b);
        aagl2.a = (CobrandCardClient)this.c.get();
        aagl2.b = (aagn)this.b.get();
        aagl2.c = (Boolean)this.d.get();
    }
}

