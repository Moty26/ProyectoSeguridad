/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.personalinfo.CobrandCardPersonalInfoView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.personalinfo.CobrandCardPersonalInfoView;

public class aais
extends exk<CobrandCardPersonalInfoView, aajf, aaiw> {
    public aais(aaiw aaiw2) {
        super((Object)aaiw2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aajf b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wg+kToP7++FxXPEs7JlN+N+", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2R1PLk5O/qE8q7J20F2raPlZLQd6a5FAvuXUpOS4R+AtDlmHx/s3+3tEIkEdJx7opQgTis6e+KTdyUkuI/iuM4/xAzf41lUglNv8KyL1cKn2sp/fVrCQEugHujf6c9PCy", -874676037324681323L, 6083922922054035335L, 5085736361568431064L, 7185931817553012858L, null, "enc::GGnQ/DmzriVCDvUcUBgL3V/nWG1mVTRsV/9m4+pdThMjd30NCQaTiw5yZm+CMxj9", 50) : null;
        object = (CobrandCardPersonalInfoView)this.a_((ViewGroup)object);
        aajb aajb2 = new aajb();
        object = aajh.g().a((aaiw)this.bS_()).a(new aaiv(aajb2, (CobrandCardPersonalInfoView)object)).a().f();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected CobrandCardPersonalInfoView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wg+kToP7++FxXPEs7JlN+N+", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zMmvnVZyy2ZVqacok3gBZFu30XRMkXBiIIK6BtIQdHQbBlmKIXbj00fnESdcCqtm8DWZoS2zU/fU7mGLigyNy9KosAI3LNm1+XazE4rs2Gm0=", -874676037324681323L, 6083922922054035335L, -6156749920277842149L, 7185931817553012858L, null, "enc::GGnQ/DmzriVCDvUcUBgL3V/nWG1mVTRsV/9m4+pdThMjd30NCQaTiw5yZm+CMxj9", 61) : null;
        layoutInflater = (CobrandCardPersonalInfoView)layoutInflater.inflate(aafw.ub__cobrandcard_personal_info, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

