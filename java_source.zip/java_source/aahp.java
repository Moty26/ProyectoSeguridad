/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  ewc
 *  ewj
 *  ewq
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public final class aahp
implements aahd {
    static final /* synthetic */ boolean a;
    private axss<aahv> b;
    private axss<aagq> c;
    private axss<aahl> d;
    private awdr<aahj> e;
    private axss<aahd> f;
    private axss<eyq> g;
    private axss<aahn> h;
    private axss<OfferResponse> i;
    private axss<ewc> j;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aahp.class.desiredAssertionStatus();
        a = bl;
    }

    private aahp(aahq aahq2) {
        if (!a && aahq2 == null) {
            throw new AssertionError();
        }
        this.a(aahq2);
    }

    private void a(aahq aahq2) {
        this.b = awdu.a(aahg.a(aahq.a(aahq2)));
        this.c = new aahs(aahq.b(aahq2));
        this.d = awdu.a(aahh.a(aahq.a(aahq2), this.b, this.c));
        this.e = aahk.a(this.d, this.c);
        this.f = awdw.a((Object)this);
        this.g = new aahu(aahq.b(aahq2));
        this.h = awdu.a(aahi.a(aahq.a(aahq2), this.f, this.g));
        this.i = new aaht(aahq.b(aahq2));
        this.j = new aahr(aahq.b(aahq2));
    }

    public static aahq b() {
        return new aahq(null);
    }

    public /* synthetic */ ewq O_() {
        return this.d();
    }

    @Override
    public aahn a() {
        return (aahn)((Object)this.h.get());
    }

    public void a(aahj aahj2) {
        this.e.a((Object)aahj2);
    }

    public aahl d() {
        return (aahl)this.d.get();
    }

    @Override
    public aagq f() {
        return (aagq)this.c.get();
    }

    @Override
    public eyq g() {
        return (eyq)this.g.get();
    }

    @Override
    public OfferResponse h() {
        return (OfferResponse)this.i.get();
    }

    @Override
    public ewc i() {
        return (ewc)this.j.get();
    }

}

