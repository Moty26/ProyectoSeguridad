/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  yzl
 *  yzp
 *  zpr
 *  zqk
 *  zqq
 *  zye
 */
import java.util.HashMap;
import java.util.Map;

class aabl
implements zqk {
    public static final zpr a = zpr.a;
    private final Map<String, String> b = new HashMap<String, String>();
    private final zye c;

    aabl(zye zye2) {
        this.c = zye2;
        this.b.put("auth_source", a.name());
        this.b.put("social_provider", "line");
    }

    public int a() {
        return 50003;
    }

    public int b() {
        return yzp.login_with_line;
    }

    public int c() {
        return yzp.login_with_line_description;
    }

    public Map<String, String> d() {
        return this.b;
    }

    public int e() {
        return yzl.ub__line_logo;
    }

    public zqq f() {
        return new aabk(this.c);
    }

    public int g() {
        return 0;
    }
}

