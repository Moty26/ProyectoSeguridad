/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView
 *  ewc
 *  ewj
 *  ewk
 *  eyq
 */
import android.view.View;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView;

public class aajv
extends ewk<aajz, CobrandCardReviewView> {
    public aajv(aajz aajz2, CobrandCardReviewView cobrandCardReviewView) {
        super((ewj)aajz2, (View)cobrandCardReviewView);
    }

    aakb a(OfferResponse offerResponse) {
        return new aakb((CobrandCardReviewView)this.c(), (aakc)this.d(), offerResponse);
    }

    aakd a(aaju aaju2, eyq eyq2, ewc ewc2) {
        return new aakd((CobrandCardReviewView)this.c(), (aajz)this.d(), aaju2, eyq2, ewc2);
    }
}

