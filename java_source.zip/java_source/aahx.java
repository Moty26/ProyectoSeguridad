/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView;

public class aahx
extends exk<CobrandCardFinancialInfoView, aaij, aaib> {
    public aahx(aaib aaib2) {
        super((Object)aaib2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aaij b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqGgG+LbWgF2gEkSc8yHXsnC9zsm15j3nkdWTkbwEuzOb", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2R1PLk5O/qE8q7J20F2raPlZLQd6a5FAvuXUpOS4R+AsZ0BA+ZcmYEeaQ44zBpTXl3mHnr8qsaHiYYehP+yXaPOHdlMRUfouZ1GC3jL5oAtk=", -3295476322921135584L, 4505779811183178691L, 8416667098904977649L, 7185931817553012858L, null, "enc::atEfgvPYLktmgAD18YGYTcYthkbcPF4BuiiA/+gFAKppufjRyTHfX3ickiFXTI8/", 46) : null;
        object = (CobrandCardFinancialInfoView)this.a_((ViewGroup)object);
        aaif aaif2 = new aaif();
        object = aaim.b().a((aaib)this.bS_()).a(new aaia(aaif2, (CobrandCardFinancialInfoView)object)).a().a();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected CobrandCardFinancialInfoView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqGgG+LbWgF2gEkSc8yHXsnC9zsm15j3nkdWTkbwEuzOb", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zMmvnVZyy2ZVqacok3gBZFnfbpgpjlvqjQu+rbNSov8r2SZ/4fSBamwsgSuip3ZNqukutYOxjDRfZaXVL2QimSFo6O3p9Wk+wC4APtq5x16M=", -3295476322921135584L, 4505779811183178691L, -7627813203045382858L, 7185931817553012858L, null, "enc::atEfgvPYLktmgAD18YGYTcYthkbcPF4BuiiA/+gFAKppufjRyTHfX3ickiFXTI8/", 57) : null;
        layoutInflater = (CobrandCardFinancialInfoView)layoutInflater.inflate(aafw.ub__cobrandcard_financial_info, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

