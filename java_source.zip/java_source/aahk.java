/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  ewj
 *  ewo
 */
public final class aahk
implements awdr<aahj> {
    static final /* synthetic */ boolean a;
    private final axss<aahl> b;
    private final axss<aagq> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aahk.class.desiredAssertionStatus();
        a = bl;
    }

    public aahk(axss<aahl> axss2, axss<aagq> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdr<aahj> a(axss<aahl> axss2, axss<aagq> axss3) {
        return new aahk(axss2, axss3);
    }

    public void a(aahj aahj2) {
        if (aahj2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aahj2, this.b);
        aahj2.a = (aahl)this.b.get();
        aahj2.b = (aagq)this.c.get();
    }
}

