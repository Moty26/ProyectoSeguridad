/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  atvd
 *  awec
 *  axss
 */
class aamn
implements axss<atvd> {
    private final aamc a;

    aamn(aamc aamc2) {
        this.a = aamc2;
    }

    public atvd a() {
        return (atvd)awec.a((Object)this.a.z(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

