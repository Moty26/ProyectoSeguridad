/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  gss
 */
import java.util.Locale;

public class aaqh {
    private String a;

    public aaqh(String string) {
        this.a = string;
    }

    public String a(String string) {
        return string.toLowerCase(Locale.US);
    }

    public String b(String string) {
        return hhz.a(gss.c((String)string, (String)this.a));
    }
}

