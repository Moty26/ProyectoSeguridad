/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.ui.core.UCardView
 *  ewj
 *  ewl
 *  ewm
 *  exm
 *  llg
 *  llw
 */
import android.view.View;
import com.ubercab.ui.core.UCardView;

public class aaek<InnerView extends View, CardContainer extends UCardView, Interactor extends aaeh, Component extends ewm>
extends exm<CardContainer, Interactor, Component> {
    private final InnerView a;

    public aaek(CardContainer CardContainer, Interactor Interactor, Component Component) {
        super(CardContainer, Interactor, Component);
        this.a = CardContainer.findViewById(aaef.a);
    }

    protected final InnerView m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKswILl1EyH4IGGnbMDJdFbQ1chKHuDROX6nBp5Ngeopb", "enc::ADzEb5bR3IrAgRA1YEswpphEgT5OTo2ZYK0+eJtS1sa6oMBMLgygNd8GVXmtMoL4", 2366547142336553411L, 8096119944931649274L, -8829953378568083307L, 4285526870058266813L, null, "enc::uyXVvAvmrwsif5292jOERw==", 32);
        }
        InnerView InnerView = this.a;
        if (llw2 != null) {
            llw2.i();
        }
        return InnerView;
    }
}

