/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.View
 *  android.view.View$OnClickListener
 *  aspo
 *  awlj
 *  awln
 *  awnf
 *  com.ubercab.presidio.contacts.model.Contact
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactPickerV2Config
 *  com.ubercab.presidio.contacts.model.ContactSelection
 *  eih
 *  hhx
 *  hie
 *  hif
 *  hik
 *  hiu
 *  hpz
 *  hqg
 */
import android.content.res.Resources;
import android.view.View;
import com.ubercab.presidio.contacts.model.Contact;
import com.ubercab.presidio.contacts.model.ContactDetail;
import com.ubercab.presidio.contacts.model.ContactPickerV2Config;
import com.ubercab.presidio.contacts.model.ContactSelection;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

public class aash {
    private final ContactPickerV2Config a;
    private final aasi b;
    private final Resources c;
    private final hpz d;
    private final aavl e;
    private final eih<aary> f = eih.a();
    private final eih<ContactSelection> g = eih.a();

    public aash(ContactPickerV2Config contactPickerV2Config, aasi aasi2, Resources resources, aavl aavl2, hpz hpz2) {
        this.a = contactPickerV2Config;
        this.e = aavl2;
        this.b = aasi2;
        this.c = resources;
        this.d = hpz2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private hie<aatb> a(aary aary2, ContactSelection contactSelection) {
        boolean bl = true;
        hif hif2 = new hif();
        boolean bl2 = !aspo.a((String)aary2.c);
        if (bl2 || !this.a.showHeaders()) {
            bl = false;
        }
        if (!bl2 && this.a.shouldShowSuggestedContacts() && this.d.a((hqg)aaqk.CONTACTS_SYNC)) {
            if (aary2.d && aary2.b.isEmpty()) {
                hif2.a((Object)new aasl(this.c.getString(aaqs.ub__contact_picker_suggested_contacts)));
                hif2.a((Object)new aasw());
            } else if (!aary2.b.isEmpty()) {
                hif2.a((Object)new aasl(this.c.getString(aaqs.ub__contact_picker_suggested_contacts)));
                hif2.a((Object)new aasy(aary2.d));
                this.e.a(aary2, contactSelection);
            }
        }
        this.a(aary2, contactSelection, hif2, bl);
        this.a(aary2, hif2);
        return hif2.a();
    }

    private String a(Contact contact) {
        return contact.displayName().substring(0, 1).toLowerCase(Locale.getDefault());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(aary var1_1, ContactSelection var2_2, hif<aatb> var3_3, boolean var4_4) {
        var6_5 = null;
        var7_6 = var1_1.a.values().iterator();
        while (var7_6.hasNext() != false) {
            var8_8 = var7_6.next();
            var1_1 = var6_5;
            if (!var4_4) ** GOTO lbl12
            if (var6_5 == null) ** GOTO lbl-1000
            var1_1 = var6_5;
            if (!hhx.a((Object)var6_5, (Object)this.a(var8_8))) lbl-1000: // 2 sources:
            {
                var1_1 = this.a(var8_8);
                var3_3.a((Object)new aasl((String)var1_1));
            }
lbl12: // 4 sources:
            var6_5 = var8_8.details().a();
            while (var6_5.hasNext()) {
                var9_9 = (ContactDetail)var6_5.next();
                var10_10 = new View.OnClickListener(){

                    public void onClick(View view) {
                        aash.this.b.a(var9_9);
                    }
                };
                var5_7 = this.a.shouldShowProfilePicture() != false ? 0 : 8;
                var3_3.a((Object)new aasd(var8_8, var9_9, var10_10, var5_7, var2_2.getContactDetails().contains((Object)var9_9), this.a.shouldShowDetailType()));
            }
            var6_5 = var1_1;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(final aary aary2, hif<aatb> hif2) {
        aaqf aaqf2 = this.a.contactFilter();
        if (!aspo.a((String)aary2.c) && aaqf2.a(aary2.c)) {
            hif2.a((Object)new aasq(aaqf2.b(aary2.c), this.b(aary2), new View.OnClickListener(){

                public void onClick(View view) {
                    aash.this.b.a_(aary2.c);
                }
            }));
            return;
        } else {
            if (!this.a.shouldShowInvalidNumber() || aaqf2.a(aary2.c) || aspo.a((String)aary2.c)) return;
            {
                hif2.a((Object)new aasn(aaqf2.b(aary2.c), this.c(aary2)));
                return;
            }
        }
    }

    private aast b(aary aary2) {
        if (this.a.contactFilter().a(aary2.c)) {
            return aast.b;
        }
        return aast.a;
    }

    private aaso c(aary aary2) {
        if (this.a.contactFilter().a(aary2.c)) {
            return aaso.b;
        }
        return aaso.a;
    }

    public awlj<hie<aatb>> a() {
        return awlj.combineLatest((awln)this.f.hide(), (awln)this.g.startWith((Object)ContactSelection.EMPTY), (awnf)new awnf<aary, ContactSelection, hie<aatb>>(){

            public hie<aatb> a(aary aary2, ContactSelection contactSelection) throws Exception {
                return aash.this.a(aary2, contactSelection);
            }
        });
    }

    public void a(aary aary2) {
        this.f.a((Object)aary2);
    }

    public void a(ContactSelection contactSelection) {
        this.g.a((Object)contactSelection);
    }

}

