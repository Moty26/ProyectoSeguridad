/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  ewc
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public interface aajw {
    public aagq e();

    public eyq f();

    public OfferResponse g();

    public ewc h();
}

