/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  axss
 *  eqc
 *  hpz
 */
public final class aale
implements awdv<aald> {
    static final /* synthetic */ boolean a;
    private final axss<hpz> b;
    private final axss<aakv> c;
    private final axss<aakx> d;
    private final axss<eqc> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aale.class.desiredAssertionStatus();
        a = bl;
    }

    public aale(axss<hpz> axss2, axss<aakv> axss3, axss<aakx> axss4, axss<eqc> axss5) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
    }

    public static awdv<aald> a(axss<hpz> axss2, axss<aakv> axss3, axss<aakx> axss4, axss<eqc> axss5) {
        return new aale(axss2, axss3, axss4, axss5);
    }

    public aald a() {
        return new aald(this.b, this.c, this.d, this.e);
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

