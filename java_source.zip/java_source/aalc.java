/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auif
 *  awlj
 *  awlp
 *  awlq
 *  awlv
 *  awlx
 *  awmh
 *  awnk
 *  axrg
 *  ayxi
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState
 *  eot
 *  eov
 *  eox
 *  epb
 *  epd
 *  eqc
 *  eqr
 *  exn
 *  exp
 *  hhy
 */
import com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState;

class aalc
implements exn {
    private final aakv a;
    private final aakx b;
    private final CommuteOptInState c = CommuteOptInState.builder().build();
    private final eqc d;

    aalc(aakv aakv2, aakx aakx2, eqc eqc2) {
        this.a = aakv2;
        this.b = aakx2;
        this.d = eqc2;
    }

    public void a() {
    }

    public void a(exp exp2) {
        ((epd)this.d.e((eqr)aaku.a).a(awmh.a()).j((awnk)new epb((eox)exp2))).a((awlx)new axrg<hhy<CommuteOptInState>>(){

            public void a(hhy<CommuteOptInState> hhy2) {
                if (hhy2.b()) {
                    aalc.this.a.a((CommuteOptInState)hhy2.c());
                    return;
                }
                aalc.this.a.a(aalc.this.c);
            }

            public /* synthetic */ void a_(Object object) {
                this.a((hhy)object);
            }

            public void onError(Throwable throwable) {
                ayxi.c((Throwable)throwable, (String)"Could not read commute opt-in state from key-value store.", (Object[])new Object[0]);
                aalc.this.a.a(aalc.this.c);
            }
        });
        ((eov)this.b.a().observeOn(awmh.a()).skip(1).distinctUntilChanged().to((awnk)new eot((eox)exp2))).a((awlp)new auif<CommuteOptInState>(){

            public void a(CommuteOptInState commuteOptInState) throws Exception {
                aalc.this.d.a((eqr)aaku.a, (Object)commuteOptInState);
            }
        });
    }

}

