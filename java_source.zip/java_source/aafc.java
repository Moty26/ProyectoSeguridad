/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  apap
 *  auih
 *  awlq
 *  awlv
 *  awlx
 *  awmh
 *  awnk
 *  com.uber.model.core.generated.crack.cobrandcard.ApplicationPrefill
 *  com.uber.model.core.generated.crack.cobrandcard.LinkText
 *  com.uber.model.core.generated.crack.cobrandcard.Offer
 *  com.uber.model.core.generated.crack.cobrandcard.OfferBenefit
 *  com.uber.model.core.generated.crack.cobrandcard.OfferRequest
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.OfferErrors
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 *  com.ubercab.presidio.cobrandcard.data.LinkTextUtils
 *  ejv
 *  eop
 *  epb
 *  epd
 *  esi
 *  ewe
 *  ewj
 *  ewz
 *  hie
 *  llg
 *  llw
 */
import android.content.Context;
import android.view.View;
import com.uber.model.core.generated.crack.cobrandcard.ApplicationPrefill;
import com.uber.model.core.generated.crack.cobrandcard.LinkText;
import com.uber.model.core.generated.crack.cobrandcard.Offer;
import com.uber.model.core.generated.crack.cobrandcard.OfferBenefit;
import com.uber.model.core.generated.crack.cobrandcard.OfferRequest;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.OfferErrors;
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;
import com.ubercab.presidio.cobrandcard.data.LinkTextUtils;
import java.util.List;

public class aafc
extends ewj<aaff, aafh>
implements aafg {
    CobrandCardClient<apap> a;
    aaff b;
    private aafo c;
    private aafo d;
    private OfferResponse e;
    private aafd f;

    public aafc() {
        this.f = new aafd(this, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(OfferResponse offerResponse) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::hL+wUa02KqjaLt9qqGYZtu9QiviwnIYkMimQR2DoKENgV7D7VMVOgA2dLWhD9L/DNvBUsbVT0lg65Av2dFGl0jsyR0FY0soCeWFMkHEcSx5h7Wg5EOZWiPPEJcqwSSiv", 3892689495945724297L, 7692958066287709848L, -5194536057813267992L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 104) : null;
        this.e = offerResponse;
        Offer offer = offerResponse.offer();
        this.b.a(offer.imageUrl(), offer.title(), offer.subtitle(), "Rewards<sup><small>\u2020</small></sup>", (CharSequence)LinkTextUtils.a((LinkText)offer.benefitsFooter(), (aako)this.f), "Additional Benefits<sup><small>\u2020</small></sup>", (CharSequence)LinkTextUtils.a((LinkText)offer.terms(), (aako)this.f));
        if (this.c != null) {
            this.c.a((List<OfferBenefit>)offer.benefits());
        }
        if (this.d != null) {
            this.d.a((List<OfferBenefit>)offer.additionalBenefits());
        }
        offerResponse.applicationFooter();
        offerResponse.prefill();
        offerResponse.showWebview();
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::6l1IdRZIw2hCeJZ5+MHkLtRBr1XvfUY25oni4AyjA5Q=", 3892689495945724297L, 7692958066287709848L, 1985936714632279494L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 81);
        }
        OfferRequest offerRequest = OfferRequest.builder().build();
        ((epd)this.a.offer(offerRequest).a(awmh.a()).j((awnk)new epb((eop)this))).a((awlx)new auih<esi<OfferResponse, OfferErrors>>(){

            public void a(esi<OfferResponse, OfferErrors> offerResponse) {
                if ((offerResponse = (OfferResponse)offerResponse.a()) != null) {
                    aafc.this.a(offerResponse);
                    return;
                }
                aafc.this.n();
            }

            public /* synthetic */ void b(Object object) throws Exception {
                this.a((esi)object);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void n() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::AvPafNPZogzAg8rqwR2YMCFNvDALna+DA7k+sYND4bE=", 3892689495945724297L, 7692958066287709848L, 1668943605731431968L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 100);
        }
        this.b.b();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ewe ewe2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", 3892689495945724297L, 7692958066287709848L, -8133349418566419115L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 44) : null;
        super.a(ewe2);
        ewe2 = ejv.a((Context)((CobrandCardOfferView)((aafh)this.h()).h()).getContext());
        this.b.a(this);
        this.c = new aafo((ejv)ewe2, this.f);
        this.d = new aafo((ejv)ewe2, this.f);
        this.b.a(this.c, this.d);
        this.b.a();
        this.m();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::QExOT3iQNYGYzpxyxg/bCQpm9jgUAfwiRMkWrf3wQkY=", 3892689495945724297L, 7692958066287709848L, 4597636907434080096L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 67);
        }
        ((aafh)this.h()).a(this.e);
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void e() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::1fXBJFw7jkdq+dlipnkY/z9PlGRtivmMYbMpnbi+uc4=", 3892689495945724297L, 7692958066287709848L, 8646112995144922114L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 72);
        }
        ((aafh)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::WJ6hE05nLd94rWOcNQ/foez+wVtu/lLmKxbeyMsG360=", 3892689495945724297L, 7692958066287709848L, 6577556923684017193L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 77);
        }
        ((aafh)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void j() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfttV1HqMJ9/omANSx2tm4Ltg==", "enc::WD/7tN4wkeSoBb9ZkEP7FDkPfmQPXKZAVeV40pbq6/I=", 3892689495945724297L, 7692958066287709848L, -6590376132571480863L, 6165381391493657874L, null, "enc::AV00HDwcdxyM9iF6Lm5WD57JHAAlPr8lq1OTboCUo2k=", 60) : null;
        this.b.a(null);
        super.j();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

