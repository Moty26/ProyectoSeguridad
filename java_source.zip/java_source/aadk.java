/*
 * Decompiled with CFR 0_119.
 */
public interface aadk {
    public void a(float var1);

    public void b(float var1);
}

