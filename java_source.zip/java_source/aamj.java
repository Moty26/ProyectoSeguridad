/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  awec
 */
import android.view.ViewGroup;

final class aamj
implements aalo {
    private aamc a;
    private aalx b;
    private ViewGroup c;
    private aalu d;
    private aamb e;

    private aamj() {
    }

    static /* synthetic */ aalu a(aamj aamj2) {
        return aamj2.d;
    }

    static /* synthetic */ aamb b(aamj aamj2) {
        return aamj2.e;
    }

    static /* synthetic */ ViewGroup c(aamj aamj2) {
        return aamj2.c;
    }

    static /* synthetic */ aamc d(aamj aamj2) {
        return aamj2.a;
    }

    static /* synthetic */ aalx e(aamj aamj2) {
        return aamj2.b;
    }

    @Override
    public aaln a() {
        if (this.a == null) {
            throw new IllegalStateException(aamc.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aalx.class.getCanonicalName() + " must be set");
        }
        if (this.c == null) {
            throw new IllegalStateException(ViewGroup.class.getCanonicalName() + " must be set");
        }
        if (this.d == null) {
            throw new IllegalStateException(aalu.class.getCanonicalName() + " must be set");
        }
        if (this.e == null) {
            throw new IllegalStateException(aamb.class.getCanonicalName() + " must be set");
        }
        return new aami(this);
    }

    @Override
    public /* synthetic */ aalo a(aalu aalu2) {
        return this.b(aalu2);
    }

    @Override
    public /* synthetic */ aalo a(aalx aalx2) {
        return this.b(aalx2);
    }

    @Override
    public /* synthetic */ aalo a(aamb aamb2) {
        return this.b(aamb2);
    }

    @Override
    public /* synthetic */ aalo a(aamc aamc2) {
        return this.b(aamc2);
    }

    @Override
    public /* synthetic */ aalo a(ViewGroup viewGroup) {
        return this.b(viewGroup);
    }

    public aamj b(aalu aalu2) {
        this.d = (aalu)awec.a((Object)aalu2);
        return this;
    }

    public aamj b(aalx aalx2) {
        this.b = (aalx)awec.a((Object)aalx2);
        return this;
    }

    public aamj b(aamb aamb2) {
        this.e = (aamb)awec.a((Object)aamb2);
        return this;
    }

    public aamj b(aamc aamc2) {
        this.a = (aamc)awec.a((Object)aamc2);
        return this;
    }

    public aamj b(ViewGroup viewGroup) {
        this.c = (ViewGroup)awec.a((Object)viewGroup);
        return this;
    }
}

