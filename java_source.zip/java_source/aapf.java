/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awec
 *  axss
 *  esc
 */
class aapf
implements axss<esc<apap>> {
    private final aaow a;

    aapf(aaow aaow2) {
        this.a = aaow2;
    }

    public esc<apap> a() {
        return (esc)awec.a(this.a.h(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

