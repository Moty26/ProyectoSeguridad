/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.content.IntentSender$SendIntentException
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  awlj
 *  awnk
 *  ayxi
 *  bcs
 *  bdu
 *  bdw
 *  bdx
 *  bfm
 *  bgl
 *  com.google.android.gms.auth.api.signin.GoogleSignInAccount
 *  com.google.android.gms.common.ConnectionResult
 *  com.google.android.gms.common.api.Status
 *  zpr
 *  zqu
 *  zqv
 *  zyc
 */
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import java.util.Locale;

class aaai
implements zyc {
    private final zqv a = new zqv();
    private final Context b;
    private final bgl c;

    aaai(Context context, bgl bgl2) {
        this.b = context;
        this.c = bgl2;
    }

    private awlj<zqu> a(String string, Throwable throwable) {
        return awlj.just((Object)this.a.a("google", "googleToken", aaan.a, string, throwable));
    }

    static String a(Context object) {
        try {
            object = object.getPackageManager().getApplicationInfo(object.getPackageName(), 128);
            if (object.metaData != null) {
                object = object.metaData.getString("com.google.CLIENT_ID");
                return object;
            }
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            ayxi.e((String)"Unable to find Google API Key!", (Object[])new Object[0]);
        }
        return null;
    }

    private String a(Status status) {
        if (status.a() != null) {
            return status.a();
        }
        return bdx.a((int)status.g());
    }

    private void a(bdw bdw2) {
        Status status = bdw2.b();
        if (bdw2.c()) {
            kly.b("Google Login: Success!", new Object[0]);
            return;
        }
        kly.d(String.format(Locale.getDefault(), "Google Login: Error - (Code: %d) (Interrupted: %b) (Cancelled: %b) (Has Resolution: %b) %s", status.g(), status.f(), status.e(), status.c(), status.a()), new Object[0]);
    }

    static void b(ConnectionResult connectionResult) {
        kly.d(String.format(Locale.getDefault(), "Google Login: Connection Error - (Code: %d) (Message: %s) (Has Resolution: %b)", connectionResult.c(), connectionResult.e(), connectionResult.a()), new Object[0]);
    }

    static boolean b(Context context) {
        if (bfm.a().a(context) == 0) {
            return true;
        }
        return false;
    }

    private String c(ConnectionResult connectionResult) {
        if (connectionResult.e() != null) {
            return connectionResult.e();
        }
        return bfm.a().b(connectionResult.c());
    }

    public awlj<zqu> a(Intent intent) {
        if (intent == null) {
            return this.a("No data returned from Google!", null);
        }
        intent = bcs.h.a(intent);
        kly.b("Google Login: Started parsing result.", new Object[0]);
        return awlj.just((Object)intent).flatMap((awnk)new awnk<bdw, awlj<zqu>>(){

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public awlj<zqu> a(bdw object) {
                aaai.this.a((bdw)object);
                if (object.c() && object.a() != null) {
                    kly.b("Google Login: Token found. Green across the board.", new Object[0]);
                    object = object.a().b();
                    return awlj.just((Object)aaai.this.a.a("google", 60000, "googleToken", (String)object, aaan.a));
                }
                if ((object = object.b()).c()) {
                    try {
                        kly.b("Google Login: Launching resolution for ." + object.g(), new Object[0]);
                        object.a((Activity)aaai.this.b, 50002);
                    }
                    catch (IntentSender.SendIntentException sendIntentException) {
                        aaai aaai2 = aaai.this;
                        if (sendIntentException.getMessage() == null) {
                            object = "Failed to launch resolution";
                            do {
                                return aaai2.a((String)object, (Throwable)sendIntentException);
                                break;
                            } while (true);
                        }
                        object = sendIntentException.getMessage();
                        return aaai2.a((String)object, (Throwable)sendIntentException);
                    }
                    kly.b("Google Login: Started resolution. Sending empty result.", new Object[0]);
                    return awlj.empty();
                }
                if (object.g() != 12501) {
                    kly.b("Google Login: Error logging in.", new Object[0]);
                    return aaai.this.a(aaai.this.a((Status)object), null);
                }
                kly.b("Google Login: Cancelled Login.", new Object[0]);
                return awlj.just((Object)aaai.this.a());
            }
        });
    }

    public zqu a() {
        return this.a.a("google", "googleToken", aaan.a);
    }

    zqu a(ConnectionResult connectionResult) {
        return this.a.a("google", "googleToken", aaan.a, this.c(connectionResult));
    }

    public Intent b() {
        return bcs.h.a(this.c);
    }

}

