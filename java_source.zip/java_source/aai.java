/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.view.ActionProvider
 *  android.view.ContextMenu
 *  android.view.ContextMenu$ContextMenuInfo
 *  android.view.KeyEvent
 *  android.view.MenuItem
 *  android.view.MenuItem$OnActionExpandListener
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.SubMenu
 *  android.view.View
 *  le
 *  mk
 *  ne
 *  qs
 */
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class aai
implements ne {
    private final int a;
    private final int b;
    private final int c;
    private final int d;
    private CharSequence e;
    private CharSequence f;
    private Intent g;
    private char h;
    private int i = 4096;
    private char j;
    private int k = 4096;
    private Drawable l;
    private int m = 0;
    private Context n;
    private MenuItem.OnMenuItemClickListener o;
    private CharSequence p;
    private CharSequence q;
    private ColorStateList r = null;
    private PorterDuff.Mode s = null;
    private boolean t = false;
    private boolean u = false;
    private int v = 16;

    public aai(Context context, int n, int n2, int n3, int n4, CharSequence charSequence) {
        this.n = context;
        this.a = n2;
        this.b = n;
        this.c = n3;
        this.d = n4;
        this.e = charSequence;
    }

    private void b() {
        if (this.l != null && (this.t || this.u)) {
            this.l = mk.g((Drawable)this.l);
            this.l = this.l.mutate();
            if (this.t) {
                mk.a((Drawable)this.l, (ColorStateList)this.r);
            }
            if (this.u) {
                mk.a((Drawable)this.l, (PorterDuff.Mode)this.s);
            }
        }
    }

    public ne a(int n) {
        throw new UnsupportedOperationException();
    }

    public ne a(View view) {
        throw new UnsupportedOperationException();
    }

    public ne a(CharSequence charSequence) {
        this.p = charSequence;
        return this;
    }

    public ne a(qs qs2) {
        throw new UnsupportedOperationException();
    }

    public qs a() {
        return null;
    }

    public ne b(int n) {
        this.setShowAsAction(n);
        return this;
    }

    public ne b(CharSequence charSequence) {
        this.q = charSequence;
        return this;
    }

    public boolean collapseActionView() {
        return false;
    }

    public boolean expandActionView() {
        return false;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    public View getActionView() {
        return null;
    }

    public int getAlphabeticModifiers() {
        return this.k;
    }

    public char getAlphabeticShortcut() {
        return this.j;
    }

    public CharSequence getContentDescription() {
        return this.p;
    }

    public int getGroupId() {
        return this.b;
    }

    public Drawable getIcon() {
        return this.l;
    }

    public ColorStateList getIconTintList() {
        return this.r;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.s;
    }

    public Intent getIntent() {
        return this.g;
    }

    public int getItemId() {
        return this.a;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public int getNumericModifiers() {
        return this.i;
    }

    public char getNumericShortcut() {
        return this.h;
    }

    public int getOrder() {
        return this.d;
    }

    public SubMenu getSubMenu() {
        return null;
    }

    public CharSequence getTitle() {
        return this.e;
    }

    public CharSequence getTitleCondensed() {
        if (this.f != null) {
            return this.f;
        }
        return this.e;
    }

    public CharSequence getTooltipText() {
        return this.q;
    }

    public boolean hasSubMenu() {
        return false;
    }

    public boolean isActionViewExpanded() {
        return false;
    }

    public boolean isCheckable() {
        if ((this.v & 1) != 0) {
            return true;
        }
        return false;
    }

    public boolean isChecked() {
        if ((this.v & 2) != 0) {
            return true;
        }
        return false;
    }

    public boolean isEnabled() {
        if ((this.v & 16) != 0) {
            return true;
        }
        return false;
    }

    public boolean isVisible() {
        if ((this.v & 8) == 0) {
            return true;
        }
        return false;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public /* synthetic */ MenuItem setActionView(int n) {
        return this.a(n);
    }

    public /* synthetic */ MenuItem setActionView(View view) {
        return this.a(view);
    }

    public MenuItem setAlphabeticShortcut(char c) {
        this.j = Character.toLowerCase(c);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int n) {
        this.j = Character.toLowerCase(c);
        this.k = KeyEvent.normalizeMetaState((int)n);
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public MenuItem setCheckable(boolean bl) {
        int n = this.v;
        int n2 = bl ? 1 : 0;
        this.v = n2 | n & -2;
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public MenuItem setChecked(boolean bl) {
        int n = this.v;
        int n2 = bl ? 2 : 0;
        this.v = n2 | n & -3;
        return this;
    }

    public /* synthetic */ MenuItem setContentDescription(CharSequence charSequence) {
        return this.a(charSequence);
    }

    /*
     * Enabled aggressive block sorting
     */
    public MenuItem setEnabled(boolean bl) {
        int n = this.v;
        int n2 = bl ? 16 : 0;
        this.v = n2 | n & -17;
        return this;
    }

    public MenuItem setIcon(int n) {
        this.m = n;
        this.l = le.a((Context)this.n, (int)n);
        this.b();
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.l = drawable;
        this.m = 0;
        this.b();
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.r = colorStateList;
        this.t = true;
        this.b();
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.s = mode;
        this.u = true;
        this.b();
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.g = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        this.h = c;
        return this;
    }

    public MenuItem setNumericShortcut(char c, int n) {
        this.h = c;
        this.i = KeyEvent.normalizeMetaState((int)n);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.o = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.h = c;
        this.j = Character.toLowerCase(c2);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int n, int n2) {
        this.h = c;
        this.i = KeyEvent.normalizeMetaState((int)n);
        this.j = Character.toLowerCase(c2);
        this.k = KeyEvent.normalizeMetaState((int)n2);
        return this;
    }

    public void setShowAsAction(int n) {
    }

    public /* synthetic */ MenuItem setShowAsActionFlags(int n) {
        return this.b(n);
    }

    public MenuItem setTitle(int n) {
        this.e = this.n.getResources().getString(n);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.e = charSequence;
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f = charSequence;
        return this;
    }

    public /* synthetic */ MenuItem setTooltipText(CharSequence charSequence) {
        return this.b(charSequence);
    }

    /*
     * Enabled aggressive block sorting
     */
    public MenuItem setVisible(boolean bl) {
        int n = this.v;
        int n2 = bl ? 0 : 8;
        this.v = n2 | n & 8;
        return this;
    }
}

