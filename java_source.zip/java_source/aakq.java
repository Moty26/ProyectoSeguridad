/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agi
 *  android.view.View
 *  com.ubercab.ui.core.UTextView
 */
import android.view.View;
import com.ubercab.ui.core.UTextView;

public class aakq
extends agi {
    protected final UTextView n;

    public aakq(UTextView uTextView) {
        super((View)uTextView);
        this.n = uTextView;
    }
}

