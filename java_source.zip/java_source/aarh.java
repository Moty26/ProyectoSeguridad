/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Patterns
 *  awlj
 *  awlp
 *  awlq
 *  awmh
 *  awmo
 *  awnk
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  com.ubercab.presidio.contacts.model.ContactSelection
 *  com.ubercab.presidio.contacts.model.RawContact
 *  com.ubercab.presidio.contacts.model.RawContact$Type
 *  eop
 *  eot
 *  eov
 *  ewe
 *  ewj
 *  hie
 *  llg
 *  llw
 */
import android.content.Context;
import android.util.Patterns;
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.contacts.model.ContactDetail;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;
import com.ubercab.presidio.contacts.model.ContactSelection;
import com.ubercab.presidio.contacts.model.RawContact;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class aarh
extends ewj<aark, aarl>
implements aaqu,
aasf {
    aaqh a;
    ContactPickerCustomization b;
    aark c;
    aarx d;
    aase e;
    aari f;
    hlg g;
    RibActivity i;

    /*
     * Enabled aggressive block sorting
     */
    private RawContact c(String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::dlLkWs8wnavhuVUZyXUQ76qMIBIDLHzvVfDqLPYEpw5nhglGWtFoeVVDfKhyZa9COd3gCs7dekW7oElefaABhttYBtDG3cVMpcqPKqtX6g+sJmiogQRBNLqlNRQzcdX1", 2819679059983535793L, 6730152745635662647L, -2326419473208545470L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 88);
        }
        string = Patterns.EMAIL_ADDRESS.matcher(string).matches() ? RawContact.create((String)this.a.a(string), (RawContact.Type)RawContact.Type.EMAIL) : RawContact.create((String)this.a.b(string), (RawContact.Type)RawContact.Type.PHONE_NUMBER);
        if (llw2 != null) {
            llw2.i();
        }
        return string;
    }

    private void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::jIdP6aq6I0sJQA/Rr2MSt5I+OyxYkOAURuXhkgWd7Nk=", 2819679059983535793L, 6730152745635662647L, 5009512561865761349L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 97);
        }
        if (this.g.a((Context)this.i, "android.permission.READ_CONTACTS")) {
            ((eov)this.d.a((Context)this.i, this.b.getContactFilter()).observeOn(awmh.a()).to((awnk)new eot((eop)this))).a((awlp)new awlp<aary>(){

                public void a(aary aary2) {
                    aarh.this.e.a(aary2);
                }

                public void onComplete() {
                }

                public void onError(Throwable throwable) {
                }

                public /* synthetic */ void onNext(Object object) {
                    this.a((aary)object);
                }

                public void onSubscribe(awmo awmo2) {
                }
            });
            ((eov)this.e.a().observeOn(awmh.a()).to((awnk)new eot((eop)this))).a((awlp)new awlp<hie<aatb>>(){

                public void a(hie<aatb> hie2) {
                    aarh.this.c.a(hie2);
                }

                public void onComplete() {
                }

                public void onError(Throwable throwable) {
                }

                public /* synthetic */ void onNext(Object object) {
                    this.a((hie)object);
                }

                public void onSubscribe(awmo awmo2) {
                }
            });
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a(ContactDetail contactDetail) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::o7mJmSwkDpECT//WbiGUf4ncfFsCHQ/AbuTxahw/7Ew86Q02hGf3d0/T3OVct7/wB36XahplP3H4jvHqQc7cTGeZnyLMY4Nm8TEMslnkvz3S4CZCdrZQuNfPYIHFq9NZ", 2819679059983535793L, 6730152745635662647L, 900999501023571385L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 59);
        }
        contactDetail = ContactSelection.create(Collections.singleton(contactDetail), Collections.emptySet());
        this.f.a((ContactSelection)contactDetail);
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a(RawContact rawContact) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::Sg2sVftVKDsJLB5w+e5TIHrDEUmh76qdhAcVfenzpoDKdnTsfRskJgG+8UqUkh9IR/XWpYnk6k1WzouhW6fW0WpJLuKB3bGBCV4KRSiGDcI=", 2819679059983535793L, 6730152745635662647L, 7985537255708645285L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 68);
        }
        rawContact = ContactSelection.create(Collections.emptySet(), Collections.singleton(rawContact));
        this.f.a((ContactSelection)rawContact);
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void a(ewe ewe2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", 2819679059983535793L, 6730152745635662647L, -8133349418566419115L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 52);
        }
        super.a(ewe2);
        this.d();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a(String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::o7mJmSwkDpECT//WbiGUf5oYzWfqfhHMVMeI7omsoA/XgAMZuYUSl4xJOyYhcjsNtOHk/PMhx4h/aAf5LEkK6Q==", 2819679059983535793L, 6730152745635662647L, -6923002244314410922L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 84);
        }
        this.d.a(string);
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void b(String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgM2BMi6+YmaUvyBKJ5oKmBXEtDxDPFIdOdusbd/B9HB8=", "enc::0aagQpiYZR9DzNHn0yohQTu4Z9Da/z5ppC+r7EJ3Ufn6WIAvFVa58yaIcqkkCLhi", 2819679059983535793L, 6730152745635662647L, 442758180689642456L, 6165381391493657874L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQUOhXaCv9N01B/HUjdnT18Y=", 75);
        }
        string = this.c(string);
        string = ContactSelection.create(Collections.emptySet(), Collections.singleton(string));
        this.f.a((ContactSelection)string);
        if (llw2 != null) {
            llw2.i();
        }
    }

}

