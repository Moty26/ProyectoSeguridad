/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  atvd
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.consent.primer.PrimerView
 *  ewc
 */
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.consent.primer.PrimerView;

public abstract class aanm {
    static aanv a(aank aank2, PrimerView primerView, aanr aanr2, RibActivity ribActivity, atvd atvd2) {
        return new aanv(primerView, aanr2, aank2, (ewc)ribActivity, atvd2);
    }
}

