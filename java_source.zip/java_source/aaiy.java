/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aaiy
implements awdv<aajq> {
    static final /* synthetic */ boolean a;
    private final aaiv b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaiy.class.desiredAssertionStatus();
        a = bl;
    }

    public aaiy(aaiv aaiv2) {
        if (!a && aaiv2 == null) {
            throw new AssertionError();
        }
        this.b = aaiv2;
    }

    public static awdv<aajq> a(aaiv aaiv2) {
        return new aaiy(aaiv2);
    }

    public aajq a() {
        return (aajq)((Object)awec.a((Object)((Object)this.b.a()), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

