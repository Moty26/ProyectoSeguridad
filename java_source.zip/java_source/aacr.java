/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 */
import android.app.PendingIntent;
import android.content.Context;
import java.util.List;

public abstract class aacr {
    protected final Context a;

    protected aacr(Context context) {
        this.a = context;
    }

    public abstract void a(List<aacu> var1, PendingIntent var2, aacg var3);
}

