/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.support.design.widget.CoordinatorLayout
 *  android.view.MotionEvent
 *  android.view.View
 *  com.ubercab.presidio.behaviors.core.DisableableBottomSheetBehavior
 */
import android.support.design.widget.CoordinatorLayout;
import android.view.MotionEvent;
import android.view.View;
import com.ubercab.presidio.behaviors.core.DisableableBottomSheetBehavior;

public class aadg {
    final /* synthetic */ DisableableBottomSheetBehavior a;

    public aadg(DisableableBottomSheetBehavior disableableBottomSheetBehavior) {
        this.a = disableableBottomSheetBehavior;
    }

    public boolean a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        return DisableableBottomSheetBehavior.access$000((DisableableBottomSheetBehavior)this.a, (CoordinatorLayout)coordinatorLayout, v, (MotionEvent)motionEvent);
    }

    public boolean a(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int n) {
        return DisableableBottomSheetBehavior.access$100((DisableableBottomSheetBehavior)this.a, (CoordinatorLayout)coordinatorLayout, v, (View)view, (View)view2, (int)n);
    }
}

