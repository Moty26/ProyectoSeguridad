/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alxc
 *  hhy
 *  iro
 */
class aany
implements alws<hhy<Void>, aanx> {
    aany() {
    }

    public aanx a(hhy<Void> hhy2) {
        return new aanz();
    }

    public alxc a() {
        return iro.aj;
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((hhy)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((hhy)object);
    }

    public String b() {
        return "bb91532a-fb87-4be4-8ba1-9bc0ebaae0a8";
    }

    public boolean b(hhy<Void> hhy2) {
        return true;
    }
}

