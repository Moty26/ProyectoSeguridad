/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  ewj
 *  ewo
 */
public final class aaka
implements awdr<aajz> {
    static final /* synthetic */ boolean a;
    private final axss<aakb> b;
    private final axss<aagq> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaka.class.desiredAssertionStatus();
        a = bl;
    }

    public aaka(axss<aakb> axss2, axss<aagq> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdr<aajz> a(axss<aakb> axss2, axss<aagq> axss3) {
        return new aaka(axss2, axss3);
    }

    public void a(aajz aajz2) {
        if (aajz2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aajz2, this.b);
        aajz2.a = (aakb)this.b.get();
        aajz2.b = (aagq)this.c.get();
    }
}

