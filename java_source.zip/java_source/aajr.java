/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  avyy
 *  avyz
 *  com.ubercab.ui.FloatingLabelEditText
 */
import android.text.TextUtils;
import com.ubercab.ui.FloatingLabelEditText;

public class aajr
implements avyz<FloatingLabelEditText, avyy> {
    private final float a;
    private final FloatingLabelEditText b;
    private final avyy c;

    public aajr(float f, FloatingLabelEditText floatingLabelEditText, avyy avyy2) {
        this.a = f;
        this.b = floatingLabelEditText;
        this.c = avyy2;
    }

    public avyy a(FloatingLabelEditText object) {
        CharSequence charSequence = this.b.e();
        object = object.e();
        if (!TextUtils.isEmpty((CharSequence)charSequence) && !TextUtils.isEmpty((CharSequence)object) && (float)(charSequence.length() + object.length()) > this.a) {
            return this.c;
        }
        return null;
    }
}

