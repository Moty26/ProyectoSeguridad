/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 */
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public final class aarb
implements awdv<aark> {
    static final /* synthetic */ boolean a;
    private final aaqx b;
    private final axss<ContactPickerCustomization> c;
    private final axss<aart> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarb.class.desiredAssertionStatus();
        a = bl;
    }

    public aarb(aaqx aaqx2, axss<ContactPickerCustomization> axss2, axss<aart> axss3) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aark> a(aaqx aaqx2, axss<ContactPickerCustomization> axss2, axss<aart> axss3) {
        return new aarb(aaqx2, axss2, axss3);
    }

    public aark a() {
        return (aark)((Object)awec.a((Object)((Object)this.b.a((ContactPickerCustomization)this.c.get(), (aart)((Object)this.d.get()))), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

