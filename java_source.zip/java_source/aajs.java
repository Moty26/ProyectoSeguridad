/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView;

public class aajs
extends exk<CobrandCardReviewView, aakd, aajw> {
    public aajs(aajw aajw2) {
        super((Object)aajw2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aakd b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjziBr/Z1xQfDHgOJbQKHpYQ0=", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2R1PLk5O/qE8q7J20F2raPlZLQd6a5FAvuXUpOS4R+AuaTY2kieZfeTnMwY7H3762mfz7qQNa1rONQ8pfBH9XuhQaxLXXc7/J3jAXVIwAwng=", -5306614988125172036L, -1523494803768456287L, 8249506237128726541L, 7185931817553012858L, null, "enc::Hujfkma6FErbAA/0eTKY9YBriUD3SKkEl35YZ9csUlU=", 45) : null;
        object = (CobrandCardReviewView)this.a_((ViewGroup)object);
        aajz aajz2 = new aajz();
        object = aakf.b().a((aajw)this.bS_()).a(new aajv(aajz2, (CobrandCardReviewView)object)).a().a();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected CobrandCardReviewView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjziBr/Z1xQfDHgOJbQKHpYQ0=", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zMmvnVZyy2ZVqacok3gBZFiHNKCMxsCt0KRoA6DsZQ4r4JIIZQieuN7auPpgylp/V7jDpVmd7yifm/xRomVVFYQ==", -5306614988125172036L, -1523494803768456287L, 6414111807864556959L, 7185931817553012858L, null, "enc::Hujfkma6FErbAA/0eTKY9YBriUD3SKkEl35YZ9csUlU=", 56) : null;
        layoutInflater = (CobrandCardReviewView)layoutInflater.inflate(aafw.ub__cobrandcard_review, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

