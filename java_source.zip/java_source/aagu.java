/*
 * Decompiled with CFR 0_119.
 */
public interface aagu {
    public void a();
}

