/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aakg {
    private aajv a;
    private aajw b;

    private aakg() {
    }

    static /* synthetic */ aajw a(aakg aakg2) {
        return aakg2.b;
    }

    static /* synthetic */ aajv b(aakg aakg2) {
        return aakg2.a;
    }

    public aaju a() {
        if (this.a == null) {
            throw new IllegalStateException(aajv.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aajw.class.getCanonicalName() + " must be set");
        }
        return new aakf(this);
    }

    public aakg a(aajv aajv2) {
        this.a = (aajv)((Object)awec.a((Object)((Object)aajv2)));
        return this;
    }

    public aakg a(aajw aajw2) {
        this.b = (aajw)awec.a((Object)aajw2);
        return this;
    }
}

