/*
 * Decompiled with CFR 0_119.
 */
public interface aapx {
    public void a(String var1);

    public void d();
}

