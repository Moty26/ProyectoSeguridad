/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aaip
implements axss<aagq> {
    private final aaib a;

    aaip(aaib aaib2) {
        this.a = aaib2;
    }

    public aagq a() {
        return (aagq)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

