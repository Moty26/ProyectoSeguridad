/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView
 *  ewj
 *  ewk
 *  eyq
 */
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView;

public class aahe
extends ewk<aahj, CobrandCardAddressView> {
    public aahe(aahj aahj2, CobrandCardAddressView cobrandCardAddressView) {
        super((ewj)aahj2, (View)cobrandCardAddressView);
    }

    aahl a(aahv aahv2, aagq aagq2) {
        return new aahl((CobrandCardAddressView)this.c(), (aahm)this.d(), aahv2, aagq2);
    }

    aahn a(aahd aahd2, eyq eyq2) {
        return new aahn((CobrandCardAddressView)this.c(), (aahj)this.d(), aahd2, eyq2, new aahx(aahd2));
    }

    aahv a() {
        return new aahv();
    }
}

