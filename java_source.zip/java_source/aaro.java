/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  hpz
 */
class aaro
implements axss<hpz> {
    private final aaqy a;

    aaro(aaqy aaqy2) {
        this.a = aaqy2;
    }

    public hpz a() {
        return (hpz)awec.a((Object)this.a.l(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

