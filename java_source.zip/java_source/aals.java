/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  ewf
 */
public final class aals
implements awdv<ewf> {
    private static final aals a = new aals();

    public static awdv<ewf> b() {
        return a;
    }

    public ewf a() {
        return (ewf)awec.a((Object)aalp.a(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

