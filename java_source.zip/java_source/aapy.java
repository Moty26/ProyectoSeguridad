/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.contact_driver.edit_number.EditNumberView
 *  ewj
 *  ewl
 *  exm
 */
import android.view.View;
import com.ubercab.presidio.contact_driver.edit_number.EditNumberView;

public class aapy
extends exm<EditNumberView, aapt, aapp> {
    public aapy(EditNumberView editNumberView, aapt aapt2, aapp aapp2) {
        super((View)editNumberView, (ewj)aapt2, (ewl)aapp2);
    }
}

