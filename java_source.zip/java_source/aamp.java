/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  eyq
 */
class aamp
implements axss<eyq> {
    private final aamc a;

    aamp(aamc aamc2) {
        this.a = aamc2;
    }

    public eyq a() {
        return (eyq)awec.a((Object)this.a.bU_(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

