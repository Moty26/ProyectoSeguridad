/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdq
 *  awdu
 *  awdv
 *  awec
 *  axss
 *  axug
 *  dze
 */
public final class aaba
implements awdv<aabd> {
    static final /* synthetic */ boolean a;
    private final aaay b;
    private final axss<axug> c;
    private final axss<dze> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaba.class.desiredAssertionStatus();
        a = bl;
    }

    public aaba(aaay aaay2, axss<axug> axss2, axss<dze> axss3) {
        if (!a && aaay2 == null) {
            throw new AssertionError();
        }
        this.b = aaay2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aabd> a(aaay aaay2, axss<axug> axss2, axss<dze> axss3) {
        return new aaba(aaay2, axss2, axss3);
    }

    public aabd a() {
        return (aabd)awec.a((Object)this.b.a(awdu.b(this.c), (dze)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

