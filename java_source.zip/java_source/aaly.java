/*
 * Decompiled with CFR 0_119.
 */
enum aaly {
    a,
    b;
    

    private aaly() {
    }
}

