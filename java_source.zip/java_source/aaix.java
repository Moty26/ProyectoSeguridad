/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aaix
implements awdv<abua> {
    static final /* synthetic */ boolean a;
    private final aaiv b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaix.class.desiredAssertionStatus();
        a = bl;
    }

    public aaix(aaiv aaiv2) {
        if (!a && aaiv2 == null) {
            throw new AssertionError();
        }
        this.b = aaiv2;
    }

    public static awdv<abua> a(aaiv aaiv2) {
        return new aaix(aaiv2);
    }

    public abua a() {
        return (abua)awec.a((Object)this.b.b(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

