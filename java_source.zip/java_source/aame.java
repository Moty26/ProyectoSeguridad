/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  ewj
 *  ewl
 *  eww
 *  ewz
 *  exm
 *  eyq
 *  eys
 *  ezc
 *  ezh
 *  ezi
 *  llg
 *  llw
 */
import android.view.View;
import android.view.ViewGroup;

public class aame
extends ewz<aalx, aaln> {
    private final ViewGroup a;
    private final eyq b;
    private final aani c;
    private aanv d;
    private boolean e = false;

    public aame(aalx aalx2, aaln aaln2, ViewGroup viewGroup, aani aani2, eyq eyq2) {
        super((ewj)aalx2, (ewl)aaln2);
        this.a = viewGroup;
        this.c = aani2;
        this.b = eyq2;
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(aanp aanp2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJJiglHkR22iBx7u1beSHuv", "enc::OvWDEe0BPBBIcn3XGZIPQVwwoxTdhhmYzdBafpeJR8SKdDqdzd3pFP87SWWtvl3YvDaghbyKKQ9SARSGbOryU6lvJ9hwYvUBqtbyrXCb/4Y=", 2512309377846186838L, 1305736551455000880L, -735139327525119089L, 4285526870058266813L, null, "enc::3k1LjzvP18dCuFeP/ztH9sGlYdj3tkE8RdfhnmTlM4U=", 41);
        }
        if (this.d == null) {
            this.d = this.c.a(this.a, aanp2);
            this.a((ewz)this.d);
            this.a.addView(this.d.h());
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void b(final aanp aanp2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJJiglHkR22iBx7u1beSHuv", "enc::zbiLwXj6dL7Pn6+JbF19N0R/sZmW49nuGsIWZJpZouJu8HIW0qXyeOdq45Mt++WiZgFLymhmn0NJpP+3Ql3uNky+ZlCsUGNej3DFojViiBs=", 2512309377846186838L, 1305736551455000880L, 8913330006102404351L, 4285526870058266813L, null, "enc::3k1LjzvP18dCuFeP/ztH9sGlYdj3tkE8RdfhnmTlM4U=", 59);
        }
        if (!this.e) {
            aanp2 = eys.a((ezc)new eww(this){

                public exm a(ViewGroup viewGroup) {
                    return aame.this.c.a(viewGroup, aanp2);
                }
            }, (ezi)new ezh()).a();
            this.b.a((eys)aanp2);
            this.e = true;
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void h() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJJiglHkR22iBx7u1beSHuv", "enc::Bh6HHbbX5ouqhNn6Eh9Q4YCUWuxd749WGMukk0HpSVQ=", 2512309377846186838L, 1305736551455000880L, -1409676355965673314L, 4285526870058266813L, null, "enc::3k1LjzvP18dCuFeP/ztH9sGlYdj3tkE8RdfhnmTlM4U=", 51) : null;
        if (this.d == null) return;
        this.a.removeView(this.d.h());
        this.b((ewz)this.d);
        this.d = null;
        if (llw2 != null) {
            llw2.i();
        }
    }

    void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKjBCRRYOBlV8cSB7iVRdQUJJiglHkR22iBx7u1beSHuv", "enc::MeqPBszhdjVx2VC/Y0gKqeOq9y5FCpbsUti59c5Qgqw=", 2512309377846186838L, 1305736551455000880L, 1675430410290113014L, 4285526870058266813L, null, "enc::3k1LjzvP18dCuFeP/ztH9sGlYdj3tkE8RdfhnmTlM4U=", 76);
        }
        if (this.e) {
            this.b.a();
            this.e = false;
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

}

