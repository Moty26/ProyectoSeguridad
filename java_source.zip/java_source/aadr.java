/*
 * Decompiled with CFR 0_119.
 */
public interface aadr {
}

