/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hqg
 */
public enum aalw implements hqg
{
    CONTACTS_SYNC;
    

    private aalw() {
    }
}

