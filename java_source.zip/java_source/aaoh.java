/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.ViewGroup
 *  ewd
 *  llg
 *  llw
 */
import android.content.Context;
import android.view.ViewGroup;

public class aaoh
extends ewd<aaox, aaow> {
    public aaoh(aaow aaow2) {
        super((Object)aaow2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aaox a(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk8PGn/Z0Gu/mxM5IM2dBdB+g==", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2eGNxdwxglj29tSwoSvMIOQci5/X7tGdSHTu7BTcLZ6S755IgWnBPVJMM9CL0fM/uBFfl1AIqiH3sd/g893AcpQ==", 6815923241891742049L, 1877971778707020637L, 6652959373872821589L, 7185931817553012858L, null, "enc::j8jN0107qfij5ryjTmhpnSfjb1L7+ew7qjvGQy57wfk=", 40) : null;
        object = object.getContext();
        aaor aaor2 = new aaor();
        object = aaoy.b().a((aaow)this.bS_()).a(new aaok((Context)object, aaor2)).a().a();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }
}

