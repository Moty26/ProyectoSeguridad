/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awdr
 *  axss
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  ewj
 *  ewo
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;

public final class aafe
implements awdr<aafc> {
    static final /* synthetic */ boolean a;
    private final axss<aaff> b;
    private final axss<CobrandCardClient<apap>> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aafe.class.desiredAssertionStatus();
        a = bl;
    }

    public aafe(axss<aaff> axss2, axss<CobrandCardClient<apap>> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdr<aafc> a(axss<aaff> axss2, axss<CobrandCardClient<apap>> axss3) {
        return new aafe(axss2, axss3);
    }

    public void a(aafc aafc2) {
        if (aafc2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aafc2, this.b);
        aafc2.a = (CobrandCardClient)this.c.get();
        aafc2.b = (aaff)this.b.get();
    }
}

