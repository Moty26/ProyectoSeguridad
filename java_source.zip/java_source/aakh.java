/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  ewc
 */
class aakh
implements axss<ewc> {
    private final aajw a;

    aakh(aajw aajw2) {
        this.a = aajw2;
    }

    public ewc a() {
        return (ewc)awec.a((Object)this.a.h(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

