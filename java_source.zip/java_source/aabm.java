/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alxc
 *  android.content.Context
 *  hhy
 *  hpz
 *  hqg
 *  yzr
 *  zqk
 *  zye
 *  zyf
 */
import android.content.Context;

public class aabm
implements alws<hhy<Void>, zqk> {
    private final zye a;

    public aabm(zye zye2) {
        this.a = zye2;
    }

    public alxc a() {
        return yzr.d;
    }

    public zqk a(hhy<Void> hhy2) {
        return new aabl(this.a);
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((hhy)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((hhy)object);
    }

    public String b() {
        return "36f3099e-a1ef-11e6-80f5-76304dec7eb7";
    }

    public boolean b(hhy<Void> hhy2) {
        if (aabg.a(this.a.f()) && this.a.h().a((hqg)zyf.RIDER_SENA_LINE_ONBOARDING)) {
            return true;
        }
        return false;
    }
}

