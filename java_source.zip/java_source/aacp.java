/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aacp
implements awdv<aaco> {
    static final /* synthetic */ boolean a;
    private final aacn b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aacp.class.desiredAssertionStatus();
        a = bl;
    }

    public aacp(aacn aacn2) {
        if (!a && aacn2 == null) {
            throw new AssertionError();
        }
        this.b = aacn2;
    }

    public static awdv<aaco> a(aacn aacn2) {
        return new aacp(aacn2);
    }

    public aaco a() {
        return (aaco)awec.a((Object)this.b.a(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

