/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView
 *  ewj
 *  ewk
 *  eyq
 */
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView;

public class aaia
extends ewk<aaif, CobrandCardFinancialInfoView> {
    public aaia(aaif aaif2, CobrandCardFinancialInfoView cobrandCardFinancialInfoView) {
        super((ewj)aaif2, (View)cobrandCardFinancialInfoView);
    }

    aaih a(aaik aaik2, aagq aagq2) {
        return new aaih((CobrandCardFinancialInfoView)this.c(), (aaii)this.d(), aaik2, aagq2);
    }

    aaij a(aahz aahz2, eyq eyq2) {
        return new aaij((CobrandCardFinancialInfoView)this.c(), (aaif)this.d(), aahz2, eyq2, new aajs(aahz2));
    }

    aaik a() {
        return new aaik();
    }
}

