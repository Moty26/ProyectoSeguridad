/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.support.design.widget.BottomSheetBehavior
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  auhz
 *  avxj
 *  awlj
 *  bx
 *  com.ubercab.ui.commons.widget.BitLoadingIndicator
 *  com.ubercab.ui.core.UButton
 *  com.ubercab.ui.core.ULinearLayout
 *  com.ubercab.ui.core.UTextView
 */
import android.annotation.SuppressLint;
import android.content.Context;
import android.support.design.widget.BottomSheetBehavior;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.ubercab.ui.commons.widget.BitLoadingIndicator;
import com.ubercab.ui.core.UButton;
import com.ubercab.ui.core.ULinearLayout;
import com.ubercab.ui.core.UTextView;

public class aaoq
extends avxj {
    private final UButton b;
    private final ULinearLayout c;
    private final ViewGroup d;
    private final UTextView e;
    private final ViewGroup f;
    private final BitLoadingIndicator g;
    private final UTextView h;
    private final UButton i;
    private final UTextView j;
    private final UTextView k;

    @SuppressLint(value={"InflateParams"})
    public aaoq(Context context) {
        super(context);
        this.d = (ViewGroup)LayoutInflater.from((Context)context).inflate(aaof.ub_optional__contact_driver_bottom_sheet, null);
        this.b = (UButton)this.d.findViewById(aaoe.ub__contact_driver_call);
        this.c = (ULinearLayout)this.d.findViewById(aaoe.ub__contact_actions_container);
        this.e = (UTextView)this.d.findViewById(aaoe.ub__contact_driver_edit);
        this.f = (ViewGroup)this.d.findViewById(aaoe.ub__contact_edit_number_container);
        this.g = (BitLoadingIndicator)this.d.findViewById(aaoe.ub__contact_driver_loading);
        this.h = (UTextView)this.d.findViewById(aaoe.ub__contact_loading_text);
        this.i = (UButton)this.d.findViewById(aaoe.ub__contact_driver_text);
        this.j = (UTextView)this.d.findViewById(aaoe.ub__contact_edit_number_rider_number);
        this.k = (UTextView)this.d.findViewById(aaoe.ub__contact_dialog_title);
        this.setContentView((View)this.d);
        context = BottomSheetBehavior.from((View)((View)this.d.getParent()));
        context.setBottomSheetCallback(new bx((BottomSheetBehavior)context){
            final /* synthetic */ BottomSheetBehavior a;

            public void a(View view, float f) {
            }

            public void a(View view, int n) {
                if (n == 1) {
                    this.a.setState(3);
                }
            }
        });
        context.setState(3);
    }

    public void a(String string) {
        this.j.setText((CharSequence)string);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(boolean bl) {
        UButton uButton = this.b;
        int n = bl ? 0 : 8;
        uButton.setVisibility(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(boolean bl, boolean bl2) {
        int n = 0;
        ULinearLayout uLinearLayout = this.c;
        int n2 = bl ? 8 : 0;
        uLinearLayout.setVisibility(n2);
        uLinearLayout = this.h;
        n2 = bl ? n : 8;
        uLinearLayout.setVisibility(n2);
        if (bl && bl2) {
            this.g.f();
            return;
        }
        this.g.g();
    }

    public void b(int n) {
        this.i.setText(n);
    }

    public void b(String string) {
        this.k.setText((CharSequence)string);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(boolean bl) {
        ViewGroup viewGroup = this.f;
        int n = bl ? 0 : 8;
        viewGroup.setVisibility(n);
    }

    public awlj<auhz> c() {
        return this.b.i();
    }

    public void c(boolean bl) {
        this.a(bl, true);
    }

    public awlj<auhz> d() {
        return this.e.g();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void d(boolean bl) {
        UButton uButton = this.i;
        int n = bl ? 0 : 8;
        uButton.setVisibility(n);
    }

    public awlj<auhz> e() {
        return this.i.i();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void e(boolean bl) {
        UTextView uTextView = this.k;
        int n = bl ? 0 : 8;
        uTextView.setVisibility(n);
    }

}

