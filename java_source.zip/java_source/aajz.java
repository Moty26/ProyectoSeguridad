/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  auif
 *  awlj
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  eop
 *  eot
 *  eov
 *  ewe
 *  ewj
 *  ewz
 *  llg
 *  llw
 */
import android.net.Uri;

public class aajz
extends ewj<aakb, aakd>
implements aakc {
    aakb a;
    aagq b;

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ewe ewe2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", -5306614988125172036L, 7936738557258160308L, -8133349418566419115L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 35) : null;
        super.a(ewe2);
        ((eov)this.b.b().observeOn(awmh.a()).take(1).to((awnk)new eot((eop)this))).a((awlp)new auif<aags>(){

            public void a(aags aags2) throws Exception {
                aajz.this.a.a(aags2);
            }
        });
        ((eov)this.b.a().observeOn(awmh.a()).take(1).to((awnk)new eot((eop)this))).a((awlp)new auif<aagr>(){

            public void a(aagr aagr2) throws Exception {
                aajz.this.a.a(aagr2);
            }
        });
        ((eov)this.b.c().observeOn(awmh.a()).take(1).to((awnk)new eot((eop)this))).a((awlp)new auif<aagt>(){

            public void a(aagt aagt2) throws Exception {
                aajz.this.a.a(aagt2);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(String string) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::I0QmPe+NO5d0D/2Ew43CajaumLkG9CAxAWiqXDdLprodGtanA/RaIjXqGGFH4Tbe", -5306614988125172036L, 7936738557258160308L, -6393166041258023491L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 76) : null;
        ((aakd)this.h()).a(Uri.parse((String)string));
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::uU+BkhZsHDaU/gtvAJ2vy7SxXQ57Z4DaudwJi2tPMFE=", -5306614988125172036L, 7936738557258160308L, -3564081918521942663L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 30);
        }
        ((aakd)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void e() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::QsOr7P4Ehl+vuIfxLhge2t5RvXGs6wMqI5X0rex1YIA=", -5306614988125172036L, 7936738557258160308L, 6865136567210821558L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 81);
        }
        ((aakd)this.h()).j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::Z5D9MNx+GSaQUsTDhAHCeBR7D/7UZs/sAiEUqAFdZiQ=", -5306614988125172036L, 7936738557258160308L, 3524047052945537763L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 86);
        }
        ((aakd)this.h()).k();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", -5306614988125172036L, 7936738557258160308L, -6923720291955140451L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 96);
        }
        ((aakd)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }

    @Override
    public void m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjztrkY3U2Zo74iokOffs3+uk=", "enc::lYHnsc7nXtBTmXEGlRFqFZCm7SB+zG20IPFC9qRVS/FY4D2QbUOMS/v8lefIAFz8", -5306614988125172036L, 7936738557258160308L, -3439247291005584840L, 6165381391493657874L, null, "enc::Hujfkma6FErbAA/0eTKY9S0gUM3gCUoLRpFrdmxm+0Dyl1D8apddoBu14k/Vyd6C", 91);
        }
        ((aakd)this.h()).l();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

