/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  apaq
 *  awdr
 *  awlj
 *  axss
 *  com.uber.model.core.generated.rtapi.services.communications.CommunicationsClient
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.contact_driver.model.ContactDriverData
 *  ewf
 *  ewj
 *  ewo
 *  fbz
 *  hpz
 */
import com.uber.model.core.generated.rtapi.services.communications.CommunicationsClient;
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.contact_driver.model.ContactDriverData;

public final class aaov
implements awdr<aaor> {
    static final /* synthetic */ boolean a;
    private final axss<ewf> b;
    private final axss<RibActivity> c;
    private final axss<hpz> d;
    private final axss<CommunicationsClient<apap>> e;
    private final axss<awlj<ContactDriverData>> f;
    private final axss<aaoq> g;
    private final axss<aaot> h;
    private final axss<hlg> i;
    private final axss<fbz> j;
    private final axss<apaq> k;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaov.class.desiredAssertionStatus();
        a = bl;
    }

    public aaov(axss<ewf> axss2, axss<RibActivity> axss3, axss<hpz> axss4, axss<CommunicationsClient<apap>> axss5, axss<awlj<ContactDriverData>> axss6, axss<aaoq> axss7, axss<aaot> axss8, axss<hlg> axss9, axss<fbz> axss10, axss<apaq> axss11) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
        if (!a && axss7 == null) {
            throw new AssertionError();
        }
        this.g = axss7;
        if (!a && axss8 == null) {
            throw new AssertionError();
        }
        this.h = axss8;
        if (!a && axss9 == null) {
            throw new AssertionError();
        }
        this.i = axss9;
        if (!a && axss10 == null) {
            throw new AssertionError();
        }
        this.j = axss10;
        if (!a && axss11 == null) {
            throw new AssertionError();
        }
        this.k = axss11;
    }

    public static awdr<aaor> a(axss<ewf> axss2, axss<RibActivity> axss3, axss<hpz> axss4, axss<CommunicationsClient<apap>> axss5, axss<awlj<ContactDriverData>> axss6, axss<aaoq> axss7, axss<aaot> axss8, axss<hlg> axss9, axss<fbz> axss10, axss<apaq> axss11) {
        return new aaov(axss2, axss3, axss4, axss5, axss6, axss7, axss8, axss9, axss10, axss11);
    }

    public void a(aaor aaor2) {
        if (aaor2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aaor2, this.b);
        aaor2.a = (RibActivity)this.c.get();
        aaor2.b = (hpz)this.d.get();
        aaor2.c = (CommunicationsClient)this.e.get();
        aaor2.d = (awlj)this.f.get();
        aaor2.e = (aaoq)((Object)this.g.get());
        aaor2.f = (ewf)this.b.get();
        aaor2.g = (aaot)this.h.get();
        aaor2.i = (hlg)this.i.get();
        aaor2.j = (fbz)this.j.get();
        aaor2.k = (apaq)this.k.get();
    }
}

