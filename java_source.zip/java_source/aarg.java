/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  awlq
 */
public final class aarg
implements awdv<awlq> {
    static final /* synthetic */ boolean a;
    private final aaqx b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarg.class.desiredAssertionStatus();
        a = bl;
    }

    public aarg(aaqx aaqx2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
    }

    public static awdv<awlq> a(aaqx aaqx2) {
        return new aarg(aaqx2);
    }

    public awlq a() {
        return (awlq)awec.a((Object)this.b.g(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

