/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  aspo
 *  auhz
 *  auif
 *  avwr
 *  awlj
 *  awlp
 *  com.ubercab.presidio.cobrandcard.picker.PickerModalView
 *  eij
 *  hie
 */
import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.picker.PickerModalView;

@SuppressLint(value={"RxJavaSubscribeInConstructor", "RxSubscribeOnError"})
public class aakr {
    private PickerModalView a;
    private eij<String> b;
    private eij<auhz> c;
    private boolean d = true;
    private avwr e;

    @SuppressLint(value={"InflateParams"})
    private aakr(aaks aaks2) {
        this.e = new avwr(aaks.a(aaks2));
        this.a = (PickerModalView)View.inflate((Context)aaks.a(aaks2), (int)aakr.a(aaks2), (ViewGroup)null);
        this.e.a((View)this.a);
        this.e.c(aaks.b(aaks2));
        this.d = aaks.c(aaks2);
        this.a.a(aaks.d(aaks2));
        this.a.b(aaks.e(aaks2));
        this.a.c(aaks.f(aaks2));
        this.b = eij.a();
        this.a.c().subscribe((awlp)new auif<String>(){

            public void a(String string) throws Exception {
                aakr.this.b.a((Object)string);
            }
        });
        if (this.d) {
            this.b.subscribe((awlp)new auif<String>(){

                public void a(String string) throws Exception {
                    aakr.this.e.b();
                }
            });
        }
        if (!aspo.a((CharSequence)aaks.f(aaks2))) {
            this.c = eij.a();
            this.a.b().subscribe((awlp)new auif<auhz>(){

                public void a(auhz auhz2) throws Exception {
                    if (aakr.this.c != null) {
                        aakr.this.c.a((Object)auhz.a);
                    }
                }
            });
            if (this.d) {
                this.c.subscribe((awlp)new auif<auhz>(){

                    public void a(auhz auhz2) throws Exception {
                        aakr.this.e.b();
                    }
                });
            }
        }
        this.a.a(aaks.g(aaks2));
    }

    private static int a(aaks aaks2) {
        return aafw.ub__cobrandcard_picker;
    }

    public static aaks a(Context context) {
        return new aaks(context);
    }

    public void a() {
        this.e.a();
    }

    public awlj<String> b() {
        return this.b;
    }

}

