/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdv
 *  awec
 *  axss
 */
import android.content.Context;

public final class aaaz
implements awdv<aabg> {
    static final /* synthetic */ boolean a;
    private final aaay b;
    private final axss<Context> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaaz.class.desiredAssertionStatus();
        a = bl;
    }

    public aaaz(aaay aaay2, axss<Context> axss2) {
        if (!a && aaay2 == null) {
            throw new AssertionError();
        }
        this.b = aaay2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
    }

    public static awdv<aabg> a(aaay aaay2, axss<Context> axss2) {
        return new aaaz(aaay2, axss2);
    }

    public aabg a() {
        return (aabg)awec.a((Object)this.b.a((Context)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

