/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  awdv
 *  awec
 */
import android.content.res.Resources;

public final class aarf
implements awdv<Resources> {
    static final /* synthetic */ boolean a;
    private final aaqx b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarf.class.desiredAssertionStatus();
        a = bl;
    }

    public aarf(aaqx aaqx2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
    }

    public static awdv<Resources> a(aaqx aaqx2) {
        return new aarf(aaqx2);
    }

    public Resources a() {
        return (Resources)awec.a((Object)this.b.f(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

