/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlj
 */
import java.util.Map;

public interface aadx {
    public awlj<Map<Integer, aady>> a();
}

