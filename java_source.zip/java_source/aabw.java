/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  auib
 *  auih
 *  awlq
 *  awlv
 *  awlx
 *  awmh
 *  axrq
 *  ayky
 *  com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService
 *  hpz
 *  hqg
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class aabw {
    aacr a;
    PendingIntent b;
    Long c = TimeUnit.HOURS.toMillis(aacj.a);
    private final hpz d;
    private final Context e;
    private final aacj f;
    private aabx g;
    private ayku h;
    private AtomicBoolean i = new AtomicBoolean(false);
    private aact j;

    public aabw(Context context, aacj aacj2, hpz hpz2) {
        this.e = context.getApplicationContext();
        this.f = aacj2;
        this.d = hpz2;
        this.h = ayxf.b();
        this.g = new aaby(null);
        this.j = new aact(){

            @Override
            public aacs a() {
                return new aacs(aabw.this.e);
            }
        };
    }

    private aacu a(JSONObject object) {
        try {
            object = new aacv().a(object.getString("name")).a(object.getDouble("latitude"), object.getDouble("longitude"), 3200.0f).a(-1).b((int)TimeUnit.SECONDS.toMillis(this.f.e())).a(7).a();
            return object;
        }
        catch (JSONException jSONException) {
            kly.a(aabz.a).b((Throwable)jSONException, "Error building geofence object from Json", new Object[0]);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void a(Context context, Class class_, boolean bl) {
        class_ = new ComponentName(context, class_);
        int n = bl ? 1 : 2;
        context.getPackageManager().setComponentEnabledSetting((ComponentName)class_, n, 1);
    }

    private boolean c(String string) {
        for (String string2 : this.f.d()) {
            if (!string2.equalsIgnoreCase("all") && !string2.equalsIgnoreCase(string)) continue;
            return true;
        }
        return false;
    }

    private PendingIntent d() {
        if (this.b == null) {
            Intent intent = new Intent(this.e, GeofenceTransitionsIntentService.class);
            this.b = PendingIntent.getService((Context)this.e, (int)0, (Intent)intent, (int)134217728);
        }
        return this.b;
    }

    private int e() {
        return (int)this.d.a((hqg)aabv.GEOFENCE_REGISTRATION_QUOTA, "airport_notification_quota", 100);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a() {
        if (this.d.c((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER)) {
            return;
        }
        if (this.a == null) {
            this.a = this.j.a();
        }
        if (this.i.get()) return;
        if (!this.h.isUnsubscribed()) return;
        this.f.f().b(axrq.b()).a(awmh.a()).b((awlx)new auih<Long>(){

            public void a(Long l) throws Exception {
                aabw.this.c = TimeUnit.HOURS.toMillis(l);
            }

            public /* synthetic */ void b(Object object) throws Exception {
                this.a((Long)object);
            }
        });
        this.h = ayki.a(new Callable<List<aacu>>(){

            public List<aacu> a() {
                return aabw.this.c();
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        }).b(aywl.d()).a(ayky.a()).a(new auib<List<aacu>>(){

            public void a(List<aacu> list) {
                if (aabw.this.a != null) {
                    aabw.this.a.a(list, aabw.this.d(), null);
                    aabw.this.i.set(true);
                }
            }

            public /* synthetic */ void onNext(Object object) {
                this.a((List)object);
            }
        });
    }

    public boolean a(String string) {
        String string2 = this.f.b();
        Long l = this.f.c();
        if (string != null && !string.isEmpty() && string2 != null && !string2.equalsIgnoreCase(string) && l > 0 && new Date().getTime() - l <= this.c && this.c(string) && !this.a(string2, string)) {
            return true;
        }
        return false;
    }

    boolean a(String string, String string2) {
        if (this.d.c((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_NO_NEARBY)) {
            return false;
        }
        string = string.toUpperCase(Locale.US);
        string2 = string2.toUpperCase(Locale.US);
        for (HashSet<String> hashSet : this.f.g()) {
            if (!hashSet.contains(string) || !hashSet.contains(string2)) continue;
            return true;
        }
        return false;
    }

    public void b() {
        if (this.d.a((hqg)aabv.AIRPORT_ARRIVAL_NOTIFICATION_MASTER) && !this.h.isUnsubscribed()) {
            this.h.unsubscribe();
        }
    }

    public void b(String string) {
        if (string != null) {
            this.f.a(string, new Date().getTime());
        }
    }

    List<aacu> c() {
        ArrayList<aacu> arrayList = new ArrayList<aacu>();
        String string = this.g.a(this.e, "geofences/airport_geofences.json");
        if (string == null) {
            return arrayList;
        }
        string = new JSONObject(string).getJSONArray("geofences");
        int n = Math.min(string.length(), this.e());
        for (int i = 0; i < n; ++i) {
            aacu aacu2 = this.a((JSONObject)string.get(i));
            if (aacu2 == null) continue;
            try {
                arrayList.add(aacu2);
            }
            catch (JSONException jSONException) {
                kly.a(aabz.a).b((Throwable)jSONException, "Error parsing Json file mGeofenceList", new Object[0]);
                break;
            }
            continue;
        }
        return arrayList;
    }

}

