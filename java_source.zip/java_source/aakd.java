/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  android.view.View
 *  com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView
 *  ewc
 *  ewj
 *  ewl
 *  exm
 *  eyq
 *  llg
 *  llw
 */
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView;

public class aakd
extends exm<CobrandCardReviewView, aajz, aaju> {
    private final eyq a;
    private final ewc b;

    public aakd(CobrandCardReviewView cobrandCardReviewView, aajz aajz2, aaju aaju2, eyq eyq2, ewc ewc2) {
        super((View)cobrandCardReviewView, (ewj)aajz2, (ewl)aaju2);
        this.a = eyq2;
        this.b = ewc2;
    }

    void a(Uri uri) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzvCi0AEMunRr38fGRI8djQQ=", "enc::4/LUclrTthywEWD7DFqon1LyIqjMlJInkR9tYB4YDAo=", -5306614988125172036L, 1258289235312994158L, 8091821050864579205L, 4285526870058266813L, null, "enc::Hujfkma6FErbAA/0eTKY9bqMhpAAwEr7RsrksU2sR4o=", 33);
        }
        this.b.startActivity(new Intent("android.intent.action.VIEW", uri));
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzvCi0AEMunRr38fGRI8djQQ=", "enc::MW1qpwovHmeQo3067P3+5lc0PUnPWwDzd8Vuy8gcISQ=", -5306614988125172036L, 1258289235312994158L, -2859438141256472459L, 4285526870058266813L, null, "enc::Hujfkma6FErbAA/0eTKY9bqMhpAAwEr7RsrksU2sR4o=", 37);
        }
        this.a.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzvCi0AEMunRr38fGRI8djQQ=", "enc::QsOr7P4Ehl+vuIfxLhge2t5RvXGs6wMqI5X0rex1YIA=", -5306614988125172036L, 1258289235312994158L, 6865136567210821558L, 4285526870058266813L, null, "enc::Hujfkma6FErbAA/0eTKY9bqMhpAAwEr7RsrksU2sR4o=", 41);
        }
        this.a.a();
        this.a.a();
        this.a.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void k() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzvCi0AEMunRr38fGRI8djQQ=", "enc::Z5D9MNx+GSaQUsTDhAHCeBR7D/7UZs/sAiEUqAFdZiQ=", -5306614988125172036L, 1258289235312994158L, 3524047052945537763L, 4285526870058266813L, null, "enc::Hujfkma6FErbAA/0eTKY9bqMhpAAwEr7RsrksU2sR4o=", 47);
        }
        this.a.a();
        this.a.a();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void l() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzvCi0AEMunRr38fGRI8djQQ=", "enc::lYHnsc7nXtBTmXEGlRFqFZCm7SB+zG20IPFC9qRVS/FY4D2QbUOMS/v8lefIAFz8", -5306614988125172036L, 1258289235312994158L, -3439247291005584840L, 4285526870058266813L, null, "enc::Hujfkma6FErbAA/0eTKY9bqMhpAAwEr7RsrksU2sR4o=", 52);
        }
        this.a.a();
        if (llw2 != null) {
            llw2.i();
        }
    }
}

