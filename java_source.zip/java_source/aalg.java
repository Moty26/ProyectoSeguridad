/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alxc
 *  apbi
 *  axss
 *  com.ubercab.presidio.request_middleware.core.model.MutablePickupRequest
 *  hhy
 *  hpz
 *  iro
 */
import com.ubercab.presidio.request_middleware.core.model.MutablePickupRequest;

public class aalg
implements alws<hhy<Void>, apbi> {
    private final axss<hpz> a;
    private final axss<aakx> b;
    private final axss<MutablePickupRequest> c;

    public aalg(axss<MutablePickupRequest> axss2, axss<aakx> axss3, axss<hpz> axss4) {
        this.a = axss4;
        this.b = axss3;
        this.c = axss2;
    }

    public alxc a() {
        return iro.Q;
    }

    public apbi a(hhy<Void> hhy2) {
        return new aalf((MutablePickupRequest)this.c.get(), (aakx)this.b.get());
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((hhy)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((hhy)object);
    }

    public String b() {
        return "af31d974-a3b2-49b5-80b2-15baa32f3eb8";
    }

    public boolean b(hhy<Void> hhy2) {
        return aaky.a((hpz)this.a.get());
    }
}

