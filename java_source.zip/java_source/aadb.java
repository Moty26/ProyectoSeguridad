/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlj
 */
public interface aadb {
    public Float currentSlideOffset();

    public int currentState();

    public int peekHeight();

    public void setState(int var1);

    public awlj<Float> slideOffset();

    public awlj<Integer> state();
}

