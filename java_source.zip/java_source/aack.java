/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  eqr
 */
import java.lang.reflect.Type;

@eqs(a="geofence-preferences-key")
enum aack implements eqr
{
    a(Boolean.class),
    b(String.class),
    c(Long.class),
    d(String.class),
    e(Long.class),
    f(Long.class);
    
    private final Class g;

    private <T> aack(Class<T> class_) {
        this.g = class_;
    }

    public Type a() {
        return this.g;
    }
}

