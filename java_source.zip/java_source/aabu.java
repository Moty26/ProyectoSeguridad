/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alxc
 *  android.os.Build
 *  android.os.Build$VERSION
 *  axss
 *  com.uber.rib.core.RibActivity
 *  hpz
 *  hqg
 *  irn
 */
import android.os.Build;
import com.uber.rib.core.RibActivity;

public class aabu
implements alws<abhf, abhe> {
    private final axss<hpz> a;
    private final axss<RibActivity> b;

    public aabu(axss<hpz> axss2, axss<RibActivity> axss3) {
        this.a = axss2;
        this.b = axss3;
    }

    public abhe a(abhf abhf2) {
        return new aabt((RibActivity)this.b.get());
    }

    public alxc a() {
        return aabn.b;
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((abhf)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((abhf)object);
    }

    public String b() {
        return "337d1da5-363b-4675-9224-ff0fdb25014c";
    }

    public boolean b(abhf abhf2) {
        if (Build.VERSION.SDK_INT < 25) {
            return false;
        }
        return ((hpz)this.a.get()).a((hqg)irn.APP_SHORTCUTS);
    }
}

