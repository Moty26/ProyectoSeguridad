/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  android.text.format.DateFormat
 *  android.view.View
 *  auhz
 *  auif
 *  awlj
 *  awlp
 *  awnk
 *  com.uber.model.core.generated.crack.cobrandcard.LinkText
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView
 *  com.ubercab.presidio.countrypicker.core.model.Country
 *  com.ubercab.ui.commons.widget.BitLoadingIndicator
 *  com.ubercab.ui.core.UButton
 *  com.ubercab.ui.core.UTextView
 *  eot
 *  eov
 *  eox
 *  exl
 *  llg
 *  llw
 */
import android.content.Context;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.View;
import com.uber.model.core.generated.crack.cobrandcard.LinkText;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.ubercab.presidio.cobrandcard.application.review.CobrandCardReviewView;
import com.ubercab.presidio.countrypicker.core.model.Country;
import com.ubercab.ui.commons.widget.BitLoadingIndicator;
import com.ubercab.ui.core.UButton;
import com.ubercab.ui.core.UTextView;
import java.util.Date;

public class aakb
extends exl<CobrandCardReviewView>
implements aake {
    private final aakc a;
    private final OfferResponse b;

    public aakb(CobrandCardReviewView cobrandCardReviewView, aakc aakc2, OfferResponse offerResponse) {
        super((View)cobrandCardReviewView);
        this.b = offerResponse;
        ((CobrandCardReviewView)this.i()).a((aake)this);
        this.a = aakc2;
    }

    private String a(String string, String string2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::VG90ZwOhIlFWarBUtfxiLSwcD+gvzQx3QHnIhoBXwt+2H1M7A5aVMmoHwVvKGBRgVgWq32+jy4N10RVv/U/5JS044v8a+hIj0i+1bgXT5RA=", -5306614988125172036L, -1230378072149238028L, 424310548575579625L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 158);
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (!TextUtils.isEmpty((CharSequence)string)) {
            stringBuilder.append(string);
        }
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            if (!TextUtils.isEmpty((CharSequence)string)) {
                stringBuilder.append(" ");
            }
            stringBuilder.append(string2);
        }
        string = stringBuilder.toString();
        if (llw2 != null) {
            llw2.i();
        }
        return string;
    }

    private String b(aagr object) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::ET5Rezm41KStvPcYjLDzxeKaxVgDI4TiUWB/dn3hLj3VGzc7sRuB6Jk4Fo5d3VdKWfFw2C5Cr3h748+xs7BliiWM6ffuyJ21dSKGTWei02wgKWQHBO5sTh9HvaxnpzRU7kwuzInhDxHynNVemMd7WMwHFjpgvHCU5qCkAVR1AH5yg0jeQpKJCRTtp03Yqmnp", -5306614988125172036L, -1230378072149238028L, 5288704614999029141L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 172);
        }
        StringBuilder stringBuilder = new StringBuilder(object.a());
        if (!TextUtils.isEmpty((CharSequence)object.b())) {
            stringBuilder.append(", ").append(object.b());
        }
        object = stringBuilder.toString();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    private String c(aagr object) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::ET5Rezm41KStvPcYjLDzxaI33TNaA3vALlPwRl8bDzlrdE60RpNDLuI047KlcjfrDnoch/HmcMgnM1dr1N5ydN1dN1o1WAEpS31VcJhibWaDQNTtTiMdwTPv0AugsnkTtlTNmLiF16AGIPRC6z9W49YpgUhbeKzunMK7IPEJHXz+bDyDOLTG7ZPaib3xP4xX", -5306614988125172036L, -1230378072149238028L, -1486064947045474747L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 180);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(object.c()).append(", ").append(object.d()).append(" ").append(object.e());
        object = stringBuilder.toString();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(aagr aagr2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::0uc0pMyr/NKB4DycUhkpmvI0Z5uND1jlDwnmdZuk4hMIALYKF6RuI19qwBQGQXXjaLLToqSigc+CWHVP6GfKY5eXYxIJYOLv87KRewJrGtEw4TH3qcYkgzOx3ILvywd+1FLRitLByzXHtcbtnSvedh5S1j2G3ooBfLrMypnTBsQ=", -5306614988125172036L, -1230378072149238028L, -8409910476164712724L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 137) : null;
        ((CobrandCardReviewView)this.i()).h().setText((CharSequence)this.b(aagr2));
        ((CobrandCardReviewView)this.i()).i().setText((CharSequence)this.c(aagr2));
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(aags aags2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::r4ji8mEmh0V3cRIsvziWBqbz9UUWmo7AAUsnI20CyLSVSPnXjvlj27qcfPyoQGdsLc1MBJShca+H0kO3/+3irEq9xF/8vY7ia/3sGQ8nZYF64/SG7m4dU3SVGV5fm7cGPkGy8G2KIMAdzoZeAOlZQiuUxXwcgrj3q3jvzwllfIM=", -5306614988125172036L, -1230378072149238028L, 6669925057145545078L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 117) : null;
        Context context = ((CobrandCardReviewView)this.i()).getContext();
        ((CobrandCardReviewView)this.i()).c().setText((CharSequence)this.a(aags2.a(), aags2.b()));
        ((CobrandCardReviewView)this.i()).d().setText((CharSequence)aags2.c());
        ((CobrandCardReviewView)this.i()).e().setText((CharSequence)aags2.d());
        if (aags2.e() != null) {
            String string = DateFormat.getDateFormat((Context)context).format(new Date(aags2.e()));
            ((CobrandCardReviewView)this.i()).f().setText((CharSequence)context.getString(aafx.cobrandcard_review_personal_section_dob, new Object[]{string}));
        }
        if (aags2.f() != null) {
            ((CobrandCardReviewView)this.i()).g().setText((CharSequence)context.getString(aafx.cobrandcard_review_personal_section_country, new Object[]{aags2.f().getIsoCode()}));
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(aagt aagt2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::ErP0EhDx2u+jfqXP4r38IOYm9/0wmk/4v0cNCW7uFRNxmUJHi19iNRD5WEcF0aF6QcRJNG0OCBftXhuskHbSIYT/bXwLCLiRruxgp6amxfiwJuEvEq643y+HmGFsBXckKRJzyp+sf681Ks/A9fKMU7494a//q9gFT0SExHdhROQ=", -5306614988125172036L, -1230378072149238028L, -9135825177914824590L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 142) : null;
        Context context = ((CobrandCardReviewView)this.i()).getContext();
        String string = aagt2.a();
        string = string.substring(string.length() - 4);
        string = context.getString(aafx.cobrandcard_review_financial_section_ssn, new Object[]{string});
        ((CobrandCardReviewView)this.i()).j().setText((CharSequence)string);
        ((CobrandCardReviewView)this.i()).k().setText((CharSequence)context.getString(aafx.cobrandcard_review_financial_section_income, new Object[]{String.valueOf(aagt2.c())}));
        ((CobrandCardReviewView)this.i()).l().setText((CharSequence)context.getString(aafx.cobrandcard_review_financial_occupation, new Object[]{aagt2.d()}));
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a(String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::I0QmPe+NO5d0D/2Ew43CajaumLkG9CAxAWiqXDdLprodGtanA/RaIjXqGGFH4Tbe", -5306614988125172036L, -1230378072149238028L, -6393166041258023491L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 113);
        }
        this.a.a(string);
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::mHjNXpidAhZ1UI8Bj9wOhNESYLsWWaNS+Ga0pIiMDWk=", -5306614988125172036L, -1230378072149238028L, 8792004404122595672L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 55);
        }
        super.f();
        ((eov)((CobrandCardReviewView)this.i()).b().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                aakb.this.a.d();
            }
        });
        ((eov)((CobrandCardReviewView)this.i()).m().g().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                aakb.this.a.e();
            }
        });
        ((eov)((CobrandCardReviewView)this.i()).n().g().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                aakb.this.a.f();
            }
        });
        ((eov)((CobrandCardReviewView)this.i()).o().g().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                aakb.this.a.m();
            }
        });
        ((eov)((CobrandCardReviewView)this.i()).q().i().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                ((CobrandCardReviewView)aakb.this.i()).p().f();
                ((CobrandCardReviewView)aakb.this.i()).q().setVisibility(8);
                ((CobrandCardReviewView)aakb.this.i()).r().setVisibility(0);
                ((CobrandCardReviewView)aakb.this.i()).s();
            }
        });
        if (this.b != null) {
            ((CobrandCardReviewView)this.i()).a(this.b.applicationFooter());
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void g() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmNDEk8dnhsrP+d7vOb9oZ/pkl1ikJhQ8tVwASMwiQjzokirm3Erz1VW79T8tiEOYM=", "enc::LIu0KBS4aHqYF90tspXATwkCV1XhZpU1szXsfmGftnU=", -5306614988125172036L, -1230378072149238028L, -5669698541601424854L, 1953763409102406465L, null, "enc::Hujfkma6FErbAA/0eTKY9TP+dii/w25kyU5HziOmM9I=", 49) : null;
        super.g();
        ((CobrandCardReviewView)this.i()).a(null);
        if (llw2 != null) {
            llw2.i();
        }
    }

}

