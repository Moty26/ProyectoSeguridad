/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.animation.Interpolator
 *  ta
 *  tc
 *  td
 */
import android.view.View;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Iterator;

public class aag {
    final ArrayList<ta> a;
    tc b;
    private long c = -1;
    private Interpolator d;
    private boolean e;
    private final td f;

    public aag() {
        this.f = new td(){
            private boolean b;
            private int c;

            void a() {
                this.c = 0;
                this.b = false;
                aag.this.b();
            }

            public void onAnimationEnd(View view) {
                int n;
                this.c = n = this.c + 1;
                if (n == aag.this.a.size()) {
                    if (aag.this.b != null) {
                        aag.this.b.onAnimationEnd(null);
                    }
                    this.a();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public void onAnimationStart(View view) {
                if (this.b) {
                    return;
                }
                this.b = true;
                if (aag.this.b == null) return;
                aag.this.b.onAnimationStart(null);
            }
        };
        this.a = new ArrayList();
    }

    public aag a(long l) {
        if (!this.e) {
            this.c = l;
        }
        return this;
    }

    public aag a(Interpolator interpolator) {
        if (!this.e) {
            this.d = interpolator;
        }
        return this;
    }

    public aag a(ta ta2) {
        if (!this.e) {
            this.a.add(ta2);
        }
        return this;
    }

    public aag a(ta ta2, ta ta3) {
        this.a.add(ta2);
        ta3.b(ta2.a());
        this.a.add(ta3);
        return this;
    }

    public aag a(tc tc2) {
        if (!this.e) {
            this.b = tc2;
        }
        return this;
    }

    public void a() {
        if (this.e) {
            return;
        }
        for (ta ta2 : this.a) {
            if (this.c >= 0) {
                ta2.a(this.c);
            }
            if (this.d != null) {
                ta2.a(this.d);
            }
            if (this.b != null) {
                ta2.a((tc)this.f);
            }
            ta2.c();
        }
        this.e = true;
    }

    void b() {
        this.e = false;
    }

    public void c() {
        if (!this.e) {
            return;
        }
        Iterator<ta> iterator = this.a.iterator();
        while (iterator.hasNext()) {
            iterator.next().b();
        }
        this.e = false;
    }

}

