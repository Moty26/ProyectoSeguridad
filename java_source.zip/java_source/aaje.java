/*
 * Decompiled with CFR 0_119.
 */
interface aaje {
    public void d();

    public void e();
}

