/*
 * Decompiled with CFR 0_119.
 */
public interface aacg {
    public void a();

    public void a(String var1);
}

