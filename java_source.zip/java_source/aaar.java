/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  ewc
 *  zye
 */
class aaar
implements axss<ewc> {
    private final zye a;

    aaar(zye zye2) {
        this.a = zye2;
    }

    public ewc a() {
        return (ewc)awec.a((Object)this.a.e(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

