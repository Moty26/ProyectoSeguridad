/*
 * Decompiled with CFR 0_119.
 */
public class aagt {
    private final String a;
    private final String b;
    private final int c;
    private final String d;

    public aagt(String string, String string2, int n, String string3) {
        this.a = string;
        this.b = string2;
        this.c = n;
        this.d = string3;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public int c() {
        return this.c;
    }

    public String d() {
        return this.d;
    }
}

