/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  ewz
 *  zqq
 *  zye
 */
import android.view.ViewGroup;

public class aabk
implements zqq<aabj> {
    private final zye a;

    aabk(zye zye2) {
        this.a = zye2;
    }

    public /* synthetic */ ewz a(ViewGroup viewGroup) {
        return this.b(viewGroup);
    }

    public aabj b(ViewGroup viewGroup) {
        return new aaaw(this.a).b();
    }
}

