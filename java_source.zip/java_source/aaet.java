/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

public class aaet
extends exk<CobrandCardOfferView, aafh, aaey> {
    public aaet(aaey aaey2) {
        super((Object)aaey2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aafh b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfth3dNCmRlgP04srFzQi3B5A==", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2R1PLk5O/qE8q7J20F2raPrlGof0B4VOxLkYGAZFEEVTFQ/H4ZXEVcPQfViB58AXxxNSd1G5r1IkIaHWXgS3sHg==", 3892689495945724297L, -7313363316936197009L, -1421991459390297703L, 7185931817553012858L, null, "enc::AV00HDwcdxyM9iF6Lm5WD06bsPNVJCSStAn5nNmVZxE=", 48) : null;
        object = (CobrandCardOfferView)this.a_((ViewGroup)object);
        aafc aafc2 = new aafc();
        object = aafi.b().a((aaey)this.bS_()).a((CobrandCardOfferView)object).a(aafc2).a().a();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected CobrandCardOfferView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gkleieOAmkN4vNoUfMTEOfth3dNCmRlgP04srFzQi3B5A==", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zOg/7JBtPKlhoSFic4JbQS37hKI9RzXqGiHCFX1MlDR+8/e7HqEFnI9fBAgD4YClq", 3892689495945724297L, -7313363316936197009L, 7512380192017381731L, 7185931817553012858L, null, "enc::AV00HDwcdxyM9iF6Lm5WD06bsPNVJCSStAn5nNmVZxE=", 60) : null;
        layoutInflater = (CobrandCardOfferView)layoutInflater.inflate(aafw.ub__cobrandcard_offer, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

