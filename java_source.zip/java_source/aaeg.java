/*
 * Decompiled with CFR 0_119.
 */
public interface aaeg<C extends aaej> {
    public C e();
}

