/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 */
import android.view.ViewGroup;

public interface aanx {
    public aaox a(aaow var1, ViewGroup var2);
}

