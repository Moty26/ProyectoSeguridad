/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  bcs
 *  bdv
 *  bfs
 *  bfv
 *  bgl
 *  bgm
 *  bgn
 *  bgo
 *  com.google.android.gms.auth.api.signin.GoogleSignInOptions
 *  ewf
 *  ewj
 *  ewn
 *  zql
 *  zyb
 *  zyc
 */
import android.content.Context;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

public class aaad
extends ewn<aaaj> {
    public aaad(aaaj aaaj2) {
        super((ewj)aaaj2);
    }

    aaai a(Context context, bgl bgl2) {
        return new aaai(context, bgl2);
    }

    bgl a(Context context) {
        GoogleSignInOptions googleSignInOptions = new bdv(GoogleSignInOptions.d).b().a(aaai.a(context)).d();
        return new bgm(context).a((bgn)this.d()).a((bgo)this.d()).a(bcs.e, (bfv)googleSignInOptions).b();
    }

    ewf a() {
        return new ewf();
    }

    zyb a(aaai aaai2, zql zql2) {
        return new zyb(50002, "google", (zyc)aaai2, zql2);
    }
}

