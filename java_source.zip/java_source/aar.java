/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.BaseAdapter
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

class aar
extends BaseAdapter {
    final /* synthetic */ aaq a;
    private int b;

    public aar(aaq aaq2) {
        this.a = aaq2;
        this.b = -1;
        this.a();
    }

    public aax a(int n) {
        int n2;
        ArrayList<aax> arrayList = this.a.c.l();
        n = n2 = this.a.e + n;
        if (this.b >= 0) {
            n = n2;
            if (n2 >= this.b) {
                n = n2 + 1;
            }
        }
        return arrayList.get(n);
    }

    void a() {
        aax aax2 = this.a.c.r();
        if (aax2 != null) {
            ArrayList<aax> arrayList = this.a.c.l();
            int n = arrayList.size();
            for (int i = 0; i < n; ++i) {
                if (arrayList.get(i) != aax2) continue;
                this.b = i;
                return;
            }
        }
        this.b = -1;
    }

    public int getCount() {
        int n = this.a.c.l().size() - this.a.e;
        if (this.b < 0) {
            return n;
        }
        return n - 1;
    }

    public /* synthetic */ Object getItem(int n) {
        return this.a(n);
    }

    public long getItemId(int n) {
        return n;
    }

    public View getView(int n, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.a.b.inflate(this.a.g, viewGroup, false);
        }
        ((abk)view).a(this.a(n), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        this.a();
        super.notifyDataSetChanged();
    }
}

