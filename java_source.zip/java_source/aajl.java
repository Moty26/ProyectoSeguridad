/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

class aajl
implements axss<OfferResponse> {
    private final aaiw a;

    aajl(aaiw aaiw2) {
        this.a = aaiw2;
    }

    public OfferResponse a() {
        return this.a.h();
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

