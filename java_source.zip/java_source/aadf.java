/*
 * Decompiled with CFR 0_119.
 */
public interface aadf {
    public void a(boolean var1);

    public int c();

    public boolean d();
}

