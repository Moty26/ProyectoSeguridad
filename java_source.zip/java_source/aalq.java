/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  com.uber.rib.core.RibActivity
 *  fbz
 */
import com.uber.rib.core.RibActivity;

public final class aalq
implements awdv<aalj> {
    static final /* synthetic */ boolean a;
    private final axss<RibActivity> b;
    private final axss<fbz> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aalq.class.desiredAssertionStatus();
        a = bl;
    }

    public aalq(axss<RibActivity> axss2, axss<fbz> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdv<aalj> a(axss<RibActivity> axss2, axss<fbz> axss3) {
        return new aalq(axss2, axss3);
    }

    public aalj a() {
        return (aalj)awec.a((Object)aalp.a((RibActivity)this.b.get(), (fbz)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

