/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aapd
implements axss<hlg> {
    private final aaow a;

    aapd(aaow aaow2) {
        this.a = aaow2;
    }

    public hlg a() {
        return (hlg)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

