/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  eyq
 */
class aakk
implements axss<eyq> {
    private final aajw a;

    aakk(aajw aajw2) {
        this.a = aajw2;
    }

    public eyq a() {
        return (eyq)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

