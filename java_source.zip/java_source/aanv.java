/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.view.View
 *  atsi
 *  atvc
 *  atvd
 *  com.ubercab.presidio.consent.primer.PrimerView
 *  com.ubercab.rds.common.app.RdsCallerIdentifier
 *  ewc
 *  ewj
 *  ewl
 *  exm
 *  llg
 *  llw
 */
import android.content.Intent;
import android.view.View;
import com.ubercab.presidio.consent.primer.PrimerView;
import com.ubercab.rds.common.app.RdsCallerIdentifier;

public class aanv
extends exm<PrimerView, aanr, aank> {
    private final ewc a;
    private final atvd b;
    private atvc c;

    public aanv(PrimerView primerView, aanr aanr2, aank aank2, ewc ewc2, atvd atvd2) {
        super((View)primerView, (ewj)aanr2, (ewl)aank2);
        this.a = ewc2;
        this.b = atvd2;
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(aanp aanp2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM1PsRPm9KTNiA7slvc3NLJwdbbjcZtvsv03AfiqVGssgA==", "enc::MNP8yNpl5nl/UTx+kg65bFajfc1VGyT0bOKnjTOMtyQsX9ku1cbecyG/RamU6OesxdoELlSDjBUjmrTDz8Evoeb2HFwlsfeVRWo0foibxc0=", -1924344159138755995L, 2888338294366021473L, 582418750870130044L, 4285526870058266813L, null, "enc::b/Zkm0N8aDWe+lIWRordDj6OVo9dJLkgegOWsNO0yek=", 44);
        }
        if (aanp2.u() != null) {
            if (this.c == null) {
                this.c = this.b.b(aanp2.u());
            }
            if (this.c != null) {
                aanp2 = this.c.a(aanp2.u(), atsi.c);
                this.a.startActivity((Intent)aanp2);
            }
        }
        if (llw2 != null) {
            llw2.i();
        }
    }
}

