/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hqg
 */
public enum aapz implements hqg
{
    SHOW_MESSAGE_OPTION_AS_SMS;
    

    private aapz() {
    }
}

