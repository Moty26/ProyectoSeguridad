/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlj
 */
public interface aaob {
    public awlj<String> a();
}

