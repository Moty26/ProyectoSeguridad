/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdv
 *  awec
 *  axss
 *  bgl
 */
import android.content.Context;

public final class aaae
implements awdv<bgl> {
    static final /* synthetic */ boolean a;
    private final aaad b;
    private final axss<Context> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaae.class.desiredAssertionStatus();
        a = bl;
    }

    public aaae(aaad aaad2, axss<Context> axss2) {
        if (!a && aaad2 == null) {
            throw new AssertionError();
        }
        this.b = aaad2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
    }

    public static awdv<bgl> a(aaad aaad2, axss<Context> axss2) {
        return new aaae(aaad2, axss2);
    }

    public bgl a() {
        return (bgl)awec.a((Object)this.b.a((Context)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

