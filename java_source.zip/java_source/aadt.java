/*
 * Decompiled with CFR 0_119.
 */
public enum aadt {
    a("806f9a95-4b83"),
    b("2eb426f6-01ad"),
    c("2641ada6-e567"),
    d("7d83b103-85ae"),
    e("db802d26-20e0"),
    f("746e5a50-5203"),
    g("86d32d54-3c82"),
    h("4969fff1-9062"),
    i("709c3758-4fd2");
    
    private String j;

    private aadt(String string2) {
        this.j = string2;
    }

    String a() {
        return this.j;
    }
}

