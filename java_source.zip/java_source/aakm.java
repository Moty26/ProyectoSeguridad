/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.os.Handler
 *  android.os.IBinder
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.view.inputmethod.InputMethodManager
 */
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

public final class aakm {
    private static Window a(Context context) {
        Window window = aakm.c(context);
        context = window;
        if (window == null) {
            context = null;
        }
        return context;
    }

    public static Integer a(Context context, int n) {
        if ((context = aakm.a(context)) == null) {
            return null;
        }
        int n2 = context.getAttributes().softInputMode;
        context.setSoftInputMode(n);
        return n2;
    }

    public static void a(View view, Runnable runnable) {
        InputMethodManager inputMethodManager = (InputMethodManager)view.getContext().getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        new Handler().postDelayed(runnable, 200);
    }

    private static Activity b(Context context) {
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity)context;
            }
            context = ((ContextWrapper)context).getBaseContext();
        }
        return null;
    }

    private static Window c(Context context) {
        if ((context = aakm.b(context)) != null) {
            return context.getWindow();
        }
        return null;
    }
}

