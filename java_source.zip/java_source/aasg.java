/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  awdv
 *  axss
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 */
import android.content.res.Resources;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public final class aasg
implements awdv<aase> {
    static final /* synthetic */ boolean a;
    private final axss<ContactPickerCustomization> b;
    private final axss<aasf> c;
    private final axss<Resources> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aasg.class.desiredAssertionStatus();
        a = bl;
    }

    public aasg(axss<ContactPickerCustomization> axss2, axss<aasf> axss3, axss<Resources> axss4) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
    }

    public static awdv<aase> a(axss<ContactPickerCustomization> axss2, axss<aasf> axss3, axss<Resources> axss4) {
        return new aasg(axss2, axss3, axss4);
    }

    public aase a() {
        return new aase((ContactPickerCustomization)this.b.get(), (aasf)this.c.get(), (Resources)this.d.get());
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

