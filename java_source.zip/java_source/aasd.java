/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.ubercab.presidio.contacts.model.Contact
 *  com.ubercab.presidio.contacts.model.ContactDetail
 */
import android.view.View;
import com.ubercab.presidio.contacts.model.Contact;
import com.ubercab.presidio.contacts.model.ContactDetail;

public class aasd
extends aatb {
    public final Contact a;
    public final ContactDetail b;
    public final View.OnClickListener c;
    public final int d;
    public final boolean e;
    public final boolean f;

    aasd(Contact contact, ContactDetail contactDetail, View.OnClickListener onClickListener, int n, boolean bl) {
        this(contact, contactDetail, onClickListener, n, bl, true);
    }

    aasd(Contact contact, ContactDetail contactDetail, View.OnClickListener onClickListener, int n, boolean bl, boolean bl2) {
        super(0);
        this.a = contact;
        this.b = contactDetail;
        this.c = onClickListener;
        this.d = n;
        this.e = bl;
        this.f = bl2;
    }
}

