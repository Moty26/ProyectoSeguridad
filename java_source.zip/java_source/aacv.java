/*
 * Decompiled with CFR 0_119.
 */
public final class aacv {
    private String a = null;
    private int b = 0;
    private long c = Long.MIN_VALUE;
    private short d = -1;
    private double e;
    private double f;
    private float g;
    private int h = 0;
    private int i = -1;

    public aacu a() {
        if (this.a == null) {
            throw new IllegalArgumentException("Request ID not set.");
        }
        if (this.b == 0) {
            throw new IllegalArgumentException("Transitions types not set.");
        }
        if ((this.b & 4) != 0 && this.i < 0) {
            throw new IllegalArgumentException("Non-negative loitering delay needs to be set when transition types include GEOFENCE_TRANSITION_DWELLING.");
        }
        if (this.c == Long.MIN_VALUE) {
            throw new IllegalArgumentException("Expiration not set.");
        }
        if (this.d == -1) {
            throw new IllegalArgumentException("Geofence region not set.");
        }
        if (this.h < 0) {
            throw new IllegalArgumentException("Notification responsiveness should be nonnegative.");
        }
        return new aacu(this.a, this.e, this.f, this.g, this.c, this.b, this.i, this.h);
    }

    public aacv a(double d, double d2, float f) {
        this.d = 1;
        this.e = d;
        this.f = d2;
        this.g = f;
        return this;
    }

    public aacv a(int n) {
        this.b = n;
        return this;
    }

    public aacv a(long l) {
        if (l < 0) {
            this.c = -1;
            return this;
        }
        this.c = l;
        return this;
    }

    public aacv a(String string) {
        this.a = string;
        return this;
    }

    public aacv b(int n) {
        this.i = n;
        return this;
    }
}

