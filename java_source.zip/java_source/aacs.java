/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.os.Bundle
 *  bfs
 *  bgl
 *  bgm
 *  bgn
 *  bgo
 *  bgp
 *  bgs
 *  bgt
 *  com.google.android.gms.common.ConnectionResult
 *  com.google.android.gms.common.api.Status
 *  com.google.android.gms.location.GeofencingRequest
 *  dqw
 *  dqx
 *  dqy
 *  dra
 *  drd
 *  le
 */
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.GeofencingRequest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class aacs
extends aacr
implements bgn,
bgo {
    private final bgl b;
    private aacg c;
    private PendingIntent d;
    private List<aacu> e;

    public aacs(Context context) {
        super(context);
        this.b = new bgm(context).a((bgn)this).a((bgo)this).a(drd.a).b();
    }

    private GeofencingRequest a() {
        dra dra2 = new dra();
        dra2.a(5);
        dra2.a(this.b());
        return dra2.a();
    }

    private dqw a(aacu aacu2) {
        return new dqx().a(aacu2.a()).a(aacu2.b(), aacu2.c(), aacu2.d()).a(aacu2.e()).c(aacu2.g()).a(aacu2.f()).b(aacu2.h()).a();
    }

    private List<dqw> b() {
        if (this.e == null || this.e.isEmpty()) {
            return null;
        }
        ArrayList<dqw> arrayList = new ArrayList<dqw>();
        Iterator<aacu> iterator = this.e.iterator();
        while (iterator.hasNext()) {
            arrayList.add(this.a(iterator.next()));
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     */
    @SuppressLint(value={"SupportAnnotationUsage"})
    private void c() {
        if (this.d == null || le.a((Context)this.a, (String)"android.permission.ACCESS_FINE_LOCATION") != 0) {
            return;
        }
        drd.c.a(this.b, this.a(), this.d).a((bgt)new bgt<Status>(){

            public void a(Status status) {
                if (aacs.this.c == null) {
                    return;
                }
                if (status.d()) {
                    aacs.this.c.a();
                    return;
                }
                aacs.this.c.a(status.a());
            }
        });
    }

    public void a(int n) {
    }

    public void a(Bundle bundle) {
        this.c();
    }

    public void a(ConnectionResult object) {
        if ((object = object.e()) != null && this.c != null) {
            this.c.a((String)object);
        }
    }

    @Override
    public void a(List<aacu> list, PendingIntent pendingIntent, aacg aacg2) {
        this.e = list;
        this.d = pendingIntent;
        this.c = aacg2;
        if (this.b.k()) {
            return;
        }
        if (this.b.j()) {
            this.c();
            return;
        }
        this.b.e();
    }

}

