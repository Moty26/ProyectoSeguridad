/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  awdr
 *  awdv
 *  awea
 *  axss
 *  ejv
 */
import android.view.LayoutInflater;

public final class aaru
implements awdv<aart> {
    static final /* synthetic */ boolean a;
    private final awdr<aart> b;
    private final axss<LayoutInflater> c;
    private final axss<aaqg> d;
    private final axss<ejv> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaru.class.desiredAssertionStatus();
        a = bl;
    }

    public aaru(awdr<aart> awdr2, axss<LayoutInflater> axss2, axss<aaqg> axss3, axss<ejv> axss4) {
        if (!a && awdr2 == null) {
            throw new AssertionError();
        }
        this.b = awdr2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.e = axss4;
    }

    public static awdv<aart> a(awdr<aart> awdr2, axss<LayoutInflater> axss2, axss<aaqg> axss3, axss<ejv> axss4) {
        return new aaru(awdr2, axss2, axss3, axss4);
    }

    public aart a() {
        return (aart)((Object)awea.a(this.b, (Object)((Object)new aart((LayoutInflater)this.c.get(), (aaqg)this.d.get(), (ejv)this.e.get()))));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

