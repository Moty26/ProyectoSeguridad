/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  aj
 *  r
 *  u
 *  y
 */
public class aa
extends aj {
    private int al = 0;

    public void a(int n) {
        this.al = n;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(u u2, int n) {
        this.u[0] = this.m;
        this.u[2] = this.n;
        this.u[1] = this.o;
        this.u[3] = this.p;
        for (n = 0; n < this.u.length; ++n) {
            this.u[n].f = u2.a((Object)this.u[n]);
        }
        if (this.al < 0 || this.al >= 4) return;
        {
            ab ab2 = this.u[this.al];
            for (n = 0; n < this.ak; ++n) {
                y y2;
                this.aj[n].u[this.al].f = y2 = u2.a((Object)this.aj[n].u[this.al]);
                if (this.al == 0 || this.al == 2) {
                    u2.b(ab2.f, y2, 0, 0);
                    continue;
                }
                u2.a(ab2.f, y2, 0, 0);
            }
            if (this.al == 0) {
                u2.c(this.o.f, this.m.f, 0, 5);
                return;
            } else {
                if (this.al == 1) {
                    u2.c(this.m.f, this.o.f, 0, 5);
                    return;
                }
                if (this.al == 2) {
                    u2.c(this.p.f, this.n.f, 0, 5);
                    return;
                }
                if (this.al != 3) return;
                {
                    u2.c(this.n.f, this.p.f, 0, 5);
                    return;
                }
            }
        }
    }
}

