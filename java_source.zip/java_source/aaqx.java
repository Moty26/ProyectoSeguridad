/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  awlq
 *  axrq
 *  com.ubercab.presidio.contacts.dropdown.ContactsDropDownView
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  ejv
 *  ewj
 *  ewk
 */
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import com.ubercab.presidio.contacts.dropdown.ContactsDropDownView;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public class aaqx
extends ewk<aarh, ContactsDropDownView> {
    public aaqx(aarh aarh2, ContactsDropDownView contactsDropDownView) {
        super((ewj)aarh2, (View)contactsDropDownView);
    }

    aaqg a(ContactPickerCustomization contactPickerCustomization) {
        return new aaqg(contactPickerCustomization.getDefaultPhoneNumberCountryIso2());
    }

    aark a(ContactPickerCustomization contactPickerCustomization, aart aart2) {
        return new aark(contactPickerCustomization, (ContactsDropDownView)this.c(), aart2);
    }

    aasf a() {
        return (aasf)this.d();
    }

    aaqh b(ContactPickerCustomization contactPickerCustomization) {
        return new aaqh(contactPickerCustomization.getDefaultPhoneNumberCountryIso2());
    }

    LayoutInflater b() {
        return LayoutInflater.from((Context)((ContactsDropDownView)this.c()).getContext());
    }

    ejv e() {
        return ejv.a((Context)((ContactsDropDownView)this.c()).getContext());
    }

    Resources f() {
        return ((ContactsDropDownView)this.c()).getResources();
    }

    awlq g() {
        return axrq.b();
    }
}

