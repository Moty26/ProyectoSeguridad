/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  apaq
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  awlj
 *  axss
 *  com.uber.model.core.generated.rtapi.services.communications.CommunicationsClient
 *  com.uber.model.core.generated.rtapi.services.communications.CommunicationsClient_Factory
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.contact_driver.model.ContactDriverData
 *  esc
 *  ewf
 *  ewj
 *  ewq
 *  eyq
 *  fbz
 *  hpz
 */
import com.uber.model.core.generated.rtapi.services.communications.CommunicationsClient;
import com.uber.model.core.generated.rtapi.services.communications.CommunicationsClient_Factory;
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.contact_driver.model.ContactDriverData;

public final class aaoy
implements aaoj {
    static final /* synthetic */ boolean a;
    private axss<ewf> b;
    private axss<RibActivity> c;
    private axss<hpz> d;
    private axss<esc<apap>> e;
    private axss<CommunicationsClient<apap>> f;
    private axss<awlj<ContactDriverData>> g;
    private axss<aaoq> h;
    private axss<aaot> i;
    private axss<hlg> j;
    private axss<fbz> k;
    private axss<apaq> l;
    private awdr<aaor> m;
    private axss<aaoj> n;
    private axss<eyq> o;
    private axss<aaox> p;
    private axss<aapu> q;
    private axss<aaob> r;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaoy.class.desiredAssertionStatus();
        a = bl;
    }

    private aaoy(aaoz aaoz2) {
        if (!a && aaoz2 == null) {
            throw new AssertionError();
        }
        this.a(aaoz2);
    }

    private void a(aaoz aaoz2) {
        this.b = awdu.a(aaon.a(aaoz.a(aaoz2)));
        this.c = new aapg(aaoz.b(aaoz2));
        this.d = new aapa(aaoz.b(aaoz2));
        this.e = new aapf(aaoz.b(aaoz2));
        this.f = CommunicationsClient_Factory.create(this.e);
        this.g = new aapb(aaoz.b(aaoz2));
        this.h = awdu.a(aaol.a(aaoz.a(aaoz2)));
        this.i = new aapc(aaoz.b(aaoz2));
        this.j = new aapd(aaoz.b(aaoz2));
        this.k = new aape(aaoz.b(aaoz2));
        this.l = new aaph(aaoz.b(aaoz2));
        this.m = aaov.a(this.b, this.c, this.d, this.f, this.g, this.h, this.i, this.j, this.k, this.l);
        this.n = awdw.a((Object)this);
        this.o = new aapi(aaoz.b(aaoz2));
        this.p = awdu.a(aaop.a(aaoz.a(aaoz2), this.n, this.o));
        this.q = awdu.a(aaom.a(aaoz.a(aaoz2)));
        this.r = awdu.a(aaoo.a(aaoz.a(aaoz2)));
    }

    public static aaoz b() {
        return new aaoz(null);
    }

    public /* synthetic */ ewq O_() {
        return this.d();
    }

    @Override
    public aaox a() {
        return (aaox)((Object)this.p.get());
    }

    public void a(aaor aaor2) {
        this.m.a((Object)aaor2);
    }

    public ewf d() {
        return (ewf)this.b.get();
    }

    @Override
    public aapu e() {
        return (aapu)this.q.get();
    }

    @Override
    public aaob f() {
        return (aaob)this.r.get();
    }

    @Override
    public fbz g() {
        return (fbz)this.k.get();
    }

}

