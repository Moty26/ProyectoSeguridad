/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.cobrandcard.application.personalinfo.CobrandCardPersonalInfoView
 *  ewj
 *  ewk
 *  eyq
 */
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.personalinfo.CobrandCardPersonalInfoView;

public class aaiv
extends ewk<aajb, CobrandCardPersonalInfoView> {
    public aaiv(aajb aajb2, CobrandCardPersonalInfoView cobrandCardPersonalInfoView) {
        super((ewj)aajb2, (View)cobrandCardPersonalInfoView);
    }

    aajd a(aajq aajq2, aagq aagq2) {
        return new aajd((CobrandCardPersonalInfoView)this.c(), (aaje)this.d(), aajq2, aagq2);
    }

    aajf a(aaiu aaiu2, eyq eyq2) {
        return new aajf((CobrandCardPersonalInfoView)this.c(), (aajb)this.d(), aaiu2, eyq2, new abtp(aaiu2), new aahb(aaiu2));
    }

    aajq a() {
        return new aajq();
    }

    abua b() {
        return (abua)this.d();
    }
}

