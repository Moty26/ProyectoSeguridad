/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aaoo
implements awdv<aaob> {
    static final /* synthetic */ boolean a;
    private final aaok b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaoo.class.desiredAssertionStatus();
        a = bl;
    }

    public aaoo(aaok aaok2) {
        if (!a && aaok2 == null) {
            throw new AssertionError();
        }
        this.b = aaok2;
    }

    public static awdv<aaob> a(aaok aaok2) {
        return new aaoo(aaok2);
    }

    public aaob a() {
        return (aaob)awec.a((Object)this.b.e(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

