/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.ActionMode
 *  android.view.ActionMode$Callback
 *  android.view.Menu
 *  android.view.MenuItem
 *  nd
 *  ne
 *  qk
 *  zw
 *  zx
 */
import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import java.util.ArrayList;

public class aac
implements zx {
    final ActionMode.Callback a;
    final Context b;
    final ArrayList<aab> c;
    final qk<Menu, Menu> d;

    public aac(Context context, ActionMode.Callback callback) {
        this.b = context;
        this.a = callback;
        this.c = new ArrayList();
        this.d = new qk();
    }

    private Menu a(Menu menu) {
        Menu menu2;
        Menu menu3 = menu2 = (Menu)this.d.get((Object)menu);
        if (menu2 == null) {
            menu3 = abl.a(this.b, (nd)menu);
            this.d.put((Object)menu, (Object)menu3);
        }
        return menu3;
    }

    public void a(zw zw2) {
        this.a.onDestroyActionMode(this.b(zw2));
    }

    public boolean a(zw zw2, Menu menu) {
        return this.a.onCreateActionMode(this.b(zw2), this.a(menu));
    }

    public boolean a(zw zw2, MenuItem menuItem) {
        return this.a.onActionItemClicked(this.b(zw2), abl.a(this.b, (ne)menuItem));
    }

    public ActionMode b(zw object) {
        int n = this.c.size();
        for (int i = 0; i < n; ++i) {
            aab aab2 = this.c.get(i);
            if (aab2 == null || aab2.b != object) continue;
            return aab2;
        }
        object = new aab(this.b, (zw)object);
        this.c.add((aab)((Object)object));
        return object;
    }

    public boolean b(zw zw2, Menu menu) {
        return this.a.onPrepareActionMode(this.b(zw2), this.a(menu));
    }
}

