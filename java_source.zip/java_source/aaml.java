/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aaml
implements axss<aalz> {
    private final aamc a;

    aaml(aamc aamc2) {
        this.a = aamc2;
    }

    public aalz a() {
        return (aalz)awec.a((Object)this.a.N(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

