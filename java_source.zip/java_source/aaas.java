/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  hpz
 *  zye
 */
class aaas
implements axss<hpz> {
    private final zye a;

    aaas(zye zye2) {
        this.a = zye2;
    }

    public hpz a() {
        return (hpz)awec.a((Object)this.a.h(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

