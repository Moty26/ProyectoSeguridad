/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auhz
 *  awlj
 *  ega
 */
public interface aaeq {
    public awlj<auhz> a();

    public awlj<auhz> b();

    public awlj<ega> c();

    public awlj<aaer> d();
}

