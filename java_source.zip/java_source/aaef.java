/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.ui.core.UCardView
 *  exk
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.ui.core.UCardView;

public abstract class aaef<CardContainer extends UCardView, Router extends aaek, ViewHolder extends aael, Dependency>
extends exk<CardContainer, Router, Dependency> {
    static final int a = aaec.ub__card_inner;

    public aaef(Dependency Dependency) {
        super(Dependency);
    }

    private void a(UCardView uCardView, LayoutInflater layoutInflater, int n) {
        layoutInflater = (ViewGroup)layoutInflater.inflate(n, (ViewGroup)uCardView, false);
        layoutInflater.setId(a);
        uCardView.addView((View)layoutInflater);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    protected abstract int b();

    protected CardContainer b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        viewGroup = (UCardView)layoutInflater.inflate(aaed.ub__card_container, viewGroup, false);
        viewGroup.setId(aaec.ub__card_container);
        this.a((UCardView)viewGroup, layoutInflater, this.b());
        return (CardContainer)viewGroup;
    }
}

