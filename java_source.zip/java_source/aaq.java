/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.support.v7.view.menu.ExpandedMenuView
 *  android.util.SparseArray
 *  android.view.ContextThemeWrapper
 *  android.view.LayoutInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ListAdapter
 *  yu
 */
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.support.v7.view.menu.ExpandedMenuView;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;

public class aaq
implements abh,
AdapterView.OnItemClickListener {
    Context a;
    LayoutInflater b;
    aat c;
    ExpandedMenuView d;
    int e;
    int f;
    int g;
    aar h;
    private abi i;
    private int j;

    public aaq(int n, int n2) {
        this.g = n;
        this.f = n2;
    }

    public aaq(Context context, int n) {
        this(n, 0);
        this.a = context;
        this.b = LayoutInflater.from((Context)this.a);
    }

    public abj a(ViewGroup viewGroup) {
        if (this.d == null) {
            this.d = (ExpandedMenuView)this.b.inflate(yu.abc_expanded_menu_layout, viewGroup, false);
            if (this.h == null) {
                this.h = new aar(this);
            }
            this.d.setAdapter((ListAdapter)this.h);
            this.d.setOnItemClickListener((AdapterView.OnItemClickListener)this);
        }
        return this.d;
    }

    @Override
    public void a(aat aat2, boolean bl) {
        if (this.i != null) {
            this.i.a(aat2, bl);
        }
    }

    @Override
    public void a(abi abi2) {
        this.i = abi2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(Context context, aat aat2) {
        if (this.f != 0) {
            this.a = new ContextThemeWrapper(context, this.f);
            this.b = LayoutInflater.from((Context)this.a);
        } else if (this.a != null) {
            this.a = context;
            if (this.b == null) {
                this.b = LayoutInflater.from((Context)this.a);
            }
        }
        this.c = aat2;
        if (this.h != null) {
            this.h.notifyDataSetChanged();
        }
    }

    public void a(Bundle bundle) {
        SparseArray sparseArray = new SparseArray();
        if (this.d != null) {
            this.d.saveHierarchyState(sparseArray);
        }
        bundle.putSparseParcelableArray("android:menu:list", sparseArray);
    }

    @Override
    public void a(Parcelable parcelable) {
        this.b((Bundle)parcelable);
    }

    @Override
    public void a(boolean bl) {
        if (this.h != null) {
            this.h.notifyDataSetChanged();
        }
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public boolean a(aat aat2, aax aax2) {
        return false;
    }

    @Override
    public boolean a(abp abp2) {
        if (!abp2.hasVisibleItems()) {
            return false;
        }
        new aaw(abp2).a((IBinder)null);
        if (this.i != null) {
            this.i.a(abp2);
        }
        return true;
    }

    @Override
    public int b() {
        return this.j;
    }

    public void b(Bundle bundle) {
        if ((bundle = bundle.getSparseParcelableArray("android:menu:list")) != null) {
            this.d.restoreHierarchyState((SparseArray)bundle);
        }
    }

    @Override
    public boolean b(aat aat2, aax aax2) {
        return false;
    }

    @Override
    public Parcelable c() {
        if (this.d == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        this.a(bundle);
        return bundle;
    }

    public ListAdapter d() {
        if (this.h == null) {
            this.h = new aar(this);
        }
        return this.h;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
        this.c.a((MenuItem)this.h.a(n), this, 0);
    }
}

