/*
 * Decompiled with CFR 0_119.
 */
public interface aafg {
    public void d();

    public void e();

    public void f();
}

