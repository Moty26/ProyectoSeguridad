/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hik
 */
final class aalh
extends aalu {
    private final String a;
    private final aanp b;
    private final aanp c;
    private final hik<String> d;
    private final int e;
    private final int f;
    private final int g;
    private final int h;
    private final boolean i;
    private final boolean j;

    private aalh(String string, aanp aanp2, aanp aanp3, hik<String> hik2, int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        this.a = string;
        this.b = aanp2;
        this.c = aanp3;
        this.d = hik2;
        this.e = n;
        this.f = n2;
        this.g = n3;
        this.h = n4;
        this.i = bl;
        this.j = bl2;
    }

    @Override
    public String a() {
        return this.a;
    }

    @Override
    public aanp b() {
        return this.b;
    }

    @Override
    public aanp c() {
        return this.c;
    }

    @Override
    public hik<String> d() {
        return this.d;
    }

    @Override
    public int e() {
        return this.e;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof aalu)) return false;
        if (!this.a.equals((object = (aalu)object).a())) return false;
        if (!this.b.equals(object.b())) return false;
        if (this.c == null) {
            if (object.c() != null) return false;
        } else if (!this.c.equals(object.c())) return false;
        if (!this.d.equals(object.d())) return false;
        if (this.e != object.e()) return false;
        if (this.f != object.f()) return false;
        if (this.g != object.g()) return false;
        if (this.h != object.h()) return false;
        if (this.i != object.i()) return false;
        if (this.j == object.j()) return true;
        return false;
    }

    @Override
    public int f() {
        return this.f;
    }

    @Override
    public int g() {
        return this.g;
    }

    @Override
    public int h() {
        return this.h;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int hashCode() {
        int n = 1231;
        int n2 = this.a.hashCode();
        int n3 = this.b.hashCode();
        int n4 = this.c == null ? 0 : this.c.hashCode();
        int n5 = this.d.hashCode();
        int n6 = this.e;
        int n7 = this.f;
        int n8 = this.g;
        int n9 = this.h;
        int n10 = this.i ? 1231 : 1237;
        if (this.j) {
            return (n10 ^ ((((((n4 ^ ((n2 ^ 1000003) * 1000003 ^ n3) * 1000003) * 1000003 ^ n5) * 1000003 ^ n6) * 1000003 ^ n7) * 1000003 ^ n8) * 1000003 ^ n9) * 1000003) * 1000003 ^ n;
        }
        n = 1237;
        return (n10 ^ ((((((n4 ^ ((n2 ^ 1000003) * 1000003 ^ n3) * 1000003) * 1000003 ^ n5) * 1000003 ^ n6) * 1000003 ^ n7) * 1000003 ^ n8) * 1000003 ^ n9) * 1000003) * 1000003 ^ n;
    }

    @Override
    public boolean i() {
        return this.i;
    }

    @Override
    public boolean j() {
        return this.j;
    }

    public String toString() {
        return "ConsentConfig{tag=" + this.a + ", " + "legalConsentPrimerConfig=" + this.b + ", " + "featureConsentPrimerConfig=" + this.c + ", " + "permissions=" + this.d + ", " + "appSettingsConfirmTitle=" + this.e + ", " + "appSettingsConfirmMessage=" + this.f + ", " + "appSettingsConfirmButtonText=" + this.g + ", " + "appSettingsCancelButtonText=" + this.h + ", " + "forceShowLegalConsent=" + this.i + ", " + "disableLegalConsent=" + this.j + "}";
    }

}

