/*
 * Decompiled with CFR 0_119.
 */
public interface aajo {
    public void a();
}

