/*
 * Decompiled with CFR 0_119.
 */
public enum aanw {
    a,
    b;
    

    private aanw() {
    }
}

