/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlj
 *  eih
 */
class aaou
implements aaob {
    final /* synthetic */ aaor a;

    aaou(aaor aaor2) {
        this.a = aaor2;
    }

    @Override
    public awlj<String> a() {
        return this.a.l.hide();
    }
}

