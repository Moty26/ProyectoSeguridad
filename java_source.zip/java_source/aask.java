/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.TextView
 */
import android.view.View;
import android.widget.TextView;

class aask
extends aata<aasl> {
    final TextView n;

    aask(TextView textView) {
        super((View)textView);
        this.n = textView;
    }

    @Override
    public void a(aasl aasl2) {
        this.n.setText((CharSequence)aasl2.a);
    }
}

