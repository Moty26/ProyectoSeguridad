/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.consent.primer.PrimerView
 */
import com.ubercab.presidio.consent.primer.PrimerView;

public interface aanl {
    public aank a();

    public aanl b(aann var1);

    public aanl b(aanp var1);

    public aanl b(aanr var1);

    public aanl b(PrimerView var1);
}

