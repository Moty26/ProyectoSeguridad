/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aarq
implements axss<aari> {
    private final aaqy a;

    aarq(aaqy aaqy2) {
        this.a = aaqy2;
    }

    public aari a() {
        return (aari)awec.a((Object)this.a.h(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

