/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agi
 */
public class aady {
    private final int a;
    private final int b;
    private final float c;
    private final agi d;

    public aady(agi agi2, int n, int n2, float f) {
        this.d = agi2;
        this.a = n;
        this.b = n2;
        this.c = f;
    }

    public agi a() {
        return this.d;
    }

    public int b() {
        return this.a;
    }

    public int c() {
        return this.b;
    }

    public float d() {
        return this.c;
    }
}

