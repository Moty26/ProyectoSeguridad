/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.webkit.CookieManager
 *  android.webkit.CookieSyncManager
 */
import android.content.Context;
import android.os.Build;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

public class aacx {
    private final Context a;

    public aacx(Context context) {
        this.a = context;
    }

    void a() {
        CookieSyncManager.createInstance((Context)this.a);
    }

    CookieManager b() {
        return CookieManager.getInstance();
    }

    boolean c() {
        if (Build.VERSION.SDK_INT < 21) {
            return true;
        }
        return false;
    }
}

