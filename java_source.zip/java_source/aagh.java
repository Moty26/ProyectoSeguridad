/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aagh
implements awdv<Boolean> {
    static final /* synthetic */ boolean a;
    private final aagc b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aagh.class.desiredAssertionStatus();
        a = bl;
    }

    public aagh(aagc aagc2) {
        if (!a && aagc2 == null) {
            throw new AssertionError();
        }
        this.b = aagc2;
    }

    public static awdv<Boolean> a(aagc aagc2) {
        return new aagh(aagc2);
    }

    public Boolean a() {
        return (Boolean)awec.a((Object)this.b.f(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

