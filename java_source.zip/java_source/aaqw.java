/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewm
 */
interface aaqw
extends ewm<aark, aarh> {
}

