/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auhz
 *  awlv
 *  awnk
 *  com.ubercab.android.util.ArraySet
 *  eqc
 *  eqr
 *  hhy
 */
import com.ubercab.android.util.ArraySet;

public class aamq {
    private eqc a;

    public aamq(eqc eqc2) {
        this.a = eqc2;
    }

    public awlv<Boolean> a(final String string) {
        return this.a.e((eqr)aamr.a).e((awnk)new awnk<hhy<ArraySet<String>>, Boolean>(){

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public Boolean a(hhy<ArraySet<String>> hhy2) throws Exception {
                boolean bl;
                if (hhy2.b() && ((ArraySet)hhy2.c()).contains((Object)string)) {
                    bl = true;
                    do {
                        return bl;
                        break;
                    } while (true);
                }
                bl = false;
                return bl;
            }
        });
    }

    public awlv<auhz> a(final String string, final boolean bl) {
        return this.a.e((eqr)aamr.a).a((awnk)new awnk<hhy<ArraySet<String>>, awlv<auhz>>(){

            /*
             * Enabled aggressive block sorting
             */
            public awlv<auhz> a(hhy<ArraySet<String>> arraySet) throws Exception {
                if (!arraySet.b() && !bl) {
                    return awlv.b((Object)auhz.a);
                }
                arraySet = arraySet.b() ? (ArraySet)arraySet.c() : new ArraySet();
                if (bl) {
                    arraySet.add((Object)string);
                } else {
                    arraySet.remove((Object)string);
                }
                aamq.this.a.a((eqr)aamr.a, (Object)arraySet);
                return awlv.b((Object)auhz.a);
            }
        });
    }

}

