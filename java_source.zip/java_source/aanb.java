/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  atvd
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.consent.primer.PrimerView
 *  ewj
 *  fbz
 */
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.consent.primer.PrimerView;

public final class aanb
implements aank {
    static final /* synthetic */ boolean a;
    private axss<PrimerView> b;
    private axss<aant> c;
    private axss<aanp> d;
    private axss<aans> e;
    private axss<fbz> f;
    private awdr<aanr> g;
    private axss<aank> h;
    private axss<aanr> i;
    private axss<RibActivity> j;
    private axss<atvd> k;
    private axss<aanv> l;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aanb.class.desiredAssertionStatus();
        a = bl;
    }

    private aanb(aanc aanc2) {
        if (!a && aanc2 == null) {
            throw new AssertionError();
        }
        this.a(aanc2);
    }

    public static aanl a() {
        return new aanc(null);
    }

    private void a(aanc aanc2) {
        this.b = awdw.a((Object)aanc.a(aanc2));
        this.c = awdu.a(this.b);
        this.d = awdw.a((Object)aanc.b(aanc2));
        this.e = new aane(aanc.c(aanc2));
        this.f = new aanf(aanc.c(aanc2));
        this.g = aanu.a(this.c, this.d, this.e, this.f);
        this.h = awdw.a((Object)this);
        this.i = awdw.a((Object)((Object)aanc.d(aanc2)));
        this.j = new aand(aanc.c(aanc2));
        this.k = new aang(aanc.c(aanc2));
        this.l = awdu.a(aano.a(this.h, this.b, this.i, this.j, this.k));
    }

    public void a(aanr aanr2) {
        this.g.a((Object)aanr2);
    }

    @Override
    public aanv b() {
        return (aanv)((Object)this.l.get());
    }

}

