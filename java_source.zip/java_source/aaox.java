/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.view.ViewGroup
 *  ewj
 *  ewl
 *  eww
 *  ewz
 *  exm
 *  eyq
 *  ezc
 *  llg
 *  llw
 */
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.ViewGroup;

public class aaox
extends ewz<aaor, aaoj> {
    private final eyq a;
    private final aapo b;
    private boolean c;

    public aaox(aaor aaor2, aaoj aaoj2, eyq eyq2, aapo aapo2) {
        super((ewj)aaor2, (ewl)aaoj2);
        this.a = eyq2;
        this.b = aapo2;
    }

    public void a(Context context, String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk87+h/ZUwu53Q+BM+sImI8GA==", "enc::NdLRK8oT9tSxh0xRuj3n5MGzL7rEH8HFzfT6/PeWqamH10piQiL/deJUUjyuJ/ayHuSA/sGuO49OBhdYbRlRdcww61vZPHQD99+b7tgConM=", 6815923241891742049L, 6975150655562714296L, -4653365097140807490L, 4285526870058266813L, null, "enc::JPB6LIR3qALvvATfkJqFW7WOPqecEIiAKtCIB0+aaLo=", 75);
        }
        context.startActivity(new Intent("android.intent.action.CALL", Uri.fromParts((String)"tel", (String)string, (String)null)));
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void b(Context context, String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk87+h/ZUwu53Q+BM+sImI8GA==", "enc::uDy+FsztKoa+ugmPyGbi8HjcW0DhhLvir8SF0H/1baFYsBGXi21m33wF/BDieV5D1dfSrZyy/hCThu0ax5dQOb6HZG12iRXCxFMybwK6zdg=", 6815923241891742049L, 6975150655562714296L, 6792919780138804455L, 4285526870058266813L, null, "enc::JPB6LIR3qALvvATfkJqFW7WOPqecEIiAKtCIB0+aaLo=", 85);
        }
        context.startActivity(new Intent("android.intent.action.DIAL", Uri.fromParts((String)"tel", (String)string, (String)null)));
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void c(Context context, String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk87+h/ZUwu53Q+BM+sImI8GA==", "enc::koMqd6kgM0Lck5b44SnI6BKi0jTuT2zjKVOxOlZFHIMzklfu6SJaflBKIv7NeIihDuywbOAyZIVupvn0/ZgfZadl3loy/DSW6281e7xbUI8=", 6815923241891742049L, 6975150655562714296L, -7329136875826056471L, 4285526870058266813L, null, "enc::JPB6LIR3qALvvATfkJqFW7WOPqecEIiAKtCIB0+aaLo=", 95);
        }
        context.startActivity(new Intent("android.intent.action.VIEW", Uri.fromParts((String)"sms", (String)string, (String)null)));
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void e() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk87+h/ZUwu53Q+BM+sImI8GA==", "enc::dm0kQtJrLjDkOQsS+0XtUmVRcnKK6v9OctqFvgdjekc=", 6815923241891742049L, 6975150655562714296L, -6242989211251487561L, 4285526870058266813L, null, "enc::JPB6LIR3qALvvATfkJqFW7WOPqecEIiAKtCIB0+aaLo=", 36);
        }
        super.e();
        if (this.c) {
            this.h();
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void h() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk87+h/ZUwu53Q+BM+sImI8GA==", "enc::nReupoY4e2UP5FhwAL/Wjs90uo92uchV0Bdprg25Pjw=", 6815923241891742049L, 6975150655562714296L, 2370758056566800925L, 4285526870058266813L, null, "enc::JPB6LIR3qALvvATfkJqFW7WOPqecEIiAKtCIB0+aaLo=", 46);
        }
        this.a.a();
        this.c = false;
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLTAqLDkv/IH/PvfeUawzFk87+h/ZUwu53Q+BM+sImI8GA==", "enc::2qIE2pWg406OgNwnBP3Xmhxp2sJx/7lzc/VdbJNrkH4=", 6815923241891742049L, 6975150655562714296L, 8393215376307664778L, 4285526870058266813L, null, "enc::JPB6LIR3qALvvATfkJqFW7WOPqecEIiAKtCIB0+aaLo=", 54);
        }
        this.a.a((ezc)new eww(this){

            public exm a(ViewGroup viewGroup) {
                return aaox.this.b.b(viewGroup);
            }

            protected void b() {
                super.b();
                ((aaor)aaox.this.a()).f();
            }
        });
        this.c = true;
        if (llw2 != null) {
            llw2.i();
        }
    }

}

