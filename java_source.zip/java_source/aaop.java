/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  eyq
 */
public final class aaop
implements awdv<aaox> {
    static final /* synthetic */ boolean a;
    private final aaok b;
    private final axss<aaoj> c;
    private final axss<eyq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaop.class.desiredAssertionStatus();
        a = bl;
    }

    public aaop(aaok aaok2, axss<aaoj> axss2, axss<eyq> axss3) {
        if (!a && aaok2 == null) {
            throw new AssertionError();
        }
        this.b = aaok2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aaox> a(aaok aaok2, axss<aaoj> axss2, axss<eyq> axss3) {
        return new aaop(aaok2, axss2, axss3);
    }

    public aaox a() {
        return (aaox)((Object)awec.a((Object)((Object)this.b.a((aaoj)this.c.get(), (eyq)this.d.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

