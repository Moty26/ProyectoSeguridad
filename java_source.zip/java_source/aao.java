/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Parcelable
 *  android.os.SystemClock
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  android.view.View
 *  android.view.View$OnAttachStateChangeListener
 *  android.view.View$OnKeyListener
 *  android.view.ViewGroup
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.FrameLayout
 *  android.widget.HeaderViewListAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.PopupWindow
 *  android.widget.PopupWindow$OnDismissListener
 *  android.widget.TextView
 *  ra
 *  rw
 *  yr
 *  yu
 */
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

final class aao
extends abf
implements abh,
View.OnKeyListener,
PopupWindow.OnDismissListener {
    final Handler a;
    final List<aap> b = new ArrayList<aap>();
    View c;
    boolean d;
    private final Context e;
    private final int f;
    private final int g;
    private final int h;
    private final boolean i;
    private final List<aat> j = new LinkedList<aat>();
    private final ViewTreeObserver.OnGlobalLayoutListener k;
    private final View.OnAttachStateChangeListener l;
    private final aex m;
    private int n;
    private int o;
    private View p;
    private int q;
    private boolean r;
    private boolean s;
    private int t;
    private int u;
    private boolean v;
    private boolean w;
    private abi x;
    private ViewTreeObserver y;
    private PopupWindow.OnDismissListener z;

    public aao(Context context, View view, int n, int n2, boolean bl) {
        this.k = new ViewTreeObserver.OnGlobalLayoutListener(){

            /*
             * Enabled aggressive block sorting
             */
            public void onGlobalLayout() {
                if (!aao.this.f() || aao.this.b.size() <= 0 || aao.this.b.get((int)0).a.c()) return;
                {
                    Object object = aao.this.c;
                    if (object == null || !object.isShown()) {
                        aao.this.e();
                        return;
                    } else {
                        object = aao.this.b.iterator();
                        while (object.hasNext()) {
                            ((aap)object.next()).a.d();
                        }
                    }
                }
            }
        };
        this.l = new View.OnAttachStateChangeListener(){

            public void onViewAttachedToWindow(View view) {
            }

            public void onViewDetachedFromWindow(View view) {
                if (aao.this.y != null) {
                    if (!aao.this.y.isAlive()) {
                        aao.this.y = view.getViewTreeObserver();
                    }
                    aao.this.y.removeGlobalOnLayoutListener(aao.this.k);
                }
                view.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
            }
        };
        this.m = new aex(){

            @Override
            public void a(aat aat2, MenuItem menuItem) {
                aao.this.a.removeCallbacksAndMessages((Object)aat2);
            }

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public void b(aat aat2, MenuItem object) {
                aao.this.a.removeCallbacksAndMessages((Object)null);
                int n = 0;
                int n2 = aao.this.b.size();
                do {
                    if (n >= n2) {
                        return;
                    }
                    if (aat2 == aao.this.b.get((int)n).b) {
                        if (n != -1) break;
                        return;
                    }
                    ++n;
                } while (true);
                final aap aap2 = ++n < aao.this.b.size() ? aao.this.b.get(n) : null;
                object = new Runnable((MenuItem)object, aat2){
                    final /* synthetic */ MenuItem b;
                    final /* synthetic */ aat c;

                    @Override
                    public void run() {
                        if (aap2 != null) {
                            aao.this.d = true;
                            aap2.b.b(false);
                            aao.this.d = false;
                        }
                        if (this.b.isEnabled() && this.b.hasSubMenu()) {
                            this.c.a(this.b, 4);
                        }
                    }
                };
                long l = SystemClock.uptimeMillis();
                aao.this.a.postAtTime((Runnable)object, (Object)aat2, l + 200);
            }

        };
        this.n = 0;
        this.o = 0;
        this.e = context;
        this.p = view;
        this.g = n;
        this.h = n2;
        this.i = bl;
        this.v = false;
        this.q = this.k();
        context = context.getResources();
        this.f = Math.max(context.getDisplayMetrics().widthPixels / 2, context.getDimensionPixelSize(yr.abc_config_prefDialogWidth));
        this.a = new Handler();
    }

    private MenuItem a(aat aat2, aat aat3) {
        int n = aat2.size();
        for (int i = 0; i < n; ++i) {
            MenuItem menuItem = aat2.getItem(i);
            if (!menuItem.hasSubMenu() || aat3 != menuItem.getSubMenu()) continue;
            return menuItem;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private View a(aap object, aat aat2) {
        int n;
        int n2 = 0;
        if ((aat2 = this.a(object.b, aat2)) == null) {
            return null;
        }
        ListView listView = object.a();
        object = listView.getAdapter();
        if (object instanceof HeaderViewListAdapter) {
            object = (HeaderViewListAdapter)object;
            n = object.getHeadersCount();
            object = (aas)object.getWrappedAdapter();
        } else {
            object = (aas)((Object)object);
            n = 0;
        }
        int n3 = object.getCount();
        do {
            if (n2 >= n3) {
                return null;
            }
            if (aat2 == object.a(n2)) {
                if (n2 != -1) break;
                return null;
            }
            ++n2;
        } while (true);
        if ((n2 = n2 + n - listView.getFirstVisiblePosition()) >= 0 && n2 < listView.getChildCount()) {
            return listView.getChildAt(n2);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void c(aat aat2) {
        Object object;
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.e);
        Object object2 = new aas(aat2, layoutInflater, this.i);
        if (!this.f() && this.v) {
            object2.a(true);
        } else if (this.f()) {
            object2.a(abf.b(aat2));
        }
        int n = aao.a((ListAdapter)object2, null, this.e, this.f);
        aey aey2 = this.j();
        aey2.a((ListAdapter)object2);
        aey2.g(n);
        aey2.e(this.o);
        if (this.b.size() > 0) {
            object2 = this.b.get(this.b.size() - 1);
            object = this.a((aap)object2, aat2);
        } else {
            object = null;
            object2 = null;
        }
        if (object != null) {
            int n2;
            aey2.c(false);
            aey2.a((Object)null);
            int n3 = this.d(n);
            int n4 = n3 == 1 ? 1 : 0;
            this.q = n3;
            if (Build.VERSION.SDK_INT >= 26) {
                aey2.b((View)object);
                n3 = 0;
                n2 = 0;
            } else {
                int[] arrn = new int[2];
                this.p.getLocationOnScreen(arrn);
                int[] arrn2 = new int[2];
                object.getLocationOnScreen(arrn2);
                n2 = arrn2[0] - arrn[0];
                n3 = arrn2[1] - arrn[1];
            }
            n4 = (this.o & 5) == 5 ? (n4 != 0 ? n2 + n : n2 - object.getWidth()) : (n4 != 0 ? object.getWidth() + n2 : n2 - n);
            aey2.c(n4);
            aey2.b(true);
            aey2.d(n3);
        } else {
            if (this.r) {
                aey2.c(this.t);
            }
            if (this.s) {
                aey2.d(this.u);
            }
            aey2.a(this.i());
        }
        object = new aap(aey2, aat2, this.q);
        this.b.add((aap)object);
        aey2.d();
        object = aey2.g();
        object.setOnKeyListener((View.OnKeyListener)this);
        if (object2 == null && this.w && aat2.m() != null) {
            object2 = (FrameLayout)layoutInflater.inflate(yu.abc_popup_menu_header_item_layout, (ViewGroup)object, false);
            layoutInflater = (TextView)object2.findViewById(16908310);
            object2.setEnabled(false);
            layoutInflater.setText(aat2.m());
            object.addHeaderView((View)object2, (Object)null, false);
            aey2.d();
        }
    }

    private int d(int n) {
        ListView listView = this.b.get(this.b.size() - 1).a();
        int[] arrn = new int[2];
        listView.getLocationOnScreen(arrn);
        Rect rect = new Rect();
        this.c.getWindowVisibleDisplayFrame(rect);
        if (this.q == 1) {
            int n2 = arrn[0];
            if (listView.getWidth() + n2 + n > rect.right) {
                return 0;
            }
            return 1;
        }
        if (arrn[0] - n < 0) {
            return 1;
        }
        return 0;
    }

    private int d(aat aat2) {
        int n = this.b.size();
        for (int i = 0; i < n; ++i) {
            if (aat2 != this.b.get((int)i).b) continue;
            return i;
        }
        return -1;
    }

    private aey j() {
        aey aey2 = new aey(this.e, null, this.g, this.h);
        aey2.a(this.m);
        aey2.a((AdapterView.OnItemClickListener)this);
        aey2.a((PopupWindow.OnDismissListener)this);
        aey2.b(this.p);
        aey2.e(this.o);
        aey2.a(true);
        aey2.h(2);
        return aey2;
    }

    private int k() {
        int n = 1;
        if (rw.f((View)this.p) == 1) {
            n = 0;
        }
        return n;
    }

    @Override
    public void a(int n) {
        if (this.n != n) {
            this.n = n;
            this.o = ra.a((int)n, (int)rw.f((View)this.p));
        }
    }

    @Override
    public void a(aat aat2) {
        aat2.a(this, this.e);
        if (this.f()) {
            this.c(aat2);
            return;
        }
        this.j.add(aat2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void a(aat aat2, boolean bl) {
        int n = this.d(aat2);
        if (n < 0) {
            return;
        }
        int n2 = n + 1;
        if (n2 < this.b.size()) {
            this.b.get((int)n2).b.b(false);
        }
        aap aap2 = this.b.remove(n);
        aap2.b.b(this);
        if (this.d) {
            aap2.a.b(null);
            aap2.a.b(0);
        }
        aap2.a.e();
        n = this.b.size();
        this.q = n > 0 ? this.b.get((int)(n - 1)).c : this.k();
        if (n != 0) {
            if (!bl) return;
            this.b.get((int)0).b.b(false);
            return;
        }
        this.e();
        if (this.x != null) {
            this.x.a(aat2, true);
        }
        if (this.y != null) {
            if (this.y.isAlive()) {
                this.y.removeGlobalOnLayoutListener(this.k);
            }
            this.y = null;
        }
        this.c.removeOnAttachStateChangeListener(this.l);
        this.z.onDismiss();
    }

    @Override
    public void a(abi abi2) {
        this.x = abi2;
    }

    @Override
    public void a(Parcelable parcelable) {
    }

    @Override
    public void a(View view) {
        if (this.p != view) {
            this.p = view;
            this.o = ra.a((int)this.n, (int)rw.f((View)this.p));
        }
    }

    @Override
    public void a(PopupWindow.OnDismissListener onDismissListener) {
        this.z = onDismissListener;
    }

    @Override
    public void a(boolean bl) {
        Iterator<aap> iterator = this.b.iterator();
        while (iterator.hasNext()) {
            aao.a(iterator.next().a().getAdapter()).notifyDataSetChanged();
        }
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public boolean a(abp abp2) {
        for (aap aap2 : this.b) {
            if (abp2 != aap2.b) continue;
            aap2.a().requestFocus();
            return true;
        }
        if (abp2.hasVisibleItems()) {
            this.a((aat)abp2);
            if (this.x != null) {
                this.x.a(abp2);
            }
            return true;
        }
        return false;
    }

    @Override
    public void b(int n) {
        this.r = true;
        this.t = n;
    }

    @Override
    public void b(boolean bl) {
        this.v = bl;
    }

    @Override
    public Parcelable c() {
        return null;
    }

    @Override
    public void c(int n) {
        this.s = true;
        this.u = n;
    }

    @Override
    public void c(boolean bl) {
        this.w = bl;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public void d() {
        if (this.f()) {
            return;
        }
        Iterator<aat> iterator = this.j.iterator();
        while (iterator.hasNext()) {
            this.c(iterator.next());
        }
        this.j.clear();
        this.c = this.p;
        if (this.c == null) return;
        boolean bl = this.y == null;
        this.y = this.c.getViewTreeObserver();
        if (bl) {
            this.y.addOnGlobalLayoutListener(this.k);
        }
        this.c.addOnAttachStateChangeListener(this.l);
    }

    @Override
    public void e() {
        int n = this.b.size();
        if (n > 0) {
            aap[] arraap = this.b.toArray(new aap[n]);
            --n;
            while (n >= 0) {
                aap aap2 = arraap[n];
                if (aap2.a.f()) {
                    aap2.a.e();
                }
                --n;
            }
        }
    }

    @Override
    public boolean f() {
        if (this.b.size() > 0 && this.b.get((int)0).a.f()) {
            return true;
        }
        return false;
    }

    @Override
    public ListView g() {
        if (this.b.isEmpty()) {
            return null;
        }
        return this.b.get(this.b.size() - 1).a();
    }

    @Override
    protected boolean h() {
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void onDismiss() {
        int n = this.b.size();
        int n2 = 0;
        while (n2 < n) {
            aap aap2 = this.b.get(n2);
            if (!aap2.a.f()) {
                if (aap2 == null) return;
                aap2.b.b(false);
                return;
            }
            ++n2;
        }
    }

    public boolean onKey(View view, int n, KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1 && n == 82) {
            this.e();
            return true;
        }
        return false;
    }

}

