/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aajk
implements axss<aagq> {
    private final aaiw a;

    aajk(aaiw aaiw2) {
        this.a = aaiw2;
    }

    public aagq a() {
        return (aagq)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

