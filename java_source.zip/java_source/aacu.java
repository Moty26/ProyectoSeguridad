/*
 * Decompiled with CFR 0_119.
 */
public final class aacu {
    private final String a;
    private final double b;
    private final double c;
    private final float d;
    private final long e;
    private final int f;
    private final int g;
    private final int h;

    private aacu(String string, double d, double d2, float f, long l, int n, int n2, int n3) {
        this.a = string;
        this.b = d;
        this.c = d2;
        this.d = f;
        this.e = l;
        this.f = n;
        this.g = n2;
        this.h = n3;
    }

    public String a() {
        return this.a;
    }

    public double b() {
        return this.b;
    }

    public double c() {
        return this.c;
    }

    public float d() {
        return this.d;
    }

    public long e() {
        return this.e;
    }

    public int f() {
        return this.f;
    }

    public int g() {
        return this.g;
    }

    public int h() {
        return this.h;
    }

}

