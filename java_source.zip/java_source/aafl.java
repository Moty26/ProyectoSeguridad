/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awec
 *  axss
 *  esc
 */
class aafl
implements axss<esc<apap>> {
    private final aaey a;

    aafl(aaey aaey2) {
        this.a = aaey2;
    }

    public esc<apap> a() {
        return (esc)awec.a(this.a.cv_(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

