/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alxc
 */
public enum aabn implements alxc
{
    a,
    b;
    

    private aabn() {
    }
}

