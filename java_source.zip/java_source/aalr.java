/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 */
public final class aalr
implements awdv<aans> {
    static final /* synthetic */ boolean a;
    private final axss<aalx> b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aalr.class.desiredAssertionStatus();
        a = bl;
    }

    public aalr(axss<aalx> axss2) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
    }

    public static awdv<aans> a(axss<aalx> axss2) {
        return new aalr(axss2);
    }

    public aans a() {
        return (aans)awec.a((Object)aalp.a((aalx)this.b.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

