/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  ewz
 *  zqq
 *  zye
 */
import android.view.ViewGroup;

class aaam
implements zqq<aaal> {
    private final zye a;

    aaam(zye zye2) {
        this.a = zye2;
    }

    public /* synthetic */ ewz a(ViewGroup viewGroup) {
        return this.b(viewGroup);
    }

    public aaal b(ViewGroup viewGroup) {
        return new aaab(this.a).b();
    }
}

