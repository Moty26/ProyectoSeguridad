/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.pm.ShortcutManager
 *  awks
 *  awnd
 *  com.uber.rib.core.RibActivity
 */
import android.annotation.TargetApi;
import android.content.pm.ShortcutManager;
import com.uber.rib.core.RibActivity;

public class aabt
extends abhe {
    private final RibActivity a;

    public aabt(RibActivity ribActivity) {
        this.a = ribActivity;
    }

    @TargetApi(value=25)
    @Override
    protected awks a() {
        return awks.a((awnd)new awnd(){

            public void a() {
                ((ShortcutManager)aabt.this.a.getSystemService("shortcut")).removeAllDynamicShortcuts();
            }
        });
    }

}

