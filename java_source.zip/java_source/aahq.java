/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aahq {
    private aahe a;
    private aahf b;

    private aahq() {
    }

    static /* synthetic */ aahe a(aahq aahq2) {
        return aahq2.a;
    }

    static /* synthetic */ aahf b(aahq aahq2) {
        return aahq2.b;
    }

    public aahd a() {
        if (this.a == null) {
            throw new IllegalStateException(aahe.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aahf.class.getCanonicalName() + " must be set");
        }
        return new aahp(this);
    }

    public aahq a(aahe aahe2) {
        this.a = (aahe)((Object)awec.a((Object)((Object)aahe2)));
        return this;
    }

    public aahq a(aahf aahf2) {
        this.b = (aahf)awec.a((Object)aahf2);
        return this;
    }
}

