/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.Contact
 *  hik
 */
import com.ubercab.presidio.contacts.model.Contact;
import java.util.Map;

public class aary {
    public final Map<String, Contact> a;
    public final hik<String> b;
    public final String c;
    public boolean d = true;

    public aary(Map<String, Contact> map, hik<String> hik2, String string, boolean bl) {
        this.a = map;
        this.b = hik2;
        this.c = string;
        this.d = bl;
    }
}

