/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apaq
 *  awec
 *  axss
 */
class aajm
implements axss<apaq> {
    private final aaiw a;

    aajm(aaiw aaiw2) {
        this.a = aaiw2;
    }

    public apaq a() {
        return (apaq)awec.a((Object)this.a.e(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

