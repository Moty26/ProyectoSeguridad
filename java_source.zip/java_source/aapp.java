/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewm
 */
interface aapp
extends ewm<aapw, aapt> {
}

