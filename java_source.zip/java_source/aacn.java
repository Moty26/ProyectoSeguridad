/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService
 */
import android.content.Context;
import com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService;

public class aacn {
    final GeofenceTransitionsIntentService a;
    final /* synthetic */ GeofenceTransitionsIntentService b;

    public aacn(GeofenceTransitionsIntentService geofenceTransitionsIntentService, GeofenceTransitionsIntentService geofenceTransitionsIntentService2) {
        this.b = geofenceTransitionsIntentService;
        this.a = geofenceTransitionsIntentService2;
    }

    aaco a() {
        return new aaco(this.b.getApplicationContext());
    }
}

