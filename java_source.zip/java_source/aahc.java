/*
 * Decompiled with CFR 0_119.
 */
interface aahc {
    public aahn a();
}

