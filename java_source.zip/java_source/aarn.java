/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aarn {
    private aaqx a;
    private aaqy b;

    private aarn() {
    }

    static /* synthetic */ aaqy a(aarn aarn2) {
        return aarn2.b;
    }

    static /* synthetic */ aaqx b(aarn aarn2) {
        return aarn2.a;
    }

    public aaqw a() {
        if (this.a == null) {
            throw new IllegalStateException(aaqx.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aaqy.class.getCanonicalName() + " must be set");
        }
        return new aarm(this);
    }

    public aarn a(aaqx aaqx2) {
        this.a = (aaqx)((Object)awec.a((Object)((Object)aaqx2)));
        return this;
    }

    public aarn a(aaqy aaqy2) {
        this.b = (aaqy)awec.a((Object)aaqy2);
        return this;
    }
}

