/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewc
 *  ewf
 *  ewm
 */
interface aaax
extends ewm<ewf, aabh> {
    public ewc d();

    public aabg e();
}

