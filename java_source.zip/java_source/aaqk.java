/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hqg
 */
public enum aaqk implements hqg
{
    EMI_PROPAGATE_PHOTO_IN_CONTACT_DETAIL,
    CONTACT_SELECTION_LIMIT,
    CONTACTS_SYNC;
    

    private aaqk() {
    }
}

