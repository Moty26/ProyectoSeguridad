/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  zql
 *  zyb
 */
public final class aaah
implements awdv<zyb> {
    static final /* synthetic */ boolean a;
    private final aaad b;
    private final axss<aaai> c;
    private final axss<zql> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaah.class.desiredAssertionStatus();
        a = bl;
    }

    public aaah(aaad aaad2, axss<aaai> axss2, axss<zql> axss3) {
        if (!a && aaad2 == null) {
            throw new AssertionError();
        }
        this.b = aaad2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<zyb> a(aaad aaad2, axss<aaai> axss2, axss<zql> axss3) {
        return new aaah(aaad2, axss2, axss3);
    }

    public zyb a() {
        return (zyb)awec.a((Object)this.b.a((aaai)this.c.get(), (zql)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

