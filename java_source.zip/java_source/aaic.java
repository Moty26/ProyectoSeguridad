/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aaic
implements awdv<aaik> {
    static final /* synthetic */ boolean a;
    private final aaia b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaic.class.desiredAssertionStatus();
        a = bl;
    }

    public aaic(aaia aaia2) {
        if (!a && aaia2 == null) {
            throw new AssertionError();
        }
        this.b = aaia2;
    }

    public static awdv<aaik> a(aaia aaia2) {
        return new aaic(aaia2);
    }

    public aaik a() {
        return (aaik)((Object)awec.a((Object)((Object)this.b.a()), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

