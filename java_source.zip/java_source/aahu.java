/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  eyq
 */
class aahu
implements axss<eyq> {
    private final aahf a;

    aahu(aahf aahf2) {
        this.a = aahf2;
    }

    public eyq a() {
        return (eyq)awec.a((Object)this.a.b(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

