/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactDetail$Type
 */
import com.ubercab.presidio.contacts.model.ContactDetail;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class aaqb {
    private static final Map<Integer, Integer> a = new HashMap<Integer, Integer>();
    private static final Map<Integer, Integer> b;
    private final aaqh c;

    static {
        a.put(4, 4);
        a.put(1, 3);
        a.put(2, 2);
        a.put(0, 1);
        a.put(3, 0);
        b = new HashMap<Integer, Integer>();
        b.put(2, 20);
        b.put(17, 19);
        b.put(12, 18);
        b.put(1, 17);
        b.put(5, 16);
        b.put(6, 15);
        b.put(10, 14);
        b.put(3, 13);
        b.put(4, 12);
        b.put(18, 11);
        b.put(19, 10);
        b.put(20, 9);
        b.put(8, 8);
        b.put(9, 7);
        b.put(11, 6);
        b.put(14, 5);
        b.put(15, 4);
        b.put(16, 3);
        b.put(0, 2);
        b.put(13, 1);
        b.put(7, 0);
    }

    aaqb(aaqh aaqh2) {
        this.c = aaqh2;
    }

    private String a(ContactDetail contactDetail) {
        if (contactDetail.type() == ContactDetail.Type.EMAIL) {
            return this.c.a(contactDetail.value());
        }
        return this.c.b(contactDetail.value());
    }

    private void a(Set<ContactDetail> object) {
        HashMap<String, ContactDetail> hashMap = new HashMap<String, ContactDetail>();
        ContactDetail contactDetail = object.iterator();
        while (contactDetail.hasNext()) {
            ContactDetail contactDetail2 = contactDetail.next();
            String string = this.a(contactDetail2);
            if (hashMap.containsKey(string) && this.b(contactDetail2) <= this.b((ContactDetail)hashMap.get(string))) continue;
            hashMap.put(string, contactDetail2);
        }
        object = object.iterator();
        while (object.hasNext()) {
            contactDetail = (ContactDetail)object.next();
            if (hashMap.values().contains((Object)contactDetail)) continue;
            object.remove();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private int b(ContactDetail contactDetail) {
        if (contactDetail.detailType() == -1) return -1;
        if (contactDetail.type() == ContactDetail.Type.EMAIL) {
            if (!a.containsKey(contactDetail.detailType())) return -1;
            return a.get(contactDetail.detailType());
        }
        if (b.containsKey(contactDetail.detailType())) return b.get(contactDetail.detailType());
        return -1;
    }

    Map<String, Set<ContactDetail>> a(Map<String, Set<ContactDetail>> map) {
        Iterator<Set<ContactDetail>> iterator = map.values().iterator();
        while (iterator.hasNext()) {
            this.a(iterator.next());
        }
        return map;
    }
}

