/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awnk
 *  com.uber.model.core.analytics.generated.platform.analytics.ConsentMetadata
 *  com.uber.model.core.analytics.generated.platform.analytics.ConsentMetadata$Builder
 *  eoc
 *  fbz
 */
import com.uber.model.core.analytics.generated.platform.analytics.ConsentMetadata;
import java.util.HashMap;
import java.util.Map;

public class aalj {
    private final String a;
    private final fbz b;

    public aalj(String string, fbz fbz2) {
        this.a = string;
        this.b = fbz2;
    }

    awnk<String, Map<String, String>> a(final aalu aalu2, final aamf aamf2, final aalk aalk2) {
        return new awnk<String, Map<String, String>>(){

            public Map<String, String> a(String object) throws Exception {
                object = new HashMap();
                aalj.this.b(aalu2, aamf2, aalk2);
                return object;
            }
        };
    }

    ConsentMetadata.Builder a(aalu aalu2, aalk aalk2) {
        return ConsentMetadata.builder().appName(this.a).eventName(aalk2.name()).featureName(aalu2.a()).legalConsentPrimerShown(Boolean.valueOf(false)).featureConsentPrimerShown(Boolean.valueOf(false));
    }

    ConsentMetadata.Builder a(aalu aalu2, aamd aamd2, aalk aalk2) {
        return this.a(aalu2, aalk2).legalConsentPrimerShown(Boolean.valueOf(aamd2.b())).featureConsentPrimerShown(Boolean.valueOf(aamd2.c()));
    }

    ConsentMetadata.Builder a(aalu aalu2, aamd aamd2, aalk aalk2, boolean bl) {
        return this.a(aalu2, aamd2, aalk2).permissionsGranted(Boolean.valueOf(bl));
    }

    String a() {
        return "45e48e0d-3e66";
    }

    final void a(aalu aalu2) {
        this.a(this.a(aalu2, aalk.a));
    }

    final void a(aalu aalu2, aamd aamd2) {
        switch (.a[aamd2.a().ordinal()]) {
            default: {
                this.a(this.a(aalu2, aamd2, aalk.k));
                return;
            }
            case 1: {
                this.a(this.a(aalu2, aamd2, aalk.h));
                return;
            }
            case 2: {
                this.a(this.a(aalu2, aamd2, aalk.i));
                return;
            }
            case 3: 
        }
        this.a(this.a(aalu2, aamd2, aalk.j));
    }

    final void a(aalu aalu2, aamf aamf2) {
        this.a(this.b(aalu2, aamf2, aalk.b));
    }

    void a(ConsentMetadata.Builder builder) {
        this.b.a("45e48e0d-3e66", (eoc)builder.build());
    }

    awnk<String, Map<String, String>> b(aalu aalu2, aamf aamf2) {
        return this.a(aalu2, aamf2, aalk.c);
    }

    ConsentMetadata.Builder b(aalu aalu2, aamf aamf2, aalk aalk2) {
        return this.a(aalu2, aalk2).hasDeferredLegalConsent(Boolean.valueOf(aamf2.b())).hasFeatureConsent(Boolean.valueOf(aamf2.c())).hasLegalConsent(Boolean.valueOf(aamf2.a()));
    }

    final void b(aalu aalu2) {
        this.a(this.a(aalu2, aalk.r));
    }

    final void b(aalu aalu2, aamd aamd2) {
        switch (.a[aamd2.a().ordinal()]) {
            default: {
                this.a(this.a(aalu2, aamd2, aalk.o, aamd2.e()));
                return;
            }
            case 1: {
                this.a(this.a(aalu2, aamd2, aalk.l, aamd2.e()));
                return;
            }
            case 2: {
                this.a(this.a(aalu2, aamd2, aalk.m, aamd2.e()));
                return;
            }
            case 3: 
        }
        this.a(this.a(aalu2, aamd2, aalk.n, aamd2.e()));
    }

    awnk<String, Map<String, String>> c(aalu aalu2, aamf aamf2) {
        return this.a(aalu2, aamf2, aalk.d);
    }

    final void c(aalu aalu2) {
        this.a(this.a(aalu2, aalk.q));
    }

    awnk<String, Map<String, String>> d(aalu aalu2, aamf aamf2) {
        return this.a(aalu2, aamf2, aalk.f);
    }

    final void d(aalu aalu2) {
        this.a(this.a(aalu2, aalk.p));
    }

    awnk<String, Map<String, String>> e(aalu aalu2, aamf aamf2) {
        return this.a(aalu2, aamf2, aalk.e);
    }

    final void e(aalu aalu2) {
        this.a(this.a(aalu2, aalk.s));
    }

    awnk<String, Map<String, String>> f(aalu aalu2, aamf aamf2) {
        return this.a(aalu2, aamf2, aalk.g);
    }

}

