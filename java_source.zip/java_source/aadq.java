/*
 * Decompiled with CFR 0_119.
 */
public interface aadq {
    public int cp_();
}

