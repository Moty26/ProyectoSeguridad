/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactDetail
 */
import com.ubercab.presidio.contacts.model.ContactDetail;

public interface aasi
extends aavm {
    public void a(ContactDetail var1);

    public void a_(String var1);
}

