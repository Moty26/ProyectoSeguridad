/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.pm.ShortcutInfo
 *  android.content.pm.ShortcutManager
 *  android.graphics.drawable.Icon
 *  arqv
 *  artc
 *  auif
 *  awlj
 *  awlp
 *  awlq
 *  awnk
 *  axrq
 *  com.uber.model.core.generated.ms.search.generated.Coordinate
 *  com.uber.model.core.generated.ms.search.generated.Geolocation
 *  com.uber.model.core.generated.ms.search.generated.GeolocationResult
 *  com.uber.rib.core.RibActivity
 *  eot
 *  eov
 *  eox
 *  exn
 *  exp
 *  hhy
 *  jih
 *  jin
 */
import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import com.uber.model.core.generated.ms.search.generated.Coordinate;
import com.uber.model.core.generated.ms.search.generated.Geolocation;
import com.uber.model.core.generated.ms.search.generated.GeolocationResult;
import com.uber.rib.core.RibActivity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class aabo
implements exn {
    private final RibActivity a;
    private final artc b;
    private final aabq c;

    public aabo(artc artc2, RibActivity ribActivity) {
        this(artc2, ribActivity, new aabp(null));
    }

    public aabo(artc artc2, RibActivity ribActivity, aabq aabq2) {
        this.b = artc2;
        this.a = ribActivity;
        this.c = aabq2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @TargetApi(value=25)
    private hhy<ShortcutInfo> a(GeolocationResult geolocationResult, String string) {
        Object object;
        Object object2;
        Object object3;
        if (string.equalsIgnoreCase("addHomeTag")) {
            object2 = "uber://settings";
            object3 = this.c.a((Context)this.a, jih.ub__location_home_24_marker);
            object = this.c.b((Context)this.a, jin.add_home);
            do {
                return this.c.a((Context)this.a, geolocationResult, string, (String)object, (Icon)object3, (String)object2);
                break;
            } while (true);
        }
        if (string.equalsIgnoreCase("addWorkTag")) {
            object2 = "uber://settings";
            object3 = this.c.a((Context)this.a, jih.ub__location_work_24_marker);
            object = this.c.b((Context)this.a, jin.add_work);
            return this.c.a((Context)this.a, geolocationResult, string, (String)object, (Icon)object3, (String)object2);
        }
        if (geolocationResult == null) {
            return hhy.e();
        }
        object = geolocationResult.location().coordinate();
        if (object == null) {
            return hhy.e();
        }
        object3 = object.latitude();
        object2 = object.longitude();
        if (object3 == null || object2 == null) {
            return hhy.e();
        }
        object = this.c.a((Context)this.a, string);
        object2 = String.format(Locale.ENGLISH, "uber://?action=setPickup&pickup=my_location&dropoff[latitude]=%s&dropoff[longitude]=%s&dropoff[nickname]=%s", object3, object2, object);
        if (string.equalsIgnoreCase("home")) {
            object3 = this.c.a((Context)this.a, jih.ub__location_home_24_marker);
            return this.c.a((Context)this.a, geolocationResult, string, (String)object, (Icon)object3, (String)object2);
        }
        if (string.equalsIgnoreCase("work")) {
            object3 = this.c.a((Context)this.a, jih.ub__location_work_24_marker);
            return this.c.a((Context)this.a, geolocationResult, string, (String)object, (Icon)object3, (String)object2);
        }
        object3 = this.c.a((Context)this.a, jih.ub__star_24_marker);
        return this.c.a((Context)this.a, geolocationResult, string, (String)object, (Icon)object3, (String)object2);
    }

    public void a() {
    }

    public void a(exp exp2) {
        ((eov)this.b.a().observeOn(axrq.a()).to((awnk)new eot((eox)exp2))).a((awlp)new auif<hhy<List<GeolocationResult>>>(){

            public void a(hhy<List<GeolocationResult>> object) throws Exception {
                if (!object.b()) {
                    return;
                }
                object = (List)object.c();
                aabo.this.a((List<GeolocationResult>)object);
            }
        });
    }

    @TargetApi(value=25)
    public void a(List<GeolocationResult> hhy2) {
        hhy<ShortcutInfo> hhy3;
        ShortcutManager shortcutManager = (ShortcutManager)this.a.getSystemService("shortcut");
        ArrayList<Object> arrayList = new ArrayList<Object>(4);
        Object object = hhy2.iterator();
        hhy<ShortcutInfo> hhy4 = null;
        hhy<ShortcutInfo> hhy5 = null;
        while (object.hasNext()) {
            hhy3 = object.next();
            if (arqv.a((GeolocationResult)hhy3).equalsIgnoreCase("home")) {
                hhy5 = hhy3;
                continue;
            }
            if (!arqv.a(hhy3).equalsIgnoreCase("work")) continue;
            hhy4 = hhy3;
        }
        if (hhy5 != null && (hhy3 = this.a((GeolocationResult)hhy5, "home")).b()) {
            arrayList.add(hhy3.c());
        }
        if (hhy4 != null && (hhy3 = this.a((GeolocationResult)hhy4, "work")).b()) {
            arrayList.add(hhy3.c());
        }
        hhy2 = hhy2.iterator();
        int n = 0;
        while (hhy2.hasNext()) {
            hhy3 = (hhy<ShortcutInfo>)hhy2.next();
            object = arqv.a((GeolocationResult)hhy3);
            if (object.isEmpty() || object.equalsIgnoreCase("home") || object.equalsIgnoreCase("work") || !(hhy3 = this.a((GeolocationResult)hhy3, (String)object)).b()) continue;
            arrayList.add(hhy3.c());
            if (++n != 2) continue;
        }
        if (hhy5 == null && (hhy2 = this.a(null, "addHomeTag")).b()) {
            arrayList.add(hhy2.c());
        }
        if (hhy4 == null && (hhy2 = this.a(null, "addWorkTag")).b()) {
            arrayList.add(hhy2.c());
        }
        shortcutManager.setDynamicShortcuts(arrayList);
    }

}

