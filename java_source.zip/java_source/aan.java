/*
 * Decompiled with CFR 0_119.
 */
class aan<T> {
    final T b;

    aan(T t) {
        if (t == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.b = t;
    }
}

