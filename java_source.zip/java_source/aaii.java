/*
 * Decompiled with CFR 0_119.
 */
interface aaii {
    public void a(String var1, String var2, int var3, String var4);

    public void d();
}

