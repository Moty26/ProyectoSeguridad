/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aarc
implements awdv<aasf> {
    static final /* synthetic */ boolean a;
    private final aaqx b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarc.class.desiredAssertionStatus();
        a = bl;
    }

    public aarc(aaqx aaqx2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
    }

    public static awdv<aasf> a(aaqx aaqx2) {
        return new aarc(aaqx2);
    }

    public aasf a() {
        return (aasf)awec.a((Object)this.b.a(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

