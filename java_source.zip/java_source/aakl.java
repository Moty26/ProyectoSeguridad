/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.text.SpannableString
 *  android.text.SpannableStringBuilder
 *  android.view.View
 *  android.view.View$OnClickListener
 *  zru
 */
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.view.View;

public class aakl {
    private static void a(SpannableStringBuilder spannableStringBuilder, String string, SpannableString spannableString) {
        int n = spannableStringBuilder.toString().indexOf(string);
        if (n != -1) {
            spannableStringBuilder.replace(n, string.length() + n, (CharSequence)spannableString);
        }
    }

    public static void a(SpannableStringBuilder spannableStringBuilder, String string, String string2, int n, View.OnClickListener onClickListener) {
        aakl.a(spannableStringBuilder, string, (SpannableString)new zru(string2, n, onClickListener));
    }
}

