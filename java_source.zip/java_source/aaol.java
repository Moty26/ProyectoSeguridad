/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aaol
implements awdv<aaoq> {
    static final /* synthetic */ boolean a;
    private final aaok b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaol.class.desiredAssertionStatus();
        a = bl;
    }

    public aaol(aaok aaok2) {
        if (!a && aaok2 == null) {
            throw new AssertionError();
        }
        this.b = aaok2;
    }

    public static awdv<aaoq> a(aaok aaok2) {
        return new aaol(aaok2);
    }

    public aaoq a() {
        return (aaoq)((Object)awec.a((Object)((Object)this.b.b()), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

