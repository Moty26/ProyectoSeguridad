/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.model.core.analytics.generated.platform.analytics.ContactPickerMetadata
 *  com.uber.model.core.analytics.generated.platform.analytics.ContactPickerMetadata$Builder
 *  com.ubercab.presidio.contacts.model.ContactSelection
 *  eoc
 *  fbz
 *  hik
 */
import com.uber.model.core.analytics.generated.platform.analytics.ContactPickerMetadata;
import com.ubercab.presidio.contacts.model.ContactSelection;

public class aaqi {
    private final String a;
    private final fbz b;

    public aaqi(String string, fbz fbz2) {
        this.a = string;
        this.b = fbz2;
    }

    public void a(String string) {
        this.b.a("448daa5a-d90e", (eoc)ContactPickerMetadata.builder().featureName(string).eventName(aaqj.b.name()).appName(this.a).build());
    }

    public void a(String string, ContactSelection contactSelection) {
        this.b.a("448daa5a-d90e", (eoc)ContactPickerMetadata.builder().featureName(string).eventName(aaqj.a.name()).appName(this.a).contactsSelectedCount(Integer.valueOf(contactSelection.getContactDetails().size() - contactSelection.getSelectedSuggestionsCount())).rawContactsSelectedCount(Integer.valueOf(contactSelection.getRawContacts().size())).suggestionsSelectedCount(Integer.valueOf(contactSelection.getSelectedSuggestionsCount())).build());
    }

    public void b(String string) {
        this.b.a("448daa5a-d90e", (eoc)ContactPickerMetadata.builder().featureName(string).eventName(aaqj.c.name()).appName(this.a).build());
    }
}

