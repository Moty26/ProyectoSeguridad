/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  eyq
 */
class aapi
implements axss<eyq> {
    private final aaow a;

    aapi(aaow aaow2) {
        this.a = aaow2;
    }

    public eyq a() {
        return (eyq)awec.a((Object)this.a.k(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

