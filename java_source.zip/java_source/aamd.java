/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hhy
 */
public class aamd {
    private final aanh a;
    private final boolean b;
    private final boolean c;
    private final aamf d;
    private final hhy<Boolean> e;

    aamd(aanh aanh2, boolean bl, boolean bl2, aamf aamf2, hhy<Boolean> hhy2) {
        this.a = aanh2;
        this.b = bl;
        this.c = bl2;
        this.d = aamf2;
        this.e = hhy2;
    }

    public aanh a() {
        return this.a;
    }

    public boolean b() {
        return this.b;
    }

    public boolean c() {
        return this.c;
    }

    public aamf d() {
        return this.d;
    }

    public boolean e() {
        if (this.e.b() && ((Boolean)this.e.c()).booleanValue()) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (aamd)object;
        if (this.a != object.a) {
            return false;
        }
        if (this.b != object.b) {
            return false;
        }
        if (this.c != object.c) {
            return false;
        }
        if (!this.d.equals(object.d)) {
            return false;
        }
        if (this.e.b() == object.e.b()) return true;
        if (!this.e.b()) return false;
        if (this.e.c() == object.e.c()) return true;
        return false;
    }

    public boolean f() {
        return this.d.a();
    }

    public boolean g() {
        if (!this.e.b() && this.a == aanh.a) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int hashCode() {
        int n = 1;
        int n2 = this.a.hashCode();
        int n3 = this.b ? 1 : 0;
        if (this.c) {
            return (((n3 + n2 * 31) * 31 + n) * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
        }
        n = 0;
        return (((n3 + n2 * 31) * 31 + n) * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
    }

    public String toString() {
        return String.format("action: %s, legalConsentPrimerShown: %s, featureConsentPrimerShown: %s, consentState: %s, permissionsGranted: %s", new Object[]{this.a, this.b, this.c, this.d, this.e});
    }
}

