/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.support.v7.widget.ActionBarContextView
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  zw
 *  zx
 */
import android.content.Context;
import android.support.v7.widget.ActionBarContextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.lang.ref.WeakReference;

public class aaa
extends zw
implements aau {
    private Context a;
    private ActionBarContextView b;
    private zx c;
    private WeakReference<View> d;
    private boolean e;
    private boolean f;
    private aat g;

    public aaa(Context context, ActionBarContextView actionBarContextView, zx zx2, boolean bl) {
        this.a = context;
        this.b = actionBarContextView;
        this.c = zx2;
        this.g = new aat(actionBarContextView.getContext()).a(1);
        this.g.a(this);
        this.f = bl;
    }

    public MenuInflater a() {
        return new aad(this.b.getContext());
    }

    public void a(int n) {
        this.b(this.a.getString(n));
    }

    @Override
    public void a(aat aat2) {
        this.d();
        this.b.a();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(View weakReference) {
        this.b.a(weakReference);
        weakReference = weakReference != null ? new WeakReference<WeakReference<Object>>(weakReference) : null;
        this.d = weakReference;
    }

    public void a(CharSequence charSequence) {
        this.b.b(charSequence);
    }

    public void a(boolean bl) {
        super.a(bl);
        this.b.a(bl);
    }

    @Override
    public boolean a(aat aat2, MenuItem menuItem) {
        return this.c.a((zw)this, menuItem);
    }

    public Menu b() {
        return this.g;
    }

    public void b(int n) {
        this.a(this.a.getString(n));
    }

    public void b(CharSequence charSequence) {
        this.b.a(charSequence);
    }

    public void c() {
        if (this.e) {
            return;
        }
        this.e = true;
        this.b.sendAccessibilityEvent(32);
        this.c.a((zw)this);
    }

    public void d() {
        this.c.b((zw)this, (Menu)this.g);
    }

    public CharSequence f() {
        return this.b.b();
    }

    public CharSequence g() {
        return this.b.c();
    }

    public boolean h() {
        return this.b.f();
    }

    public View i() {
        if (this.d != null) {
            return this.d.get();
        }
        return null;
    }
}

