/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactDetail$Type
 *  gss
 */
import com.ubercab.presidio.contacts.model.ContactDetail;

public class aaqt
implements aaqf {
    private String a;

    public aaqt(String string) {
        this.a = string;
    }

    @Override
    public int a() {
        return aaqs.ub__contact_picker_v2_search_hint_sms_contacts;
    }

    @Override
    public int a(aary aary2) {
        return aaqs.ub__contact_picker_search_query_add;
    }

    @Override
    public boolean a(ContactDetail contactDetail) {
        if (contactDetail.type() == ContactDetail.Type.PHONE_NUMBER && this.a(contactDetail.value())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean a(String string) {
        return gss.f((String)string, (String)this.a);
    }

    @Override
    public String b(String string) {
        return gss.b((String)string, (String)this.a);
    }
}

