/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 */
public final class aaid
implements awdv<aaih> {
    static final /* synthetic */ boolean a;
    private final aaia b;
    private final axss<aaik> c;
    private final axss<aagq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaid.class.desiredAssertionStatus();
        a = bl;
    }

    public aaid(aaia aaia2, axss<aaik> axss2, axss<aagq> axss3) {
        if (!a && aaia2 == null) {
            throw new AssertionError();
        }
        this.b = aaia2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aaih> a(aaia aaia2, axss<aaik> axss2, axss<aagq> axss3) {
        return new aaid(aaia2, axss2, axss3);
    }

    public aaih a() {
        return (aaih)awec.a((Object)this.b.a((aaik)((Object)this.c.get()), (aagq)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

