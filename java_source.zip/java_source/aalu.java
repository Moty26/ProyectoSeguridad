/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hik
 */
import java.util.Collections;
import java.util.Set;

public abstract class aalu {
    public static aalv k() {
        return new aali().a(Collections.<String>emptySet()).a(false).b(false);
    }

    public abstract String a();

    public abstract aanp b();

    public abstract aanp c();

    public abstract hik<String> d();

    public abstract int e();

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract boolean i();

    public abstract boolean j();

    public String[] l() {
        return (String[])this.d().toArray((Object[])new String[this.d().size()]);
    }
}

