/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awec
 *  axss
 *  esc
 */
class aagy
implements axss<esc<apap>> {
    private final aagd a;

    aagy(aagd aagd2) {
        this.a = aagd2;
    }

    public esc<apap> a() {
        return (esc)awec.a(this.a.cv_(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

