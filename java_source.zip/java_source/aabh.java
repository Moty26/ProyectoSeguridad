/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  awlj
 *  awlp
 *  awlq
 *  awlv
 *  awmh
 *  awnk
 *  axrf
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineAccessTokenModel
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineOtpModel
 *  eop
 *  eot
 *  eov
 *  ewc
 *  ewe
 *  ewf
 *  ewj
 *  ezx
 *  ezy
 *  ezz
 *  faa
 *  gsr
 *  hpz
 *  llg
 *  llw
 *  mog
 *  yzp
 *  zdb
 *  zpr
 *  zql
 *  zqu
 *  zqv
 */
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineAccessTokenModel;
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineOtpModel;
import java.util.concurrent.Callable;

public class aabh
extends ewj<ewf, aabj>
implements mog {
    private static String g = "";
    private static String i = "";
    ewc a;
    hpz b;
    aabd c;
    aabg d;
    Context e;
    zql f;
    private final zqv j = new zqv();

    /*
     * Enabled aggressive block sorting
     */
    private void a(Throwable throwable) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1TtbCs0XLJ7pZ07EMQGqzCTeECvQmU0+V0V5DmsajlKeE=", "enc::AvPafNPZogzAg8rqwR2YMHISjODeqeJJFIq4YUsLqT+U/mHmoRYNJ35rPMts8clZ", -3883737660415490358L, 3223290401409009629L, 8713956184916750228L, 6165381391493657874L, null, "enc::uDPNMWhZD8MpSodiqPLEpo2Tx6tyMG5c6dPr7VD4RJA=", 105) : null;
        throwable = this.j.a("line", "lineToken", aabl.a, this.e.getString(yzp.login_with_line_error), throwable);
        this.f.a((zqu)throwable, this.e.getString(yzp.login_with_line_error));
        if (llw2 != null) {
            llw2.i();
        }
    }

    public ezy<faa, mog> a(final String string) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1TtbCs0XLJ7pZ07EMQGqzCTeECvQmU0+V0V5DmsajlKeE=", "enc::V+EEBh8rBspSClTwDRtglpITTMJVAQNdA12h9Nsua0w40kJgNf/JocHZvkcNksSogNYBFzS1uK4tDgPj6MOsrWRwA9g1jdwwqcI+8EjNir1TbXizSQGovFP4vpW4nJ0J", -3883737660415490358L, 3223290401409009629L, 5824558257497416913L, 6165381391493657874L, null, "enc::uDPNMWhZD8MpSodiqPLEpo2Tx6tyMG5c6dPr7VD4RJA=", 117);
        }
        string = ezy.a((awlv)awlv.a((Callable)new Callable<awlv<ezz<faa, mog>>>(){

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public awlv<ezz<faa, mog>> a() throws Exception {
                if (!(g == null || g.isEmpty() || i.isEmpty() || string == null || string.isEmpty())) {
                    ((eov)aabh.this.c.a(g, string, i).observeOn(awmh.a()).to((awnk)new eot((eop)aabh.this))).a((awlp)new axrf<LineAccessTokenModel>(){

                        public void a(LineAccessTokenModel lineAccessTokenModel) {
                            long l = gsr.a((String)lineAccessTokenModel.expire(), (long)0);
                            lineAccessTokenModel = aabh.this.j.a("line", l, "lineToken", lineAccessTokenModel.accessToken(), aabl.a);
                            aabh.this.f.a((zqu)lineAccessTokenModel);
                        }

                        public void onComplete() {
                        }

                        public void onError(Throwable throwable) {
                            aabh.this.a(throwable);
                        }

                        public /* synthetic */ void onNext(Object object) {
                            this.a((LineAccessTokenModel)object);
                        }
                    });
                    do {
                        return awlv.b((Object)ezz.a((ezx)aabh.this));
                        break;
                    } while (true);
                }
                aabh.this.a(new IllegalStateException("channel id/otp not available"));
                return awlv.b((Object)ezz.a((ezx)aabh.this));
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }

        }));
        if (llw2 != null) {
            llw2.i();
        }
        return string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void a(ewe object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1TtbCs0XLJ7pZ07EMQGqzCTeECvQmU0+V0V5DmsajlKeE=", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", -3883737660415490358L, 3223290401409009629L, -8133349418566419115L, 6165381391493657874L, null, "enc::uDPNMWhZD8MpSodiqPLEpo2Tx6tyMG5c6dPr7VD4RJA=", 57) : null;
        this.f.a(zdb.c);
        super.a((ewe)object);
        try {
            object = this.e.getPackageManager().getApplicationInfo(this.e.getPackageName(), 128);
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            this.f.a(zdb.b);
            this.a((Throwable)nameNotFoundException);
        }
        g = (String)object.metaData.get("jp.line.sdk.ChannelId");
        object = this.e.getPackageName();
        if (g != null && object != null && !g.isEmpty() && !object.isEmpty()) {
            ((eov)this.c.a(g).observeOn(awmh.a()).to((awnk)new eot((eop)this))).a((awlp)new axrf<LineOtpModel>((String)object){
                final /* synthetic */ String a;

                public void a(LineOtpModel lineOtpModel) {
                    i = lineOtpModel.otp();
                    if (g != null) {
                        aabh.this.a.startActivity(aabh.this.d.a(lineOtpModel, g, this.a));
                        aabh.this.f.a(zdb.d);
                    }
                }

                public void onComplete() {
                }

                public void onError(Throwable throwable) {
                    aabh.this.f.a(zdb.b);
                    aabh.this.a(throwable);
                }

                public /* synthetic */ void onNext(Object object) {
                    this.a((LineOtpModel)object);
                }
            });
        } else {
            this.f.a(zdb.b);
            this.a(new IllegalStateException("channel id not available"));
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

}

