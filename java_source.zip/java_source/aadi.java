/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior
 *  com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior$1
 */
import com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior;

public class aadi {
    private int a;
    private int b;

    private aadi(int n, int n2) {
        this.a = n;
        this.b = n2;
    }

    public /* synthetic */ aadi(int n, int n2, ExpandingBottomSheetBehavior.1 var3_3) {
        this(n, n2);
    }

    public static /* synthetic */ int a(aadi aadi2) {
        return aadi2.a;
    }

    public static /* synthetic */ int b(aadi aadi2) {
        return aadi2.b;
    }
}

