/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  axss
 *  hpz
 */
public final class aaqe
implements awdv<aaqd> {
    static final /* synthetic */ boolean a;
    private final axss<hpz> b;
    private final axss<aaqb> c;
    private final axss<aaqh> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaqe.class.desiredAssertionStatus();
        a = bl;
    }

    public aaqe(axss<hpz> axss2, axss<aaqb> axss3, axss<aaqh> axss4) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
    }

    public static awdv<aaqd> a(axss<hpz> axss2, axss<aaqb> axss3, axss<aaqh> axss4) {
        return new aaqe(axss2, axss3, axss4);
    }

    public aaqd a() {
        return new aaqd((hpz)this.b.get(), (aaqb)this.c.get(), (aaqh)this.d.get());
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

