/*
 * Decompiled with CFR 0_119.
 */
interface aait {
    public aajf f();
}

