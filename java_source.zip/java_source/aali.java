/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hik
 */
import java.util.Set;

final class aali
extends aalv {
    private String a;
    private aanp b;
    private aanp c;
    private hik<String> d;
    private Integer e;
    private Integer f;
    private Integer g;
    private Integer h;
    private Boolean i;
    private Boolean j;

    aali() {
    }

    @Override
    public aalu a() {
        String string = "";
        if (this.a == null) {
            string = "" + " tag";
        }
        String string2 = string;
        if (this.b == null) {
            string2 = string + " legalConsentPrimerConfig";
        }
        string = string2;
        if (this.d == null) {
            string = string2 + " permissions";
        }
        string2 = string;
        if (this.e == null) {
            string2 = string + " appSettingsConfirmTitle";
        }
        string = string2;
        if (this.f == null) {
            string = string2 + " appSettingsConfirmMessage";
        }
        string2 = string;
        if (this.g == null) {
            string2 = string + " appSettingsConfirmButtonText";
        }
        string = string2;
        if (this.h == null) {
            string = string2 + " appSettingsCancelButtonText";
        }
        string2 = string;
        if (this.i == null) {
            string2 = string + " forceShowLegalConsent";
        }
        string = string2;
        if (this.j == null) {
            string = string2 + " disableLegalConsent";
        }
        if (!string.isEmpty()) {
            throw new IllegalStateException("Missing required properties:" + string);
        }
        return new aalh(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
    }

    @Override
    public aalv a(int n) {
        this.e = n;
        return this;
    }

    @Override
    public aalv a(aanp aanp2) {
        if (aanp2 == null) {
            throw new NullPointerException("Null legalConsentPrimerConfig");
        }
        this.b = aanp2;
        return this;
    }

    @Override
    public aalv a(String string) {
        if (string == null) {
            throw new NullPointerException("Null tag");
        }
        this.a = string;
        return this;
    }

    @Override
    public aalv a(Set<String> set) {
        if (set == null) {
            throw new NullPointerException("Null permissions");
        }
        this.d = hik.a(set);
        return this;
    }

    @Override
    public aalv a(boolean bl) {
        this.i = bl;
        return this;
    }

    @Override
    public aalv b(int n) {
        this.f = n;
        return this;
    }

    @Override
    public aalv b(aanp aanp2) {
        this.c = aanp2;
        return this;
    }

    @Override
    public aalv b(boolean bl) {
        this.j = bl;
        return this;
    }

    @Override
    public aalv c(int n) {
        this.g = n;
        return this;
    }

    @Override
    public aalv d(int n) {
        this.h = n;
        return this;
    }
}

