/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdr
 *  awdu
 *  axss
 *  axug
 *  dze
 *  ewc
 *  ewf
 *  ewj
 *  ewq
 *  hpz
 *  zql
 *  zye
 */
import android.content.Context;

public final class aaap
implements aaax {
    static final /* synthetic */ boolean a;
    private axss<ewf> b;
    private axss<ewc> c;
    private axss<hpz> d;
    private axss<axug> e;
    private axss<dze> f;
    private axss<aabd> g;
    private axss<Context> h;
    private axss<aabg> i;
    private axss<zql> j;
    private awdr<aabh> k;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaap.class.desiredAssertionStatus();
        a = bl;
    }

    private aaap(aaaq aaaq2) {
        if (!a && aaaq2 == null) {
            throw new AssertionError();
        }
        this.a(aaaq2);
    }

    public static aaaq a() {
        return new aaaq(null);
    }

    private void a(aaaq aaaq2) {
        this.b = awdu.a(aabb.a(aaaq.a(aaaq2)));
        this.c = new aaar(aaaq.b(aaaq2));
        this.d = new aaas(aaaq.b(aaaq2));
        this.e = new aaau(aaaq.b(aaaq2));
        this.f = aabc.a(aaaq.a(aaaq2));
        this.g = awdu.a(aaba.a(aaaq.a(aaaq2), this.e, this.f));
        this.h = new aaat(aaaq.b(aaaq2));
        this.i = awdu.a(aaaz.a(aaaq.a(aaaq2), this.h));
        this.j = new aaav(aaaq.b(aaaq2));
        this.k = aabi.a(this.b, this.c, this.d, this.g, this.i, this.h, this.j);
    }

    public /* synthetic */ ewq O_() {
        return this.b();
    }

    public void a(aabh aabh2) {
        this.k.a((Object)aabh2);
    }

    public ewf b() {
        return (ewf)this.b.get();
    }

    @Override
    public ewc d() {
        return (ewc)this.c.get();
    }

    @Override
    public aabg e() {
        return (aabg)this.i.get();
    }

}

