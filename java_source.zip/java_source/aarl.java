/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.contacts.dropdown.ContactsDropDownView
 *  ewj
 *  ewl
 *  exm
 */
import android.view.View;
import com.ubercab.presidio.contacts.dropdown.ContactsDropDownView;

public class aarl
extends exm<ContactsDropDownView, aarh, aaqw> {
    public aarl(ContactsDropDownView contactsDropDownView, aarh aarh2, aaqw aaqw2) {
        super((View)contactsDropDownView, (ewj)aarh2, (ewl)aaqw2);
    }
}

