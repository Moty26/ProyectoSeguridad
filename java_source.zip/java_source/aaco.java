/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationManager
 *  android.content.Context
 */
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;

public class aaco {
    private NotificationManager a;

    public aaco(Context context) {
        this.a = (NotificationManager)context.getSystemService("notification");
    }

    public void a(Notification notification) {
        if (this.a != null) {
            this.a.notify(0, notification);
        }
    }
}

