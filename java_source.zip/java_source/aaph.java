/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apaq
 *  awec
 *  axss
 */
class aaph
implements axss<apaq> {
    private final aaow a;

    aaph(aaow aaow2) {
        this.a = aaow2;
    }

    public apaq a() {
        return (apaq)awec.a((Object)this.a.j(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

