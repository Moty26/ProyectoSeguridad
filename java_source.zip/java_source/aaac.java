/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewc
 *  ewf
 *  ewm
 */
interface aaac
extends ewm<ewf, aaaj> {
    public ewc d();

    public aaai e();
}

