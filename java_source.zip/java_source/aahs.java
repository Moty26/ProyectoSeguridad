/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aahs
implements axss<aagq> {
    private final aahf a;

    aahs(aahf aahf2) {
        this.a = aahf2;
    }

    public aagq a() {
        return (aagq)awec.a((Object)this.a.a(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

