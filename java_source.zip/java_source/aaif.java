/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewj
 *  ewz
 *  llg
 *  llw
 */
public class aaif
extends ewj<aaih, aaij>
implements aaii {
    aaih a;
    aagq b;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(String object, String string, int n, String string2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqPw+qqt4kP9/1lYuR7H8dFqpWOHAKYcAV6nG49oEHog+", "enc::+h1tLDd02ucW+8SvFzR68yipevNYxS5ycOcu00bMpvlj7gGb0deyoHi1sndNSDAgH15B2vMnb2S2ZMdeHoO04gjyWGD9yeci6ZeJrxiEgQPypNGgOvFvy+7F8u2RM9C2", -3295476322921135584L, 3455480235303190760L, 858170181721350364L, 6165381391493657874L, null, "enc::atEfgvPYLktmgAD18YGYTdPksASivI+H0HOIqWwAl9n3COtkiOcVF2eidVD2aeuy", 31) : null;
        object = new aagt((String)object, string, n, string2);
        this.b.a((aagt)object);
        ((aaij)this.h()).j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqPw+qqt4kP9/1lYuR7H8dFqpWOHAKYcAV6nG49oEHog+", "enc::uU+BkhZsHDaU/gtvAJ2vy7SxXQ57Z4DaudwJi2tPMFE=", -3295476322921135584L, 3455480235303190760L, -3564081918521942663L, 6165381391493657874L, null, "enc::atEfgvPYLktmgAD18YGYTdPksASivI+H0HOIqWwAl9n3COtkiOcVF2eidVD2aeuy", 22);
        }
        ((aaij)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqPw+qqt4kP9/1lYuR7H8dFqpWOHAKYcAV6nG49oEHog+", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", -3295476322921135584L, 3455480235303190760L, -6923720291955140451L, 6165381391493657874L, null, "enc::atEfgvPYLktmgAD18YGYTdPksASivI+H0HOIqWwAl9n3COtkiOcVF2eidVD2aeuy", 44);
        }
        ((aaij)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }
}

