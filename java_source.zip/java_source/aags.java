/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.countrypicker.core.model.Country
 */
import com.ubercab.presidio.countrypicker.core.model.Country;

public class aags {
    private final String a;
    private final String b;
    private final String c;
    private final String d;
    private final Long e;
    private final Country f;

    public aags(String string, String string2, String string3, String string4, Long l, Country country) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = l;
        this.f = country;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public String c() {
        return this.c;
    }

    public String d() {
        return this.d;
    }

    public Long e() {
        return this.e;
    }

    public Country f() {
        return this.f;
    }
}

