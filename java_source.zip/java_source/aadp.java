/*
 * Decompiled with CFR 0_119.
 */
public interface aadp {
    public void a(int var1);
}

