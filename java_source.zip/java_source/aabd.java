/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdq
 *  awep
 *  awlj
 *  awlq
 *  axrq
 *  axug
 *  axuh
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.LineApi
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineAccessTokenModel
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineOtpModel
 *  dze
 *  retrofit2.CallAdapter
 *  retrofit2.CallAdapter$Factory
 *  retrofit2.Converter
 *  retrofit2.Converter$Factory
 *  retrofit2.Retrofit
 *  retrofit2.Retrofit$Builder
 *  retrofit2.adapter.rxjava.RxJavaCallAdapterFactory
 *  retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
 *  retrofit2.converter.gson.GsonConverterFactory
 */
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.LineApi;
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineAccessTokenModel;
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineOtpModel;
import java.util.List;
import java.util.Locale;
import retrofit2.CallAdapter;
import retrofit2.Converter;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class aabd {
    private final LineApi a;

    public aabd(awdq<axug> axuh2, dze dze2) {
        axuh2 = ((axug)axuh2.get()).y();
        axuh2.a().clear();
        axuh2.b().clear();
        this.a = (LineApi)new Retrofit.Builder().client(axuh2.c()).addConverterFactory((Converter.Factory)aabe.a()).addConverterFactory((Converter.Factory)GsonConverterFactory.create((dze)dze2)).addCallAdapterFactory((CallAdapter.Factory)RxJava2CallAdapterFactory.createWithScheduler((awlq)axrq.b())).addCallAdapterFactory((CallAdapter.Factory)RxJavaCallAdapterFactory.createWithScheduler((ayko)aywl.d())).baseUrl("https://api.line.me/").build().create(LineApi.class);
    }

    private String a(String string, String string2) {
        return String.format(Locale.US, "%s=%s", string, string2);
    }

    awlj<LineOtpModel> a(String string) {
        string = String.format(Locale.US, "%s=%s", "channelId", string);
        return awep.b((ayki)this.a.getOtp(string));
    }

    awlj<LineAccessTokenModel> a(String string, String string2, String string3) {
        string = String.format(Locale.US, "%s&%s&%s", this.a("channelId", string), this.a("requestToken", string2), this.a("otp", string3));
        return awep.b((ayki)this.a.getAccessToken(string));
    }
}

