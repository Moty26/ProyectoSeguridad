/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 */
public final class aahg
implements awdv<aahv> {
    static final /* synthetic */ boolean a;
    private final aahe b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aahg.class.desiredAssertionStatus();
        a = bl;
    }

    public aahg(aahe aahe2) {
        if (!a && aahe2 == null) {
            throw new AssertionError();
        }
        this.b = aahe2;
    }

    public static awdv<aahv> a(aahe aahe2) {
        return new aahg(aahe2);
    }

    public aahv a() {
        return (aahv)((Object)awec.a((Object)((Object)this.b.a()), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

