/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.provider.ContactsContract
 *  android.provider.ContactsContract$CommonDataKinds
 *  android.provider.ContactsContract$CommonDataKinds$Email
 *  android.provider.ContactsContract$CommonDataKinds$Phone
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  com.ubercab.presidio.contacts.model.Contact
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  com.ubercab.presidio.contacts.model.ContactDetail$Type
 *  ejv
 *  ekh
 *  hhy
 */
import android.content.res.Resources;
import android.net.Uri;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ubercab.presidio.contacts.model.Contact;
import com.ubercab.presidio.contacts.model.ContactDetail;

class aasc
extends aata<aasd> {
    private final ejv n;
    private final aaqg o;
    private final View p;
    private final TextView q;
    private final TextView r;
    private final ImageView s;
    private final ImageView t;

    aasc(aaqg aaqg2, ejv ejv2, View view) {
        super(view);
        this.n = ejv2;
        this.o = aaqg2;
        this.p = view;
        this.q = (TextView)this.p.findViewById(aaqq.ub__contact_display_name);
        this.s = (ImageView)this.p.findViewById(aaqq.ub__contact_picker_profile_picture);
        this.r = (TextView)this.p.findViewById(aaqq.ub__contact_detail_row);
        this.t = (ImageView)this.p.findViewById(aaqq.ub__contact_checkmark);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private CharSequence a(ContactDetail object, View object2, aasd aasd2) {
        Resources resources = object2.getResources();
        object2 = this.o.a((ContactDetail)object);
        if (!aasd2.f) {
            return object2;
        }
        int n = object.detailType();
        if (n == -1 || n == 3 || n == 7) {
            return object2;
        }
        if (object.type() == ContactDetail.Type.EMAIL) {
            object = ContactsContract.CommonDataKinds.Email.getTypeLabel((Resources)resources, (int)n, (CharSequence)null);
            do {
                return object2 + " - " + object;
                break;
            } while (true);
        }
        object = ContactsContract.CommonDataKinds.Phone.getTypeLabel((Resources)resources, (int)n, (CharSequence)null);
        return object2 + " - " + object;
    }

    private void b(aasd aasd2) {
        hhy hhy2 = aasd2.a.photoThumbnailUri();
        if (hhy2.b() && aasd2.d == 0) {
            this.n.a((Uri)hhy2.c()).a(this.s);
            this.s.setVisibility(aasd2.d);
            return;
        }
        this.s.setVisibility(8);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(aasd aasd2) {
        ContactDetail contactDetail = aasd2.b;
        this.p.setSelected(aasd2.e);
        this.p.setOnClickListener(aasd2.c);
        ImageView imageView = this.t;
        int n = aasd2.e ? 0 : 4;
        imageView.setVisibility(n);
        this.q.setText((CharSequence)contactDetail.displayName());
        this.r.setText(this.a(contactDetail, (View)this.r, aasd2));
        this.b(aasd2);
    }
}

