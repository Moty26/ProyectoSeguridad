/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.experiment.model.TreatmentGroup
 */
import com.ubercab.experiment.model.TreatmentGroup;

public enum aadu implements TreatmentGroup
{
    a,
    b,
    c;
    

    private aadu() {
    }
}

