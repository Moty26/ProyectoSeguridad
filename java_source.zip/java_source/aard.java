/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  awdv
 *  awec
 */
import android.view.LayoutInflater;

public final class aard
implements awdv<LayoutInflater> {
    static final /* synthetic */ boolean a;
    private final aaqx b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aard.class.desiredAssertionStatus();
        a = bl;
    }

    public aard(aaqx aaqx2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
    }

    public static awdv<LayoutInflater> a(aaqx aaqx2) {
        return new aard(aaqx2);
    }

    public LayoutInflater a() {
        return (LayoutInflater)awec.a((Object)this.b.b(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

