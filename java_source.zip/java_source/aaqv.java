/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.contacts.dropdown.ContactsDropDownView
 *  exk
 *  llg
 *  llw
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.contacts.dropdown.ContactsDropDownView;

public class aaqv
extends exk<ContactsDropDownView, aarl, aaqy> {
    public aaqv(aaqy aaqy2) {
        super((Object)aaqy2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aarl b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtg7qP+wijLNbLiG3S0Dj+46A==", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2eGNxdwxglj29tSwoSvMIObcvnxUv2YadjvO0xSOHK6mOQ/KnbMJLIZLQGY+yl/8HlSCbPtKvnFoBltL20leG0Q==", 2819679059983535793L, 4585385941533457779L, -4576351041090114695L, 7185931817553012858L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQco3C1ovOSITyZAIkjtEFYY=", 57) : null;
        object = (ContactsDropDownView)this.a_((ViewGroup)object);
        aarh aarh2 = new aarh();
        object = new aarl((ContactsDropDownView)object, aarh2, aarm.a().a((aaqy)this.bS_()).a(new aaqx(aarh2, (ContactsDropDownView)object)).a());
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    protected ContactsDropDownView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater = null;
        if (llg.b()) {
            layoutInflater = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtg7qP+wijLNbLiG3S0Dj+46A==", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++z/3TEOdppFz4xc6cJ58/IJJKuaiHryYXemQ8Ggipo0WcTITe14W/pU2yfed5/cdNK", 2819679059983535793L, 4585385941533457779L, -766512063962971949L, 7185931817553012858L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQco3C1ovOSITyZAIkjtEFYY=", 70);
        }
        viewGroup = new ContactsDropDownView(viewGroup.getContext());
        if (layoutInflater != null) {
            layoutInflater.i();
        }
        return viewGroup;
    }
}

