/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  auih
 *  awlq
 *  awlv
 *  awlx
 *  awmh
 *  awnk
 *  com.uber.model.core.generated.crack.cobrandcard.OfferRequest
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.OfferErrors
 *  eop
 *  epb
 *  epd
 *  esi
 *  ewe
 *  ewj
 *  ewz
 *  llg
 *  llw
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferRequest;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.OfferErrors;

public class aagl
extends ewj<aagn, aagp>
implements aago {
    CobrandCardClient<apap> a;
    aagn b;
    Boolean c;
    private OfferResponse d;

    private void m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::wkroHD4IXRz0whjECXgDCbZVU3Q8MuXgVonhRLtrumk=", 7963966960560010407L, 455391849889117831L, 2705775279395529845L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 61);
        }
        ((aagp)this.h()).j();
        this.b.j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void n() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::6l1IdRZIw2hCeJZ5+MHkLtRBr1XvfUY25oni4AyjA5Q=", 7963966960560010407L, 455391849889117831L, 1985936714632279494L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 66);
        }
        OfferRequest offerRequest = OfferRequest.builder().build();
        ((epd)this.a.offer(offerRequest).a(awmh.a()).j((awnk)new epb((eop)this))).a((awlx)new auih<esi<OfferResponse, OfferErrors>>(){

            public void a(esi<OfferResponse, OfferErrors> offerResponse) {
                if ((offerResponse = (OfferResponse)offerResponse.a()) != null) {
                    aagl.this.d = offerResponse;
                    ((aagp)aagl.this.h()).j();
                    aagl.this.b.j();
                    return;
                }
                aagl.this.b.l();
            }

            public /* synthetic */ void b(Object object) throws Exception {
                this.a((esi)object);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ewe ewe2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", 7963966960560010407L, 455391849889117831L, -8133349418566419115L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 49);
        }
        super.a(ewe2);
        this.b.b();
        if (!this.c.booleanValue()) {
            this.b.b();
            this.n();
        } else {
            this.m();
        }
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::uU+BkhZsHDaU/gtvAJ2vy7SxXQ57Z4DaudwJi2tPMFE=", 7963966960560010407L, 455391849889117831L, -3564081918521942663L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 38);
        }
        ((aagp)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public OfferResponse e() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::DjLdIFPj96BQLWdbC+NfeZluKUL06phAYWf5dp4wLwV0UpuRnWwr8o5gCzZGc0w9247uBP7aYTP5p6qEbE1jndu2gYghWVgrRiXpgwXGO2A8Zlrb+FZkk6aM/1YsFr/l", 7963966960560010407L, 455391849889117831L, -569444654408740498L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 88);
        }
        OfferResponse offerResponse = this.d;
        if (llw2 != null) {
            llw2.i();
        }
        return offerResponse;
    }

    @Override
    public void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::WJ6hE05nLd94rWOcNQ/foez+wVtu/lLmKxbeyMsG360=", 7963966960560010407L, 455391849889117831L, 6577556923684017193L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 93);
        }
        ((aagp)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm8kEN79V6omxB+k0vQ0qlgM=", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", 7963966960560010407L, 455391849889117831L, -6923720291955140451L, 6165381391493657874L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcPemPKePMmB92mm4NDF+LwmLZijYhQx6RV0xCegLIBPH", 43);
        }
        this.b.k();
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }

}

