/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  ewf
 */
public final class aaag
implements awdv<ewf> {
    static final /* synthetic */ boolean a;
    private final aaad b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaag.class.desiredAssertionStatus();
        a = bl;
    }

    public aaag(aaad aaad2) {
        if (!a && aaad2 == null) {
            throw new AssertionError();
        }
        this.b = aaad2;
    }

    public static awdv<ewf> a(aaad aaad2) {
        return new aaag(aaad2);
    }

    public ewf a() {
        return (ewf)awec.a((Object)this.b.a(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

