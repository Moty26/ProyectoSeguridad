/*
 * Decompiled with CFR 0_119.
 */
interface aafp
extends aako {
}

