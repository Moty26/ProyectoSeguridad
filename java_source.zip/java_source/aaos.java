/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  eih
 *  ewz
 */
class aaos
implements aapu {
    final /* synthetic */ aaor a;

    aaos(aaor aaor2) {
        this.a = aaor2;
    }

    @Override
    public void a() {
        aaor.a(this.a, false);
        ((aaox)this.a.h()).h();
    }

    @Override
    public void a(String string) {
        aaor.b(this.a, true);
        this.a.l.a((Object)string);
        aaor.a(this.a, false);
        ((aaox)this.a.h()).h();
    }
}

