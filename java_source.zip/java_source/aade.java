/*
 * Decompiled with CFR 0_119.
 */
public interface aade {
    public int p();
}

