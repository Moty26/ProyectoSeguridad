/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  ewf
 *  ewj
 *  ewn
 *  eyq
 */
import android.content.Context;

public class aaok
extends ewn<aaor> {
    private final Context a;

    public aaok(Context context, aaor aaor2) {
        super((ewj)aaor2);
        this.a = context;
    }

    aaox a(aaoj aaoj2, eyq eyq2) {
        return new aaox((aaor)this.d(), aaoj2, eyq2, new aapo(aaoj2));
    }

    ewf a() {
        return new ewf();
    }

    aaoq b() {
        return new aaoq(this.a);
    }

    aapu c() {
        aaor aaor2 = (aaor)this.d();
        aaor2.getClass();
        return new aaos(aaor2);
    }

    aaob e() {
        aaor aaor2 = (aaor)this.d();
        aaor2.getClass();
        return new aaou(aaor2);
    }
}

