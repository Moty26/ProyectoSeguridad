/*
 * Decompiled with CFR 0_119.
 */
import java.util.Set;

public abstract class aalv {
    public abstract aalu a();

    public abstract aalv a(int var1);

    public abstract aalv a(aanp var1);

    public abstract aalv a(String var1);

    public abstract aalv a(Set<String> var1);

    public abstract aalv a(boolean var1);

    public abstract aalv b(int var1);

    public abstract aalv b(aanp var1);

    public abstract aalv b(boolean var1);

    public abstract aalv c(int var1);

    public abstract aalv d(int var1);
}

