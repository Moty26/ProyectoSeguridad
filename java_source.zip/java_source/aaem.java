/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afi
 *  auhz
 *  avvm
 *  awlj
 *  eih
 */
public class aaem
extends avvm<aael>
implements aaes {
    private final eih<auhz> a = eih.a();

    public aaem() {
        this.a(new afi(){

            public void a() {
                aaem.this.a.a((Object)auhz.a);
            }
        });
    }

    @Override
    public awlj<auhz> b() {
        return this.a.hide();
    }

}

