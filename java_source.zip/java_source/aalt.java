/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  awdv
 *  awec
 *  axss
 *  eyq
 */
import android.view.ViewGroup;

public final class aalt
implements awdv<aame> {
    static final /* synthetic */ boolean a;
    private final axss<aaln> b;
    private final axss<aalx> c;
    private final axss<ViewGroup> d;
    private final axss<eyq> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aalt.class.desiredAssertionStatus();
        a = bl;
    }

    public aalt(axss<aaln> axss2, axss<aalx> axss3, axss<ViewGroup> axss4, axss<eyq> axss5) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
    }

    public static awdv<aame> a(axss<aaln> axss2, axss<aalx> axss3, axss<ViewGroup> axss4, axss<eyq> axss5) {
        return new aalt(axss2, axss3, axss4, axss5);
    }

    public aame a() {
        return (aame)((Object)awec.a((Object)((Object)aalp.a((aaln)this.b.get(), (aalx)this.c.get(), (ViewGroup)this.d.get(), (eyq)this.e.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

