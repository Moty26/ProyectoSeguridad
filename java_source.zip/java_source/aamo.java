/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  lms
 */
class aamo
implements axss<lms> {
    private final aamc a;

    aamo(aamc aamc2) {
        this.a = aamc2;
    }

    public lms a() {
        return (lms)awec.a((Object)this.a.E(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

