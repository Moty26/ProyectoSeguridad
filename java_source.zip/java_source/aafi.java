/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  apaq
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 *  esc
 *  ewc
 *  ewj
 *  eyq
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

public final class aafi
implements aaev {
    static final /* synthetic */ boolean a;
    private axss<CobrandCardOfferView> b;
    private axss<aaff> c;
    private axss<esc<apap>> d;
    private axss<CobrandCardDataTransactions<apap>> e;
    private axss<CobrandCardClient<apap>> f;
    private awdr<aafc> g;
    private axss<aaev> h;
    private axss<aafc> i;
    private axss<eyq> j;
    private axss<ewc> k;
    private axss<aafh> l;
    private axss<apaq> m;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aafi.class.desiredAssertionStatus();
        a = bl;
    }

    private aafi(aafj aafj2) {
        if (!a && aafj2 == null) {
            throw new AssertionError();
        }
        this.a(aafj2);
    }

    private void a(aafj aafj2) {
        this.b = awdw.a((Object)aafj.a(aafj2));
        this.c = awdu.a(this.b);
        this.d = new aafl(aafj.b(aafj2));
        this.e = awdu.a(aafa.b());
        this.f = awdu.a(aaez.a(this.d, this.e));
        this.g = aafe.a(this.c, this.f);
        this.h = awdw.a((Object)this);
        this.i = awdw.a((Object)aafj.c(aafj2));
        this.j = new aafn(aafj.b(aafj2));
        this.k = new aafk(aafj.b(aafj2));
        this.l = awdu.a(aafb.a(this.h, this.b, this.i, this.j, this.k));
        this.m = new aafm(aafj.b(aafj2));
    }

    public static aaew b() {
        return new aafj(null);
    }

    @Override
    public apaq B() {
        return (apaq)this.m.get();
    }

    @Override
    public aafh a() {
        return (aafh)((Object)this.l.get());
    }

    public void a(aafc aafc2) {
        this.g.a((Object)aafc2);
    }

    @Override
    public eyq bU_() {
        return (eyq)this.j.get();
    }

    @Override
    public esc<apap> cv_() {
        return (esc)this.d.get();
    }

    @Override
    public ewc d() {
        return (ewc)this.k.get();
    }

}

