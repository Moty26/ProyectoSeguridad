/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ShortcutInfo
 *  android.content.pm.ShortcutInfo$Builder
 *  android.content.res.Resources
 *  android.graphics.drawable.Icon
 *  android.net.Uri
 *  arqv
 *  com.uber.model.core.generated.ms.search.generated.GeolocationResult
 *  hhy
 */
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.res.Resources;
import android.graphics.drawable.Icon;
import android.net.Uri;
import com.uber.model.core.generated.ms.search.generated.GeolocationResult;

class aabp
implements aabq {
    private aabp() {
    }

    @TargetApi(value=23)
    @Override
    public Icon a(Context context, int n) {
        return Icon.createWithResource((Context)context, (int)n);
    }

    @TargetApi(value=25)
    @Override
    public hhy<ShortcutInfo> a(Context context, GeolocationResult geolocationResult, String string, String string2, Icon icon, String string3) {
        return hhy.b((Object)new ShortcutInfo.Builder(context, string).setShortLabel((CharSequence)string2).setLongLabel((CharSequence)string2).setIcon(icon).setIntent(new Intent("android.intent.action.VIEW", Uri.parse((String)string3))).build());
    }

    @Override
    public String a(Context context, String string) {
        return arqv.a((String)string, (Resources)context.getResources());
    }

    @Override
    public String b(Context context, int n) {
        return context.getResources().getString(n);
    }
}

