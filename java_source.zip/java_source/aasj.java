/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  awdv
 *  axss
 *  com.ubercab.presidio.contacts.model.ContactPickerV2Config
 *  hpz
 */
import android.content.res.Resources;
import com.ubercab.presidio.contacts.model.ContactPickerV2Config;

public final class aasj
implements awdv<aash> {
    static final /* synthetic */ boolean a;
    private final axss<ContactPickerV2Config> b;
    private final axss<aasi> c;
    private final axss<Resources> d;
    private final axss<aavl> e;
    private final axss<hpz> f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aasj.class.desiredAssertionStatus();
        a = bl;
    }

    public aasj(axss<ContactPickerV2Config> axss2, axss<aasi> axss3, axss<Resources> axss4, axss<aavl> axss5, axss<hpz> axss6) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
    }

    public static awdv<aash> a(axss<ContactPickerV2Config> axss2, axss<aasi> axss3, axss<Resources> axss4, axss<aavl> axss5, axss<hpz> axss6) {
        return new aasj(axss2, axss3, axss4, axss5, axss6);
    }

    public aash a() {
        return new aash((ContactPickerV2Config)this.b.get(), (aasi)this.c.get(), (Resources)this.d.get(), (aavl)((Object)this.e.get()), (hpz)this.f.get());
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

