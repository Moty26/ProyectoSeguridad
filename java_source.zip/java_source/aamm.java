/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  fbz
 */
class aamm
implements axss<fbz> {
    private final aamc a;

    aamm(aamc aamc2) {
        this.a = aamc2;
    }

    public fbz a() {
        return (fbz)awec.a((Object)this.a.aE_(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

