/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  hix
 */
import android.content.Context;
import android.content.res.AssetManager;
import java.io.IOException;
import java.io.InputStream;

class aaby
implements aabx {
    private aaby() {
    }

    @Override
    public String a(Context object, String string) {
        try {
            object = hix.c((InputStream)object.getAssets().open(string));
            return object;
        }
        catch (IOException iOException) {
            kly.a(aabz.b).b(iOException, "Could not open asset.", new Object[0]);
            return null;
        }
    }
}

