/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 */
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public final class aaqz
implements awdv<aaqg> {
    static final /* synthetic */ boolean a;
    private final aaqx b;
    private final axss<ContactPickerCustomization> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaqz.class.desiredAssertionStatus();
        a = bl;
    }

    public aaqz(aaqx aaqx2, axss<ContactPickerCustomization> axss2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
    }

    public static awdv<aaqg> a(aaqx aaqx2, axss<ContactPickerCustomization> axss2) {
        return new aaqz(aaqx2, axss2);
    }

    public aaqg a() {
        return (aaqg)awec.a((Object)this.b.a((ContactPickerCustomization)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

