/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alww
 *  alxc
 *  android.os.Build
 *  android.os.Build$VERSION
 *  artc
 *  axss
 *  com.uber.rib.core.RibActivity
 *  exn
 *  hpz
 *  hqg
 *  irn
 */
import android.os.Build;
import com.uber.rib.core.RibActivity;

public class aabr
implements alws<alww, exn> {
    private final axss<hpz> a;
    private final axss<artc> b;
    private final axss<RibActivity> c;

    public aabr(axss<hpz> axss2, axss<artc> axss3, axss<RibActivity> axss4) {
        this.a = axss2;
        this.b = axss3;
        this.c = axss4;
    }

    public alxc a() {
        return aabn.a;
    }

    public exn a(alww alww2) {
        return new aabo((artc)this.b.get(), (RibActivity)this.c.get());
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((alww)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((alww)object);
    }

    public String b() {
        return "9b10f9e9-724e-421f-9060-8ec1b9b7809b";
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean b(alww alww2) {
        if (Build.VERSION.SDK_INT < 25) {
            return false;
        }
        if (!((hpz)this.a.get()).a((hqg)irn.APP_SHORTCUTS)) return false;
        if (!((hpz)this.a.get()).a((hqg)irn.RIDER_CACHE_FAVORITES)) return false;
        return true;
    }
}

