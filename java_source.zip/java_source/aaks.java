/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  hie
 */
import android.content.Context;
import android.content.res.Resources;

public class aaks {
    private Context a;
    private CharSequence b;
    private CharSequence c;
    private hie<String> d = hie.c();
    private CharSequence e;
    private boolean f = true;
    private boolean g = true;

    aaks(Context context) {
        this.a = context;
    }

    static /* synthetic */ Context a(aaks aaks2) {
        return aaks2.a;
    }

    static /* synthetic */ boolean b(aaks aaks2) {
        return aaks2.g;
    }

    static /* synthetic */ boolean c(aaks aaks2) {
        return aaks2.f;
    }

    static /* synthetic */ CharSequence d(aaks aaks2) {
        return aaks2.b;
    }

    static /* synthetic */ CharSequence e(aaks aaks2) {
        return aaks2.c;
    }

    static /* synthetic */ CharSequence f(aaks aaks2) {
        return aaks2.e;
    }

    static /* synthetic */ hie g(aaks aaks2) {
        return aaks2.d;
    }

    public aakr a() {
        return new aakr(this);
    }

    public aaks a(int n) {
        return this.a((CharSequence)this.a.getResources().getString(n));
    }

    public aaks a(CharSequence charSequence) {
        this.e = charSequence;
        return this;
    }

    public /* varargs */ aaks a(String ... arrstring) {
        this.d = hie.a((Object[])arrstring);
        return this;
    }

    public aakr b() {
        aakr aakr2 = this.a();
        aakr2.a();
        return aakr2;
    }
}

