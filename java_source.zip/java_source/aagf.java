/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  awdv
 *  awec
 *  axss
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  esc
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;

public final class aagf
implements awdv<CobrandCardClient<apap>> {
    static final /* synthetic */ boolean a;
    private final aagc b;
    private final axss<esc<apap>> c;
    private final axss<CobrandCardDataTransactions<apap>> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aagf.class.desiredAssertionStatus();
        a = bl;
    }

    public aagf(aagc aagc2, axss<esc<apap>> axss2, axss<CobrandCardDataTransactions<apap>> axss3) {
        if (!a && aagc2 == null) {
            throw new AssertionError();
        }
        this.b = aagc2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<CobrandCardClient<apap>> a(aagc aagc2, axss<esc<apap>> axss2, axss<CobrandCardDataTransactions<apap>> axss3) {
        return new aagf(aagc2, axss2, axss3);
    }

    public CobrandCardClient<apap> a() {
        return (CobrandCardClient)awec.a(this.b.a((esc)this.c.get(), (CobrandCardDataTransactions)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

