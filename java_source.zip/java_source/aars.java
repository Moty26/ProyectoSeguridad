/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  com.uber.rib.core.RibActivity
 */
import com.uber.rib.core.RibActivity;

class aars
implements axss<RibActivity> {
    private final aaqy a;

    aars(aaqy aaqy2) {
        this.a = aaqy2;
    }

    public RibActivity a() {
        return (RibActivity)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

