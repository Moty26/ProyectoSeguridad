/*
 * Decompiled with CFR 0_119.
 */
public class aamf {
    private final boolean a;
    private final boolean b;
    private final boolean c;

    public aamf(boolean bl, boolean bl2, boolean bl3) {
        this.a = bl;
        this.b = bl2;
        this.c = bl3;
    }

    public boolean a() {
        return this.a;
    }

    public boolean b() {
        return this.b;
    }

    public boolean c() {
        return this.c;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) return false;
        if (this.getClass() != object.getClass()) {
            return false;
        }
        object = (aamf)object;
        if (this.a != object.a) {
            return false;
        }
        if (this.b != object.b) {
            return false;
        }
        if (this.c == object.c) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int hashCode() {
        int n = 1;
        int n2 = this.a ? 1 : 0;
        int n3 = this.b ? 1 : 0;
        if (this.c) {
            return (n3 + n2 * 31) * 31 + n;
        }
        n = 0;
        return (n3 + n2 * 31) * 31 + n;
    }

    public String toString() {
        return String.format("hasLegalConsent: %s, hasDeferredLegalConsent: %s, hasFeatureConsent: %s", this.a, this.b, this.c);
    }
}

