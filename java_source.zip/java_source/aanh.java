/*
 * Decompiled with CFR 0_119.
 */
public enum aanh {
    a,
    b,
    c,
    d;
    

    private aanh() {
    }
}

