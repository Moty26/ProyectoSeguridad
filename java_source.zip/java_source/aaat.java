/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awec
 *  axss
 *  zye
 */
import android.content.Context;

class aaat
implements axss<Context> {
    private final zye a;

    aaat(zye zye2) {
        this.a = zye2;
    }

    public Context a() {
        return (Context)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

