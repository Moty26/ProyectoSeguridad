/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  atvd
 *  awdv
 *  awec
 *  axss
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.consent.primer.PrimerView
 */
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.consent.primer.PrimerView;

public final class aano
implements awdv<aanv> {
    static final /* synthetic */ boolean a;
    private final axss<aank> b;
    private final axss<PrimerView> c;
    private final axss<aanr> d;
    private final axss<RibActivity> e;
    private final axss<atvd> f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aano.class.desiredAssertionStatus();
        a = bl;
    }

    public aano(axss<aank> axss2, axss<PrimerView> axss3, axss<aanr> axss4, axss<RibActivity> axss5, axss<atvd> axss6) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
    }

    public static awdv<aanv> a(axss<aank> axss2, axss<PrimerView> axss3, axss<aanr> axss4, axss<RibActivity> axss5, axss<atvd> axss6) {
        return new aano(axss2, axss3, axss4, axss5, axss6);
    }

    public aanv a() {
        return (aanv)((Object)awec.a((Object)((Object)aanm.a((aank)this.b.get(), (PrimerView)this.c.get(), (aanr)((Object)this.d.get()), (RibActivity)this.e.get(), (atvd)this.f.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

