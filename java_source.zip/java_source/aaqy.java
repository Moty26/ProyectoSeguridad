/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  hpz
 */
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public interface aaqy {
    public RibActivity f();

    public ContactPickerCustomization g();

    public aari h();

    public hpz l();

    public hlg t();
}

