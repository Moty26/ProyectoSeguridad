/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aane
implements axss<aans> {
    private final aann a;

    aane(aann aann2) {
        this.a = aann2;
    }

    public aans a() {
        return (aans)awec.a((Object)this.a.d(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

