/*
 * Decompiled with CFR 0_119.
 */
interface aaga {
    public aagp a();
}

