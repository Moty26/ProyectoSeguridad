/*
 * Decompiled with CFR 0_119.
 */
public abstract class aak {
    public abstract abn a();
}

