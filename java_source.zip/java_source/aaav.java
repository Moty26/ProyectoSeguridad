/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  zql
 *  zye
 */
class aaav
implements axss<zql> {
    private final zye a;

    aaav(zye zye2) {
        this.a = zye2;
    }

    public zql a() {
        return (zql)awec.a((Object)this.a.j(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

