/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  aspo
 *  awlj
 *  awln
 *  awlq
 *  awnl
 *  com.ubercab.presidio.contacts.model.Contact
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  eih
 *  hie
 *  hig
 *  hih
 *  hik
 *  hiu
 */
import android.content.Context;
import com.ubercab.presidio.contacts.model.Contact;
import com.ubercab.presidio.contacts.model.ContactDetail;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

public class aarx {
    protected boolean a = true;
    protected final awlq b;
    protected final eih<String> c = eih.a();
    private final aaqd d;
    private final eih<hik<String>> e = eih.a();

    public aarx(aaqd aaqd2, awlq awlq2) {
        this.b = awlq2;
        this.d = aaqd2;
    }

    private boolean a(Contact contact, String string) {
        if (aspo.a((String)string)) {
            return true;
        }
        string = string.toLowerCase(Locale.US).trim();
        if (contact.displayName().toLowerCase(Locale.US).contains(string)) {
            return true;
        }
        contact = contact.details().a();
        while (contact.hasNext()) {
            if (!((ContactDetail)contact.next()).value().toLowerCase(Locale.US).contains(string)) continue;
            return true;
        }
        return false;
    }

    protected aary a(Map<String, Contact> object, hik<String> hik2, String string) {
        hih hih2 = new hih();
        for (Map.Entry entry : object.entrySet()) {
            Contact contact = (Contact)entry.getValue();
            if (!this.a(contact, string)) continue;
            hih2.a(entry.getKey(), (Object)contact);
        }
        return new aary((Map<String, Contact>)hih2.a(), hik2, string, this.a);
    }

    public awlj<aary> a(Context context, aaqf aaqf2) {
        return awlj.combineLatest(this.b(context, aaqf2), (awln)this.e.startWith((Object)hik.b()), (awln)this.c.startWith((Object)""), (awnl)new awnl<Map<String, Contact>, hik<String>, String, aary>(){

            public aary a(Map<String, Contact> map, hik<String> hik2, String string) throws Exception {
                return aarx.this.a(map, hik2, string);
            }
        }).subscribeOn(this.b);
    }

    public void a(String string) {
        this.c.a((Object)string);
    }

    public void a(Collection<String> collection) {
        this.a = false;
        this.e.a((Object)hik.a(collection));
    }

    protected awlj<Map<String, Contact>> b(final Context context, final aaqf aaqf2) {
        return awlj.fromCallable((Callable)new Callable<Map<String, Contact>>(){

            public Map<String, Contact> a() throws Exception {
                return aarx.this.d.a(context, aaqf2);
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        }).subscribeOn(this.b);
    }

}

