/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  axss
 *  com.uber.rib.core.RibActivity
 *  fbz
 *  hpz
 */
import com.uber.rib.core.RibActivity;

public final class aacc
implements awdv<aaca> {
    static final /* synthetic */ boolean a;
    private final axss<hpz> b;
    private final axss<RibActivity> c;
    private final axss<aabw> d;
    private final axss<fbz> e;
    private final axss<aacj> f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aacc.class.desiredAssertionStatus();
        a = bl;
    }

    public aacc(axss<hpz> axss2, axss<RibActivity> axss3, axss<aabw> axss4, axss<fbz> axss5, axss<aacj> axss6) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
        if (!a && axss6 == null) {
            throw new AssertionError();
        }
        this.f = axss6;
    }

    public static awdv<aaca> a(axss<hpz> axss2, axss<RibActivity> axss3, axss<aabw> axss4, axss<fbz> axss5, axss<aacj> axss6) {
        return new aacc(axss2, axss3, axss4, axss5, axss6);
    }

    public aaca a() {
        return new aaca(this.b, this.c, this.d, this.e, this.f);
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

