/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auhz
 *  awlv
 */
public interface aamb {
    public awlv<aamf> a(aalu var1);

    public awlv<auhz> a(aalu var1, aamd var2);

    public awlv<auhz> b(aalu var1, aamd var2);
}

