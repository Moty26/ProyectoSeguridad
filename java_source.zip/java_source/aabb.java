/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  ewf
 */
public final class aabb
implements awdv<ewf> {
    static final /* synthetic */ boolean a;
    private final aaay b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aabb.class.desiredAssertionStatus();
        a = bl;
    }

    public aabb(aaay aaay2) {
        if (!a && aaay2 == null) {
            throw new AssertionError();
        }
        this.b = aaay2;
    }

    public static awdv<ewf> a(aaay aaay2) {
        return new aabb(aaay2);
    }

    public ewf a() {
        return (ewf)awec.a((Object)this.b.a(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

