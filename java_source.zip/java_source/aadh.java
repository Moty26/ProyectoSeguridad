/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior
 *  com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior$1
 *  rw
 */
import android.view.View;
import com.ubercab.presidio.behaviors.core.ExpandingBottomSheetBehavior;

public class aadh
implements Runnable {
    final /* synthetic */ ExpandingBottomSheetBehavior a;
    private final View b;
    private final int c;
    private boolean d;

    private aadh(ExpandingBottomSheetBehavior expandingBottomSheetBehavior, View view, int n) {
        this.a = expandingBottomSheetBehavior;
        this.d = true;
        this.b = view;
        this.c = n;
    }

    public /* synthetic */ aadh(ExpandingBottomSheetBehavior expandingBottomSheetBehavior, View view, int n, ExpandingBottomSheetBehavior.1 var4_4) {
        this(expandingBottomSheetBehavior, view, n);
    }

    public void a() {
        this.d = false;
    }

    @Override
    public void run() {
        if (!this.d) {
            return;
        }
        if (ExpandingBottomSheetBehavior.access$700((ExpandingBottomSheetBehavior)this.a) != null && ExpandingBottomSheetBehavior.access$700((ExpandingBottomSheetBehavior)this.a).continueSettling(true)) {
            rw.a((View)this.b, (Runnable)this);
            return;
        }
        if (this.c == 6) {
            ExpandingBottomSheetBehavior.access$800((ExpandingBottomSheetBehavior)this.a, (View)this.b);
        }
        ExpandingBottomSheetBehavior.access$900((ExpandingBottomSheetBehavior)this.a, (int)this.c);
    }
}

