/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  axss
 */
public final class aaqc
implements awdv<aaqb> {
    static final /* synthetic */ boolean a;
    private final axss<aaqh> b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaqc.class.desiredAssertionStatus();
        a = bl;
    }

    public aaqc(axss<aaqh> axss2) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
    }

    public static awdv<aaqb> a(axss<aaqh> axss2) {
        return new aaqc(axss2);
    }

    public aaqb a() {
        return new aaqb((aaqh)this.b.get());
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

