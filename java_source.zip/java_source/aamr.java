/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.android.util.ArraySet
 *  eqr
 *  hja
 */
import com.ubercab.android.util.ArraySet;
import java.lang.reflect.Type;

@eqs(a="feature-consent")
enum aamr implements eqr
{
    a(hja.a(ArraySet.class, (Type[])new Type[]{String.class}));
    
    private Type b;

    private aamr(Type type) {
        this.b = type;
    }

    public Type a() {
        return this.b;
    }
}

