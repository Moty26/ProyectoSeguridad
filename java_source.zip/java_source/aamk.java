/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  com.uber.rib.core.RibActivity
 */
import com.uber.rib.core.RibActivity;

class aamk
implements axss<RibActivity> {
    private final aamc a;

    aamk(aamc aamc2) {
        this.a = aamc2;
    }

    public RibActivity a() {
        return (RibActivity)awec.a((Object)this.a.a(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

