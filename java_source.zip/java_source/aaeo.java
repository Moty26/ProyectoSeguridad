/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afw
 *  android.support.v7.widget.RecyclerView
 *  auhz
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView$1
 */
import android.support.v7.widget.RecyclerView;
import com.ubercab.presidio.cards.core.card.CardsRecyclerView;

class aaeo
extends afw {
    final /* synthetic */ aaen a;
    private int b;

    private aaeo(aaen aaen2) {
        this.a = aaen2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(RecyclerView recyclerView, int n) {
        if (n != 0) return;
        {
            if (this.b < 0) {
                aaen.a(this.a).a((Object)auhz.a);
                return;
            } else {
                if (this.b <= 0) return;
                {
                    aaen.b(this.a).a((Object)auhz.a);
                    return;
                }
            }
        }
    }

    public void a(RecyclerView recyclerView, int n, int n2) {
        this.b = n2;
    }
}

