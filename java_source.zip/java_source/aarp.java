/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 */
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

class aarp
implements axss<ContactPickerCustomization> {
    private final aaqy a;

    aarp(aaqy aaqy2) {
        this.a = aaqy2;
    }

    public ContactPickerCustomization a() {
        return (ContactPickerCustomization)awec.a((Object)this.a.g(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

