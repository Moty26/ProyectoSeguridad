/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apaq
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  ewc
 *  ewj
 *  ewq
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public final class aajh
implements aaiu {
    static final /* synthetic */ boolean a;
    private axss<aajq> b;
    private axss<aagq> c;
    private axss<aajd> d;
    private axss<apaq> e;
    private awdr<aajb> f;
    private axss<aaiu> g;
    private axss<eyq> h;
    private axss<aajf> i;
    private axss<abua> j;
    private axss<OfferResponse> k;
    private axss<ewc> l;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aajh.class.desiredAssertionStatus();
        a = bl;
    }

    private aajh(aaji aaji2) {
        if (!a && aaji2 == null) {
            throw new AssertionError();
        }
        this.a(aaji2);
    }

    private void a(aaji aaji2) {
        this.b = awdu.a(aaiy.a(aaji.a(aaji2)));
        this.c = new aajk(aaji.b(aaji2));
        this.d = awdu.a(aaiz.a(aaji.a(aaji2), this.b, this.c));
        this.e = new aajm(aaji.b(aaji2));
        this.f = aajc.a(this.d, this.c, this.e);
        this.g = awdw.a((Object)this);
        this.h = new aajn(aaji.b(aaji2));
        this.i = awdu.a(aaja.a(aaji.a(aaji2), this.g, this.h));
        this.j = awdu.a(aaix.a(aaji.a(aaji2)));
        this.k = new aajl(aaji.b(aaji2));
        this.l = new aajj(aaji.b(aaji2));
    }

    public static aaji g() {
        return new aaji(null);
    }

    public /* synthetic */ ewq O_() {
        return this.h();
    }

    @Override
    public aagq a() {
        return (aagq)this.c.get();
    }

    public void a(aajb aajb2) {
        this.f.a((Object)aajb2);
    }

    @Override
    public eyq b() {
        return (eyq)this.h.get();
    }

    @Override
    public abua c() {
        return (abua)this.j.get();
    }

    @Override
    public OfferResponse d() {
        return (OfferResponse)this.k.get();
    }

    @Override
    public ewc e() {
        return (ewc)this.l.get();
    }

    @Override
    public aajf f() {
        return (aajf)((Object)this.i.get());
    }

    public aajd h() {
        return (aajd)this.d.get();
    }

}

