/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  com.uber.rib.core.RibActivity
 */
import com.uber.rib.core.RibActivity;

class aand
implements axss<RibActivity> {
    private final aann a;

    aand(aann aann2) {
        this.a = aann2;
    }

    public RibActivity a() {
        return (RibActivity)awec.a((Object)this.a.f(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

