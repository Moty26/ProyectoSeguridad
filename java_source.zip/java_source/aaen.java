/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afw
 *  auhz
 *  awlj
 *  awnk
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView
 *  com.ubercab.presidio.cards.core.card.CardsRecyclerView$1
 *  ega
 *  eih
 */
import com.ubercab.presidio.cards.core.card.CardsRecyclerView;

public class aaen
implements aaeq {
    final /* synthetic */ CardsRecyclerView a;
    private final eih<auhz> b;
    private final eih<auhz> c;

    private aaen(CardsRecyclerView cardsRecyclerView) {
        this.a = cardsRecyclerView;
        this.b = eih.a();
        this.c = eih.a();
        cardsRecyclerView.a((afw)new aaeo(this, null));
    }

    public /* synthetic */ aaen(CardsRecyclerView cardsRecyclerView, CardsRecyclerView.1 var2_2) {
        this(cardsRecyclerView);
    }

    static /* synthetic */ eih a(aaen aaen2) {
        return aaen2.b;
    }

    static /* synthetic */ eih b(aaen aaen2) {
        return aaen2.c;
    }

    @Override
    public awlj<auhz> a() {
        return this.b.hide();
    }

    @Override
    public awlj<auhz> b() {
        return this.c.hide();
    }

    @Override
    public awlj<ega> c() {
        return this.a.J();
    }

    @Override
    public awlj<aaer> d() {
        return this.a.J().map((awnk)new awnk<ega, aaer>(){

            public aaer a(ega ega2) throws Exception {
                return aaer.a(ega2.b(), ega2.c());
            }
        });
    }

}

