/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  awdr
 *  awdu
 *  awdv
 *  awea
 *  awlq
 *  axss
 *  com.uber.rib.core.RibActivity
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  ejv
 *  ewj
 *  ewq
 *  hpz
 */
import android.content.res.Resources;
import android.view.LayoutInflater;
import com.uber.rib.core.RibActivity;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public final class aarm
implements aaqw {
    static final /* synthetic */ boolean a;
    private axss<ContactPickerCustomization> b;
    private axss<LayoutInflater> c;
    private axss<aaqg> d;
    private axss<ejv> e;
    private axss<aart> f;
    private axss<aark> g;
    private axss<aaqh> h;
    private axss<hpz> i;
    private axss j;
    private axss<aaqd> k;
    private axss<awlq> l;
    private axss<aarx> m;
    private axss<aasf> n;
    private axss<Resources> o;
    private axss<aase> p;
    private axss<aari> q;
    private axss<hlg> r;
    private axss<RibActivity> s;
    private awdr<aarh> t;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aarm.class.desiredAssertionStatus();
        a = bl;
    }

    private aarm(aarn aarn2) {
        if (!a && aarn2 == null) {
            throw new AssertionError();
        }
        this.a(aarn2);
    }

    public static aarn a() {
        return new aarn(null);
    }

    private void a(aarn aarn2) {
        this.b = new aarp(aarn.a(aarn2));
        this.c = aard.a(aarn.b(aarn2));
        this.d = awdu.a(aaqz.a(aarn.b(aarn2), this.b));
        this.e = aare.a(aarn.b(aarn2));
        this.f = aaru.a(awea.a(), this.c, this.d, this.e);
        this.g = awdu.a(aarb.a(aarn.b(aarn2), this.b, this.f));
        this.h = awdu.a(aara.a(aarn.b(aarn2), this.b));
        this.i = new aaro(aarn.a(aarn2));
        this.j = aaqc.a(this.h);
        this.k = aaqe.a(this.i, this.j, this.h);
        this.l = aarg.a(aarn.b(aarn2));
        this.m = aarz.a(this.k, this.l);
        this.n = aarc.a(aarn.b(aarn2));
        this.o = aarf.a(aarn.b(aarn2));
        this.p = aasg.a(this.b, this.n, this.o);
        this.q = new aarq(aarn.a(aarn2));
        this.r = new aarr(aarn.a(aarn2));
        this.s = new aars(aarn.a(aarn2));
        this.t = aarj.a(this.g, this.h, this.b, this.m, this.p, this.q, this.r, this.s);
    }

    public /* synthetic */ ewq O_() {
        return this.b();
    }

    public void a(aarh aarh2) {
        this.t.a((Object)aarh2);
    }

    public aark b() {
        return (aark)((Object)this.g.get());
    }

}

