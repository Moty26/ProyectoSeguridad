/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  ewj
 *  ewo
 */
public final class aaig
implements awdr<aaif> {
    static final /* synthetic */ boolean a;
    private final axss<aaih> b;
    private final axss<aagq> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaig.class.desiredAssertionStatus();
        a = bl;
    }

    public aaig(axss<aaih> axss2, axss<aagq> axss3) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
    }

    public static awdr<aaif> a(axss<aaih> axss2, axss<aagq> axss3) {
        return new aaig(axss2, axss3);
    }

    public void a(aaif aaif2) {
        if (aaif2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aaif2, this.b);
        aaif2.a = (aaih)this.b.get();
        aaif2.b = (aagq)this.c.get();
    }
}

