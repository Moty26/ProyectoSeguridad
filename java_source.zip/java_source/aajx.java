/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public final class aajx
implements awdv<aakb> {
    static final /* synthetic */ boolean a;
    private final aajv b;
    private final axss<OfferResponse> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aajx.class.desiredAssertionStatus();
        a = bl;
    }

    public aajx(aajv aajv2, axss<OfferResponse> axss2) {
        if (!a && aajv2 == null) {
            throw new AssertionError();
        }
        this.b = aajv2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
    }

    public static awdv<aakb> a(aajv aajv2, axss<OfferResponse> axss2) {
        return new aajx(aajv2, axss2);
    }

    public aakb a() {
        return (aakb)awec.a((Object)this.b.a((OfferResponse)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

