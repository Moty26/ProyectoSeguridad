/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  atvd
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.rib.core.RibActivity
 *  ewf
 *  ewj
 *  eyq
 *  fbz
 *  lms
 */
import android.view.ViewGroup;
import com.uber.rib.core.RibActivity;

public final class aami
implements aaln {
    static final /* synthetic */ boolean a;
    private axss<ewf> b;
    private axss<aalu> c;
    private axss<aamb> d;
    private axss<ViewGroup> e;
    private axss<aalz> f;
    private axss<RibActivity> g;
    private axss<lms> h;
    private axss<fbz> i;
    private axss<aalj> j;
    private awdr<aalx> k;
    private axss<aaln> l;
    private axss<aalx> m;
    private axss<eyq> n;
    private axss<aame> o;
    private axss<aans> p;
    private axss<atvd> q;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aami.class.desiredAssertionStatus();
        a = bl;
    }

    private aami(aamj aamj2) {
        if (!a && aamj2 == null) {
            throw new AssertionError();
        }
        this.a(aamj2);
    }

    private void a(aamj aamj2) {
        this.b = awdu.a(aals.b());
        this.c = awdw.a((Object)aamj.a(aamj2));
        this.d = awdw.a((Object)aamj.b(aamj2));
        this.e = awdw.a((Object)aamj.c(aamj2));
        this.f = new aaml(aamj.d(aamj2));
        this.g = new aamk(aamj.d(aamj2));
        this.h = new aamo(aamj.d(aamj2));
        this.i = new aamm(aamj.d(aamj2));
        this.j = awdu.a(aalq.a(this.g, this.i));
        this.k = aama.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.j);
        this.l = awdw.a((Object)this);
        this.m = awdw.a((Object)aamj.e(aamj2));
        this.n = new aamp(aamj.d(aamj2));
        this.o = awdu.a(aalt.a(this.l, this.m, this.e, this.n));
        this.p = awdu.a(aalr.a(this.m));
        this.q = new aamn(aamj.d(aamj2));
    }

    public static aalo b() {
        return new aamj(null);
    }

    @Override
    public aame a() {
        return (aame)((Object)this.o.get());
    }

    public void a(aalx aalx2) {
        this.k.a((Object)aalx2);
    }

    @Override
    public fbz c() {
        return (fbz)this.i.get();
    }

    @Override
    public aans d() {
        return (aans)this.p.get();
    }

    @Override
    public atvd e() {
        return (atvd)this.q.get();
    }

    @Override
    public RibActivity f() {
        return (RibActivity)this.g.get();
    }

}

