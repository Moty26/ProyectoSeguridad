/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  auhz
 *  auif
 *  avxl
 *  avyy
 *  avyz
 *  avze
 *  awlj
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView
 *  com.ubercab.presidio.cobrandcard.application.personalinfo.DropDownLikeEditTextField
 *  com.ubercab.presidio.payment.base.ui.util.ClickableFloatingLabelEditText
 *  com.ubercab.ui.FloatingLabelEditText
 *  com.ubercab.ui.core.UButton
 *  eih
 *  eot
 *  eov
 *  eox
 *  exl
 *  gsq
 *  llg
 *  llw
 */
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.ubercab.presidio.cobrandcard.application.financial.CobrandCardFinancialInfoView;
import com.ubercab.presidio.cobrandcard.application.personalinfo.DropDownLikeEditTextField;
import com.ubercab.presidio.payment.base.ui.util.ClickableFloatingLabelEditText;
import com.ubercab.ui.FloatingLabelEditText;
import com.ubercab.ui.core.UButton;
import java.util.List;

public class aaih
extends exl<CobrandCardFinancialInfoView>
implements aail {
    public static final String[] a = new String[]{"Professional", "Self Employed", "Student", "Government", "Service/Retail", "Homemaker", "Skilled Trade", "Unemployed", "Other"};
    private final aaik b;
    private final aaii c;
    private final aagq d;
    private eih<Boolean> e;

    public aaih(CobrandCardFinancialInfoView cobrandCardFinancialInfoView, aaii aaii2, aaik aaik2, aagq aagq2) {
        super((View)cobrandCardFinancialInfoView);
        this.d = aagq2;
        ((CobrandCardFinancialInfoView)this.i()).a((aail)this);
        this.b = aaik2;
        this.c = aaii2;
    }

    private void b() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::PEqM7SmtsGHRNuY95Y1gVABEk+5h5QxN0pVTC0yssGI=", -3295476322921135584L, -523244936299521340L, 7917008305137517131L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 96);
        }
        this.l();
        this.m();
        this.k();
        this.j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::i3QjaNV65HYUV0vC0SkK6dvvl8JzBoeFfeFfwCZgdfU=", -3295476322921135584L, -523244936299521340L, -5370545716216592912L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 104);
        }
        ((eov)this.d.c().observeOn(awmh.a()).to((awnk)new eot((eox)this))).a((awlp)new auif<aagt>(){

            public void a(aagt aagt2) throws Exception {
                ((CobrandCardFinancialInfoView)aaih.this.i()).b().d((CharSequence)aagt2.a());
                ((CobrandCardFinancialInfoView)aaih.this.i()).c().d((CharSequence)aagt2.b());
                ((CobrandCardFinancialInfoView)aaih.this.i()).d().d((CharSequence)String.valueOf(aagt2.c()));
                ((CobrandCardFinancialInfoView)aaih.this.i()).e().b(aagt2.d());
                aaih.this.n();
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::oEOE4Eko1tJUUZjrbJkjEvx9XUN65qOLBVM9n5zm3aI=", -3295476322921135584L, -523244936299521340L, -7171068847808750571L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 121) : null;
        Drawable drawable = avxl.a((Context)((CobrandCardFinancialInfoView)this.i()).getContext(), (int)aafu.ub__cobrandcard_help_icon, (int)aaft.ub__ui_core_brand_grey_80);
        ((CobrandCardFinancialInfoView)this.i()).b().a(null, drawable);
        ((CobrandCardFinancialInfoView)this.i()).c().a(null, drawable);
        ((CobrandCardFinancialInfoView)this.i()).d().a(null, drawable);
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void l() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::r6Ns3C+EqMzl+lFIp66fFTIXYDEqwpJ2ZDb2jW4H5MA=", -3295476322921135584L, -523244936299521340L, 125490928547692315L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 134) : null;
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_application_validation_required)), (FloatingLabelEditText)((CobrandCardFinancialInfoView)this.i()).b(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_application_validation_required)), (FloatingLabelEditText)((CobrandCardFinancialInfoView)this.i()).c(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_application_validation_required)), (FloatingLabelEditText)((CobrandCardFinancialInfoView)this.i()).d(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avze((Object)new avyy(aafx.cobrandcard_application_validation_required)), ((CobrandCardFinancialInfoView)this.i()).e().b(), true);
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::KbrII09E6NuGH6JQ+mBqkbRQ6hE0x9aVkyjwtJDe2EU=", -3295476322921135584L, -523244936299521340L, 8727261037778022271L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 157);
        }
        this.e = eih.b((Object)false);
        ((eov)this.e.to((awnk)new eot((eox)this))).a((awlp)new auif<Boolean>(){

            public void a(Boolean bl) throws Exception {
                ((CobrandCardFinancialInfoView)aaih.this.i()).a(bl);
            }
        });
        ((eov)((CobrandCardFinancialInfoView)this.i()).b().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aaih.this.n();
            }
        });
        ((eov)((CobrandCardFinancialInfoView)this.i()).c().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aaih.this.n();
            }
        });
        ((eov)((CobrandCardFinancialInfoView)this.i()).d().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aaih.this.n();
            }
        });
        ((eov)((CobrandCardFinancialInfoView)this.i()).e().b().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aaih.this.n();
            }
        });
        ((eov)((CobrandCardFinancialInfoView)this.i()).g().i().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void a(auhz object) throws Exception {
                int n;
                object = null;
                try {
                    n = Integer.parseInt(((CobrandCardFinancialInfoView)aaih.this.i()).d().e().toString());
                }
                catch (NumberFormatException numberFormatException) {
                    kly.d(numberFormatException, "Unexpected income format exception.", new Object[0]);
                }
                object = n;
                if (aaih.this.b.a().isEmpty() && object != null) {
                    gsq.b((Context)((CobrandCardFinancialInfoView)aaih.this.i()).getContext(), (View)aaih.this.i());
                    aaih.this.c.a(((CobrandCardFinancialInfoView)aaih.this.i()).b().e().toString(), ((CobrandCardFinancialInfoView)aaih.this.i()).c().e().toString(), object.intValue(), ((CobrandCardFinancialInfoView)aaih.this.i()).e().b().e().toString());
                }
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void n() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::Xb1prVOKAitqEVSeADgD/1iTzqeVhAxv97RyJcd7iOZJ1Qj0MFpfhwmAxqniIemh", -3295476322921135584L, -523244936299521340L, -5383437497431032144L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 233);
        }
        eih<Boolean> eih2 = this.e;
        boolean bl = this.b.b().size() == 0;
        eih2.a((Object)bl);
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::MMhgc7LPW8Nb5PWShcQW0wx2ml+HKR/9lzak6n4A1g8msSoA8vkB4etPEsYWR/um", -3295476322921135584L, -523244936299521340L, -3258551959409342833L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 238);
        }
        ((eov)aakr.a(((CobrandCardFinancialInfoView)this.i()).getContext()).a(a).a(aafx.cobrandcard_done).b().b().to((awnk)new eot((eox)this))).a((awlp)new auif<String>(){

            public void a(String string) throws Exception {
                ((CobrandCardFinancialInfoView)aaih.this.i()).a(string);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::mHjNXpidAhZ1UI8Bj9wOhNESYLsWWaNS+Ga0pIiMDWk=", -3295476322921135584L, -523244936299521340L, 8792004404122595672L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 80);
        }
        super.f();
        ((eov)((CobrandCardFinancialInfoView)this.i()).f().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) throws Exception {
                aaih.this.c.d();
            }
        });
        this.b();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void g() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmWf9CIKm4A3SwNKYbizocGr8vW+Hq6agueXROgkdzoqKajAdqPi2eCj5cbntkm9FZy04A/sF4KwMRA7Ao4sD33", "enc::LIu0KBS4aHqYF90tspXATwkCV1XhZpU1szXsfmGftnU=", -3295476322921135584L, -523244936299521340L, -5669698541601424854L, 1953763409102406465L, null, "enc::atEfgvPYLktmgAD18YGYTe/+KR277WkGTfDxjKYHrDtEQtqP752Lp+pNsyDKl8+e", 74) : null;
        super.g();
        ((CobrandCardFinancialInfoView)this.i()).a(null);
        if (llw2 != null) {
            llw2.i();
        }
    }

}

