/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  ewj
 *  ewo
 *  fbz
 */
public final class aapv
implements awdr<aapt> {
    static final /* synthetic */ boolean a;
    private final axss<aapw> b;
    private final axss<aapu> c;
    private final axss<aaob> d;
    private final axss<fbz> e;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aapv.class.desiredAssertionStatus();
        a = bl;
    }

    public aapv(axss<aapw> axss2, axss<aapu> axss3, axss<aaob> axss4, axss<fbz> axss5) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
        if (!a && axss5 == null) {
            throw new AssertionError();
        }
        this.e = axss5;
    }

    public static awdr<aapt> a(axss<aapw> axss2, axss<aapu> axss3, axss<aaob> axss4, axss<fbz> axss5) {
        return new aapv(axss2, axss3, axss4, axss5);
    }

    public void a(aapt aapt2) {
        if (aapt2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a((ewj)aapt2, this.b);
        aapt2.a = (aapw)((Object)this.b.get());
        aapt2.b = (aapu)this.c.get();
        aapt2.c = (aaob)this.d.get();
        aapt2.d = (fbz)this.e.get();
    }
}

