/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.TypedArray
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.SubMenu
 *  android.view.View
 *  qs
 *  rf
 *  yx
 */
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import java.lang.reflect.Constructor;

class aaf {
    private String A;
    private String B;
    private CharSequence C;
    private CharSequence D;
    private ColorStateList E;
    private PorterDuff.Mode F;
    qs a;
    final /* synthetic */ aad b;
    private Menu c;
    private int d;
    private int e;
    private int f;
    private int g;
    private boolean h;
    private boolean i;
    private boolean j;
    private int k;
    private int l;
    private CharSequence m;
    private CharSequence n;
    private int o;
    private char p;
    private int q;
    private char r;
    private int s;
    private int t;
    private boolean u;
    private boolean v;
    private boolean w;
    private int x;
    private int y;
    private String z;

    public aaf(aad aad2, Menu menu) {
        this.b = aad2;
        this.E = null;
        this.F = null;
        this.c = menu;
        this.a();
    }

    private char a(String string) {
        if (string == null) {
            return '\u0000';
        }
        return string.charAt(0);
    }

    private <T> T a(String string, Class<?>[] object, Object[] arrobject) {
        try {
            object = this.b.e.getClassLoader().loadClass(string).getConstructor(object);
            object.setAccessible(true);
            object = object.newInstance(arrobject);
        }
        catch (Exception exception) {
            Log.w((String)"SupportMenuInflater", (String)("Cannot instantiate class: " + string), (Throwable)exception);
            return null;
        }
        return (T)object;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(MenuItem menuItem) {
        boolean bl = true;
        Object object = menuItem.setChecked(this.u).setVisible(this.v).setEnabled(this.w);
        boolean bl2 = this.t >= 1;
        object.setCheckable(bl2).setTitleCondensed(this.n).setIcon(this.o);
        if (this.x >= 0) {
            menuItem.setShowAsAction(this.x);
        }
        if (this.B != null) {
            if (this.b.e.isRestricted()) {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
            menuItem.setOnMenuItemClickListener((MenuItem.OnMenuItemClickListener)new aae(this.b.a(), this.B));
        }
        if (menuItem instanceof aax) {
            object = (aax)menuItem;
        }
        if (this.t >= 2) {
            if (menuItem instanceof aax) {
                ((aax)menuItem).a(true);
            } else if (menuItem instanceof aay) {
                ((aay)menuItem).a(true);
            }
        }
        if (this.z != null) {
            menuItem.setActionView((View)this.a(this.z, aad.a, this.b.c));
        } else {
            bl = false;
        }
        if (this.y > 0) {
            if (!bl) {
                menuItem.setActionView(this.y);
            } else {
                Log.w((String)"SupportMenuInflater", (String)"Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            }
        }
        if (this.a != null) {
            rf.a((MenuItem)menuItem, (qs)this.a);
        }
        rf.a((MenuItem)menuItem, (CharSequence)this.C);
        rf.b((MenuItem)menuItem, (CharSequence)this.D);
        rf.b((MenuItem)menuItem, (char)this.p, (int)this.q);
        rf.a((MenuItem)menuItem, (char)this.r, (int)this.s);
        if (this.F != null) {
            rf.a((MenuItem)menuItem, (PorterDuff.Mode)this.F);
        }
        if (this.E != null) {
            rf.a((MenuItem)menuItem, (ColorStateList)this.E);
        }
    }

    public void a() {
        this.d = 0;
        this.e = 0;
        this.f = 0;
        this.g = 0;
        this.h = true;
        this.i = true;
    }

    public void a(AttributeSet attributeSet) {
        attributeSet = this.b.e.obtainStyledAttributes(attributeSet, yx.MenuGroup);
        this.d = attributeSet.getResourceId(yx.MenuGroup_android_id, 0);
        this.e = attributeSet.getInt(yx.MenuGroup_android_menuCategory, 0);
        this.f = attributeSet.getInt(yx.MenuGroup_android_orderInCategory, 0);
        this.g = attributeSet.getInt(yx.MenuGroup_android_checkableBehavior, 0);
        this.h = attributeSet.getBoolean(yx.MenuGroup_android_visible, true);
        this.i = attributeSet.getBoolean(yx.MenuGroup_android_enabled, true);
        attributeSet.recycle();
    }

    public void b() {
        this.j = true;
        this.a(this.c.add(this.d, this.k, this.l, this.m));
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(AttributeSet attributeSet) {
        int n;
        int n2 = 1;
        attributeSet = this.b.e.obtainStyledAttributes(attributeSet, yx.MenuItem);
        this.k = attributeSet.getResourceId(yx.MenuItem_android_id, 0);
        this.l = attributeSet.getInt(yx.MenuItem_android_menuCategory, this.e) & -65536 | attributeSet.getInt(yx.MenuItem_android_orderInCategory, this.f) & 65535;
        this.m = attributeSet.getText(yx.MenuItem_android_title);
        this.n = attributeSet.getText(yx.MenuItem_android_titleCondensed);
        this.o = attributeSet.getResourceId(yx.MenuItem_android_icon, 0);
        this.p = this.a(attributeSet.getString(yx.MenuItem_android_alphabeticShortcut));
        this.q = attributeSet.getInt(yx.MenuItem_alphabeticModifiers, 4096);
        this.r = this.a(attributeSet.getString(yx.MenuItem_android_numericShortcut));
        this.s = attributeSet.getInt(yx.MenuItem_numericModifiers, 4096);
        if (attributeSet.hasValue(yx.MenuItem_android_checkable)) {
            n = attributeSet.getBoolean(yx.MenuItem_android_checkable, false) ? 1 : 0;
            this.t = n;
        } else {
            this.t = this.g;
        }
        this.u = attributeSet.getBoolean(yx.MenuItem_android_checked, false);
        this.v = attributeSet.getBoolean(yx.MenuItem_android_visible, this.h);
        this.w = attributeSet.getBoolean(yx.MenuItem_android_enabled, this.i);
        this.x = attributeSet.getInt(yx.MenuItem_showAsAction, -1);
        this.B = attributeSet.getString(yx.MenuItem_android_onClick);
        this.y = attributeSet.getResourceId(yx.MenuItem_actionLayout, 0);
        this.z = attributeSet.getString(yx.MenuItem_actionViewClass);
        this.A = attributeSet.getString(yx.MenuItem_actionProviderClass);
        n = this.A != null ? n2 : 0;
        if (n != 0 && this.y == 0 && this.z == null) {
            this.a = (qs)this.a(this.A, aad.b, this.b.d);
        } else {
            if (n != 0) {
                Log.w((String)"SupportMenuInflater", (String)"Ignoring attribute 'actionProviderClass'. Action view already specified.");
            }
            this.a = null;
        }
        this.C = attributeSet.getText(yx.MenuItem_contentDescription);
        this.D = attributeSet.getText(yx.MenuItem_tooltipText);
        this.F = attributeSet.hasValue(yx.MenuItem_iconTintMode) ? adw.a(attributeSet.getInt(yx.MenuItem_iconTintMode, -1), this.F) : null;
        this.E = attributeSet.hasValue(yx.MenuItem_iconTint) ? attributeSet.getColorStateList(yx.MenuItem_iconTint) : null;
        attributeSet.recycle();
        this.j = false;
    }

    public SubMenu c() {
        this.j = true;
        SubMenu subMenu = this.c.addSubMenu(this.d, this.k, this.l, this.m);
        this.a(subMenu.getItem());
        return subMenu;
    }

    public boolean d() {
        return this.j;
    }
}

