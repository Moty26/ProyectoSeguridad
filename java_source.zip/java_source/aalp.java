/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.view.ViewGroup
 *  com.uber.rib.core.RibActivity
 *  ewf
 *  eyq
 *  fbz
 */
import android.app.Application;
import android.view.ViewGroup;
import com.uber.rib.core.RibActivity;

public abstract class aalp {
    static aalj a(RibActivity ribActivity, fbz fbz2) {
        return new aalj(ribActivity.getApplication().getPackageName(), fbz2);
    }

    static aame a(aaln aaln2, aalx aalx2, ViewGroup viewGroup, eyq eyq2) {
        return new aame(aalx2, aaln2, viewGroup, new aani(aaln2), eyq2);
    }

    static aans a(aalx aalx2) {
        return aalx2;
    }

    static ewf a() {
        return new ewf();
    }
}

