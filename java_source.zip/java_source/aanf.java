/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  fbz
 */
class aanf
implements axss<fbz> {
    private final aann a;

    aanf(aann aann2) {
        this.a = aann2;
    }

    public fbz a() {
        return (fbz)awec.a((Object)this.a.c(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

