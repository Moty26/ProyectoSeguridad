/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService
 */
import com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService;

public final class aacq
implements awdr<GeofenceTransitionsIntentService> {
    static final /* synthetic */ boolean a;
    private final axss<aaco> b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aacq.class.desiredAssertionStatus();
        a = bl;
    }

    public aacq(axss<aaco> axss2) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
    }

    public static awdr<GeofenceTransitionsIntentService> a(axss<aaco> axss2) {
        return new aacq(axss2);
    }

    public void a(GeofenceTransitionsIntentService geofenceTransitionsIntentService) {
        if (geofenceTransitionsIntentService == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        geofenceTransitionsIntentService.a = (aaco)this.b.get();
    }
}

