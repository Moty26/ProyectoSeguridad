/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  eyq
 */
public final class aaja
implements awdv<aajf> {
    static final /* synthetic */ boolean a;
    private final aaiv b;
    private final axss<aaiu> c;
    private final axss<eyq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaja.class.desiredAssertionStatus();
        a = bl;
    }

    public aaja(aaiv aaiv2, axss<aaiu> axss2, axss<eyq> axss3) {
        if (!a && aaiv2 == null) {
            throw new AssertionError();
        }
        this.b = aaiv2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aajf> a(aaiv aaiv2, axss<aaiu> axss2, axss<eyq> axss3) {
        return new aaja(aaiv2, axss2, axss3);
    }

    public aajf a() {
        return (aajf)((Object)awec.a((Object)((Object)this.b.a((aaiu)this.c.get(), (eyq)this.d.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

