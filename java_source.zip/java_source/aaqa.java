/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.util.Patterns
 *  com.ubercab.presidio.contacts.model.ContactDetail
 *  gss
 */
import android.util.Patterns;
import com.ubercab.presidio.contacts.model.ContactDetail;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class aaqa
implements aaqf {
    private String a;

    public aaqa(String string) {
        this.a = string;
    }

    @Override
    public int a() {
        return aaqs.ub__contact_picker_v2_search_hint_all_contacts;
    }

    @Override
    public int a(aary aary2) {
        return aaqs.ub__contact_picker_search_query_add;
    }

    @Override
    public boolean a(ContactDetail contactDetail) {
        return this.a(contactDetail.value());
    }

    @Override
    public boolean a(String string) {
        if (gss.f((String)string, (String)this.a) || Patterns.EMAIL_ADDRESS.matcher(string).matches()) {
            return true;
        }
        return false;
    }

    @Override
    public String b(String string) {
        String string2 = string;
        if (gss.f((String)string, (String)this.a)) {
            string2 = gss.b((String)string, (String)this.a);
        }
        return string2;
    }
}

