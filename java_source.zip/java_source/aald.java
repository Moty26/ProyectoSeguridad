/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  alws
 *  alww
 *  alxc
 *  axss
 *  eqc
 *  exn
 *  hpz
 *  iro
 */
public class aald
implements alws<alww, exn> {
    private final axss<hpz> a;
    private final axss<aakv> b;
    private final axss<aakx> c;
    private final axss<eqc> d;

    public aald(axss<hpz> axss2, axss<aakv> axss3, axss<aakx> axss4, axss<eqc> axss5) {
        this.a = axss2;
        this.b = axss3;
        this.c = axss4;
        this.d = axss5;
    }

    public alxc a() {
        return iro.Q;
    }

    public exn a(alww alww2) {
        return new aalc((aakv)this.b.get(), (aakx)this.c.get(), (eqc)this.d.get());
    }

    public /* synthetic */ boolean a(Object object) {
        return this.b((alww)object);
    }

    public /* synthetic */ Object b(Object object) {
        return this.a((alww)object);
    }

    public String b() {
        return "6d7c1f81-96ec-4ed8-a48c-2eb2a7de7cfe";
    }

    public boolean b(alww alww2) {
        return aaky.a((hpz)this.a.get());
    }
}

