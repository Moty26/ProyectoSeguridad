/*
 * Decompiled with CFR 0_119.
 */
interface aago {
    public void d();

    public void f();
}

