/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aaci {
    private aacn a;

    private aaci() {
    }

    static /* synthetic */ aacn a(aaci aaci2) {
        return aaci2.a;
    }

    public aaci a(aacn aacn2) {
        this.a = (aacn)awec.a((Object)aacn2);
        return this;
    }

    public aacl a() {
        if (this.a == null) {
            throw new IllegalStateException(aacn.class.getCanonicalName() + " must be set");
        }
        return new aach(this);
    }
}

