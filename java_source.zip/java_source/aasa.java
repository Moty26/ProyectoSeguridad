/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awlj
 *  awlq
 *  com.ubercab.presidio.contacts.model.Contact
 *  eih
 *  hik
 *  lms
 */
import android.content.Context;
import com.ubercab.presidio.contacts.model.Contact;
import java.util.Collections;
import java.util.Map;

public class aasa
extends aarx {
    private final eih<hik<Contact>> d = eih.a();
    private final lms e;

    public aasa(aaqd aaqd2, awlq awlq2, lms lms2) {
        super(aaqd2, awlq2);
        this.e = lms2;
    }

    @Override
    protected awlj<Map<String, Contact>> b(Context context, aaqf aaqf2) {
        if (!this.e.a(context, "android.permission.READ_CONTACTS")) {
            return awlj.just(Collections.emptyMap());
        }
        return super.b(context, aaqf2);
    }
}

