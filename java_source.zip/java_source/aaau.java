/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  axug
 *  zye
 */
class aaau
implements axss<axug> {
    private final zye a;

    aaau(zye zye2) {
        this.a = zye2;
    }

    public axug a() {
        return (axug)awec.a((Object)this.a.i(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

