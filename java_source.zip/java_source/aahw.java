/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  avyy
 *  avyz
 *  com.ubercab.ui.FloatingLabelEditText
 */
import android.text.TextUtils;
import com.ubercab.ui.FloatingLabelEditText;

public class aahw
implements avyz<FloatingLabelEditText, avyy> {
    private final avyy a;
    private final int b;

    public aahw(int n, avyy avyy2) {
        this.a = avyy2;
        this.b = n;
    }

    public avyy a(FloatingLabelEditText object) {
        if (!TextUtils.isEmpty((CharSequence)(object = object.e())) && object.length() > this.b) {
            return this.a;
        }
        return null;
    }
}

