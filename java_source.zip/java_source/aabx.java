/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
import android.content.Context;

interface aabx {
    public String a(Context var1, String var2);
}

