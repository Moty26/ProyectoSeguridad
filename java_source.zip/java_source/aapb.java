/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  awlj
 *  axss
 *  com.ubercab.presidio.contact_driver.model.ContactDriverData
 */
import com.ubercab.presidio.contact_driver.model.ContactDriverData;

class aapb
implements axss<awlj<ContactDriverData>> {
    private final aaow a;

    aapb(aaow aaow2) {
        this.a = aaow2;
    }

    public awlj<ContactDriverData> a() {
        return (awlj)awec.a(this.a.e(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

