/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agq
 *  android.annotation.SuppressLint
 *  android.view.View
 */
import android.annotation.SuppressLint;
import android.view.View;

@SuppressLint(value={"PotentialRibletLeak"})
public abstract class aael<Router extends aaek, CardModel>
extends agq {
    private final Router n;

    public aael(Router Router) {
        super(Router.h());
        this.n = Router;
    }

    public Router A() {
        return this.n;
    }
}

