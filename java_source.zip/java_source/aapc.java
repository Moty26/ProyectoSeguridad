/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 */
class aapc
implements axss<aaot> {
    private final aaow a;

    aapc(aaow aaow2) {
        this.a = aaow2;
    }

    public aaot a() {
        return (aaot)awec.a((Object)this.a.d(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

