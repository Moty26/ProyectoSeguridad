/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlj
 *  axsa
 */
public class aagq {
    private final axsa<aags> a = axsa.a();
    private final axsa<aagr> b = axsa.a();
    private final axsa<aagt> c = axsa.a();

    public awlj<aagr> a() {
        return this.b.hide();
    }

    public void a(aagr aagr2) {
        this.b.onNext((Object)aagr2);
    }

    public void a(aags aags2) {
        this.a.onNext((Object)aags2);
    }

    public void a(aagt aagt2) {
        this.c.onNext((Object)aagt2);
    }

    public awlj<aags> b() {
        return this.a.hide();
    }

    public awlj<aagt> c() {
        return this.c.hide();
    }
}

