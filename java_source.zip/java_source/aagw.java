/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aagw {
    private aagc a;
    private aagd b;

    private aagw() {
    }

    static /* synthetic */ aagc a(aagw aagw2) {
        return aagw2.a;
    }

    static /* synthetic */ aagd b(aagw aagw2) {
        return aagw2.b;
    }

    public aagb a() {
        if (this.a == null) {
            throw new IllegalStateException(aagc.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aagd.class.getCanonicalName() + " must be set");
        }
        return new aagv(this);
    }

    public aagw a(aagc aagc2) {
        this.a = (aagc)((Object)awec.a((Object)((Object)aagc2)));
        return this;
    }

    public aagw a(aagd aagd2) {
        this.b = (aagd)awec.a((Object)aagd2);
        return this;
    }
}

