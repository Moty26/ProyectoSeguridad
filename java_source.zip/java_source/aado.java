/*
 * Decompiled with CFR 0_119.
 */
public interface aado {
    public int a();
}

