/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.text.format.DateUtils
 *  android.view.View
 *  android.widget.DatePicker
 *  auhz
 *  auif
 *  avxl
 *  avyy
 *  avyz
 *  avzd
 *  avzf
 *  awlj
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  com.ubercab.presidio.cobrandcard.application.personalinfo.CobrandCardPersonalInfoView
 *  com.ubercab.presidio.cobrandcard.application.personalinfo.DropDownLikeEditTextField
 *  com.ubercab.presidio.countrypicker.core.model.Country
 *  com.ubercab.presidio.payment.base.ui.util.ClickableFloatingLabelEditText
 *  com.ubercab.ui.FloatingLabelEditText
 *  com.ubercab.ui.core.UButton
 *  eih
 *  eot
 *  eov
 *  eox
 *  exl
 *  gsq
 *  hor
 *  llg
 *  llw
 */
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.DatePicker;
import com.ubercab.presidio.cobrandcard.application.personalinfo.CobrandCardPersonalInfoView;
import com.ubercab.presidio.cobrandcard.application.personalinfo.DropDownLikeEditTextField;
import com.ubercab.presidio.countrypicker.core.model.Country;
import com.ubercab.presidio.payment.base.ui.util.ClickableFloatingLabelEditText;
import com.ubercab.ui.FloatingLabelEditText;
import com.ubercab.ui.core.UButton;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class aajd
extends exl<CobrandCardPersonalInfoView>
implements aajg {
    private DatePickerDialog a;
    private final aajq b;
    private final aagq c;
    private final aaje d;
    private final aajp e;
    private eih<Boolean> f;
    private Country g;
    private Long h;

    public aajd(CobrandCardPersonalInfoView cobrandCardPersonalInfoView, aaje aaje2, aajq aajq2, aagq aagq2) {
        super((View)cobrandCardPersonalInfoView);
        this.c = aagq2;
        ((CobrandCardPersonalInfoView)this.i()).a((aajg)this);
        this.b = aajq2;
        this.d = aaje2;
        this.e = new aajp(18, new avyy((CharSequence)((CobrandCardPersonalInfoView)this.i()).getResources().getString(aafx.cobrandcard_personal_validation_minimumBirthDate, new Object[]{18})));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(Country country) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::oBsHW3YppMFkB16syt69Q48ChJHHpbd3GRnyI2QHtJbJHc0lnunsiv8N243c30R07LJuvnPlCsMEhI+RIxl45O5P8qwyrndeN95ypEEkJjBwcEI1gZaWlbmUuMz6IEC0", -874676037324681323L, 2016499818736231241L, -8037276484149047604L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 281) : null;
        DropDownLikeEditTextField dropDownLikeEditTextField = ((CobrandCardPersonalInfoView)this.i()).g();
        Object object = abum.a(country, dropDownLikeEditTextField.getResources());
        if (object != null) {
            dropDownLikeEditTextField.a((Drawable)object);
        }
        object = avxl.a((Resources)((CobrandCardPersonalInfoView)this.i()).getContext().getResources());
        object = country != null ? abum.a(country, (Locale)object) : null;
        dropDownLikeEditTextField.b((String)object);
        this.g = country;
        this.n();
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::i3QjaNV65HYUV0vC0SkK6dvvl8JzBoeFfeFfwCZgdfU=", -874676037324681323L, 2016499818736231241L, -5370545716216592912L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 97);
        }
        ((eov)this.c.b().observeOn(awmh.a()).to((awnk)new eot((eox)this))).a((awlp)new auif<aags>(){

            public void a(aags aags2) throws Exception {
                ((CobrandCardPersonalInfoView)aajd.this.i()).b().d((CharSequence)aags2.a());
                ((CobrandCardPersonalInfoView)aajd.this.i()).c().d((CharSequence)aags2.b());
                ((CobrandCardPersonalInfoView)aajd.this.i()).d().d((CharSequence)aags2.c());
                ((CobrandCardPersonalInfoView)aajd.this.i()).e().d((CharSequence)aags2.d());
                aajd.this.a(aags2.e());
                aajd.this.b(aags2.f());
                aajd.this.n();
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void k() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::oEOE4Eko1tJUUZjrbJkjEvx9XUN65qOLBVM9n5zm3aI=", -874676037324681323L, 2016499818736231241L, -7171068847808750571L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 116) : null;
        Drawable drawable = avxl.a((Context)((CobrandCardPersonalInfoView)this.i()).getContext(), (int)aafu.ub__cobrandcard_help_icon, (int)aaft.ub__ui_core_brand_grey_80);
        ((CobrandCardPersonalInfoView)this.i()).d().a(null, drawable);
        ((CobrandCardPersonalInfoView)this.i()).e().a(null, drawable);
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void l() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::r6Ns3C+EqMzl+lFIp66fFTIXYDEqwpJ2ZDb2jW4H5MA=", -874676037324681323L, 2016499818736231241L, 125490928547692315L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 127) : null;
        Object object = ((CobrandCardPersonalInfoView)this.i()).getResources();
        String string = object.getString(aafx.cobrandcard_personal_validation_minimumNameLength, new Object[]{2});
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avzf(2, (Object)new avyy((CharSequence)string)), (FloatingLabelEditText)((CobrandCardPersonalInfoView)this.i()).b(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avzf(2, (Object)new avyy((CharSequence)string)), (FloatingLabelEditText)((CobrandCardPersonalInfoView)this.i()).c(), true);
        object = object.getString(aafx.cobrandcard_personal_validation_maximumFullNameLength, new Object[]{31});
        this.b.a(new aajr(31.0f, (FloatingLabelEditText)((CobrandCardPersonalInfoView)this.i()).b(), new avyy((CharSequence)object)), (FloatingLabelEditText)((CobrandCardPersonalInfoView)this.i()).c(), true);
        object = new avyy(aafx.cobrandcard_personal_validation_emailIsValid);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avzd(object, object), (FloatingLabelEditText)((CobrandCardPersonalInfoView)this.i()).d(), true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avzf(1, (Object)new avyy(aafx.cobrandcard_personal_validation_country_required)), ((CobrandCardPersonalInfoView)this.i()).g().a, true);
        this.b.a((avyz<FloatingLabelEditText, avyy>)new avzf(1, (Object)new avyy(aafx.cobrandcard_personal_validation_birthDate_required)), ((CobrandCardPersonalInfoView)this.i()).f().a, true);
        this.b.a(this.e, ((CobrandCardPersonalInfoView)this.i()).f().a, true);
        if (llw2 != null) {
            llw2.i();
        }
    }

    private void m() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::KbrII09E6NuGH6JQ+mBqkbRQ6hE0x9aVkyjwtJDe2EU=", -874676037324681323L, 2016499818736231241L, 8727261037778022271L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 164);
        }
        this.f = eih.b((Object)false);
        ((eov)this.f.to((awnk)new eot((eox)this))).a((awlp)new auif<Boolean>(){

            public void a(Boolean bl) throws Exception {
                ((CobrandCardPersonalInfoView)aajd.this.i()).a(bl);
            }
        });
        ((eov)((CobrandCardPersonalInfoView)this.i()).b().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aajd.this.n();
            }
        });
        ((eov)((CobrandCardPersonalInfoView)this.i()).c().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aajd.this.n();
            }
        });
        ((eov)((CobrandCardPersonalInfoView)this.i()).d().c().to((awnk)new eot((eox)this))).a((awlp)new auif<CharSequence>(){

            public void a(CharSequence charSequence) throws Exception {
                aajd.this.n();
            }
        });
        ((eov)((CobrandCardPersonalInfoView)this.i()).h().i().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz object) throws Exception {
                if (aajd.this.b.a().isEmpty()) {
                    object = new aags(((CobrandCardPersonalInfoView)aajd.this.i()).b().e().toString(), ((CobrandCardPersonalInfoView)aajd.this.i()).c().e().toString(), ((CobrandCardPersonalInfoView)aajd.this.i()).d().e().toString(), ((CobrandCardPersonalInfoView)aajd.this.i()).e().e().toString(), aajd.this.h, aajd.this.g);
                    aajd.this.c.a((aags)object);
                    gsq.b((Context)((CobrandCardPersonalInfoView)aajd.this.i()).getContext(), (View)aajd.this.i());
                    aajd.this.d.e();
                }
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void n() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::Xb1prVOKAitqEVSeADgD/1iTzqeVhAxv97RyJcd7iOZJ1Qj0MFpfhwmAxqniIemh", -874676037324681323L, 2016499818736231241L, -5383437497431032144L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 238);
        }
        eih<Boolean> eih2 = this.f;
        boolean bl = this.b.b().size() == 0;
        eih2.a((Object)bl);
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void a() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::HBi3A9ZMWzitblkYUUyfE7bSiSynQGvmH1OeLvIuxG0=", -874676037324681323L, 2016499818736231241L, 8202113491547885506L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 229);
        }
        gsq.b((Context)((CobrandCardPersonalInfoView)this.i()).getContext(), (View)this.i());
        this.d.d();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void a(Country country) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::QcsDcs0r1cK4k6btuMJD82NMgGtR4moJ5h7eCPM/TO+Wg4P/DBMtOiYoO+X7DXNkRiZ9ti/96XBXNw2UEN4eSKIiNBVttkXw+K5evX67Fw/2eBG6yq9QqJ3L9c2ucKT3", -874676037324681323L, 2016499818736231241L, -8980903819998128658L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 234);
        }
        this.b(country);
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void a(Long l) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::d2L1UHq4LjhOcrUSXjTzBxv2DE0Y36S0D+LfZl7KUsdEXM3wFpHW/9MEXxEXRGoW", -874676037324681323L, 2016499818736231241L, 4217168143644884050L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 268) : null;
        String string = l != null ? DateUtils.formatDateTime((Context)((CobrandCardPersonalInfoView)this.i()).getContext(), (long)l, (int)20) : null;
        ((CobrandCardPersonalInfoView)this.i()).a(string);
        this.h = l;
        this.e.a(this.h);
        this.n();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void b() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::a92iQcDJkwMzwNmRoVpkjxchXDeDItRZpWErZjZHapFGTYgpBbbO1Fi6vmEugKVd", -874676037324681323L, 2016499818736231241L, 8548501491176641304L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 243);
        }
        if (this.a == null) {
            Calendar calendar = Calendar.getInstance();
            this.a = new DatePickerDialog(((CobrandCardPersonalInfoView)this.i()).getContext(), aafy.Platform_Dialog, new DatePickerDialog.OnDateSetListener(){

                public void onDateSet(DatePicker object, int n, int n2, int n3) {
                    object = Calendar.getInstance();
                    object.set(5, n3);
                    object.set(2, n2);
                    object.set(1, n);
                    aajd.this.a(object.getTimeInMillis());
                }
            }, calendar.get(1), calendar.get(2), calendar.get(5));
            this.a.getDatePicker().setMaxDate(new Date().getTime());
        }
        hor.a((Dialog)this.a);
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::mHjNXpidAhZ1UI8Bj9wOhNESYLsWWaNS+Ga0pIiMDWk=", -874676037324681323L, 2016499818736231241L, 8792004404122595672L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 88);
        }
        super.f();
        this.l();
        this.m();
        this.k();
        this.j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void g() {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wiZvpvmH/m/uwF7rUiMaSEe", "enc::LIu0KBS4aHqYF90tspXATwkCV1XhZpU1szXsfmGftnU=", -874676037324681323L, 2016499818736231241L, -5669698541601424854L, 1953763409102406465L, null, "enc::GGnQ/DmzriVCDvUcUBgL3e/ZGKlXLfABb2n9Icc53oFRLcxFbvU2kYZ0KSYDA8FE", 82) : null;
        super.g();
        ((CobrandCardPersonalInfoView)this.i()).a(null);
        if (llw2 != null) {
            llw2.i();
        }
    }

}

