/*
 * Decompiled with CFR 0_119.
 */
public final class aafr {
}

