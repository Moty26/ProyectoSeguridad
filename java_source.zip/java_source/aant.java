/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auhz
 *  awlc
 *  awlj
 */
public interface aant {
    public awlj<auhz> a();

    public void a(aanp var1);

    public void a(boolean var1);

    public awlj<auhz> b();

    public awlj<auhz> c();

    public awlj<auhz> d();

    public void e();

    public void h();

    public awlc<auhz> i();
}

