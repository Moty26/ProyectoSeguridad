/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.ubercab.presidio.contact_driver.edit_number.EditNumberView
 *  ewj
 *  ewk
 */
import android.view.View;
import com.ubercab.presidio.contact_driver.edit_number.EditNumberView;

public class aapq
extends ewk<aapt, EditNumberView> {
    public aapq(aapt aapt2, EditNumberView editNumberView) {
        super((ewj)aapt2, (View)editNumberView);
    }

    aapw a() {
        return new aapw((EditNumberView)this.c(), (aapx)this.d());
    }
}

