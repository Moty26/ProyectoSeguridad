/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewParent
 *  bx
 *  com.ubercab.presidio.behaviors.core.LegacyExpandingBottomSheetBehavior
 *  hqg
 */
import android.view.View;
import android.view.ViewParent;
import com.ubercab.presidio.behaviors.core.LegacyExpandingBottomSheetBehavior;
import java.util.Iterator;

public class aadm
extends bx {
    final /* synthetic */ LegacyExpandingBottomSheetBehavior a;
    private boolean b;
    private boolean c;

    public aadm(LegacyExpandingBottomSheetBehavior legacyExpandingBottomSheetBehavior) {
        this.a = legacyExpandingBottomSheetBehavior;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(View view, float f) {
        if (LegacyExpandingBottomSheetBehavior.access$500((LegacyExpandingBottomSheetBehavior)this.a) && view.getParent() != null) {
            float f2 = ((View)view.getParent()).getHeight();
            f = f2 - (float)this.a.peekHeight;
            float f3 = f2 - (float)LegacyExpandingBottomSheetBehavior.access$800((LegacyExpandingBottomSheetBehavior)this.a);
            f2 -= (float)LegacyExpandingBottomSheetBehavior.access$900((LegacyExpandingBottomSheetBehavior)this.a);
            int n = view.getTop();
            float f4 = this.a.currentSlideoffset;
            if ((float)n == f) {
                this.a.currentSlideoffset = 0.0f;
            } else if ((float)n < f && (float)n > f3) {
                this.a.currentSlideoffset = (f - (float)n) / (f - f3);
            } else if ((float)n == f3) {
                this.a.currentSlideoffset = 1.0f;
            } else if ((float)n == f2) {
                this.a.currentSlideoffset = 2.0f;
            } else if ((float)n < f3) {
                this.a.currentSlideoffset = (f3 - (float)n) / (f3 - f2) + 1.0f;
            }
            boolean bl = f4 > this.a.currentSlideoffset;
            this.b = bl;
            bl = f4 < this.a.currentSlideoffset;
            this.c = bl;
            if ((LegacyExpandingBottomSheetBehavior.access$600((LegacyExpandingBottomSheetBehavior)this.a) == 2 || LegacyExpandingBottomSheetBehavior.access$600((LegacyExpandingBottomSheetBehavior)this.a) == 1) && (this.a.currentSlideoffset < 0.95f || LegacyExpandingBottomSheetBehavior.access$1000((LegacyExpandingBottomSheetBehavior)this.a) != null && LegacyExpandingBottomSheetBehavior.access$1000((LegacyExpandingBottomSheetBehavior)this.a).a((hqg)aada.SUPPORT_26_FIXES) && (double)this.a.currentSlideoffset <= LegacyExpandingBottomSheetBehavior.access$1000((LegacyExpandingBottomSheetBehavior)this.a).a((hqg)aada.SUPPORT_26_FIXES, "slideOffset", 0.949999988079071))) {
                LegacyExpandingBottomSheetBehavior.access$000((LegacyExpandingBottomSheetBehavior)this.a, (int)0);
            } else if (LegacyExpandingBottomSheetBehavior.access$1000((LegacyExpandingBottomSheetBehavior)this.a) != null && LegacyExpandingBottomSheetBehavior.access$1000((LegacyExpandingBottomSheetBehavior)this.a).a((hqg)aada.SUPPORT_26_FIXES) && LegacyExpandingBottomSheetBehavior.access$600((LegacyExpandingBottomSheetBehavior)this.a) == 0 && (double)this.a.currentSlideoffset > LegacyExpandingBottomSheetBehavior.access$1000((LegacyExpandingBottomSheetBehavior)this.a).a((hqg)aada.SUPPORT_26_FIXES, "slideOffset", 0.949999988079071) && this.c) {
                LegacyExpandingBottomSheetBehavior.access$000((LegacyExpandingBottomSheetBehavior)this.a, (int)1);
            }
        } else {
            this.a.currentSlideoffset = f;
        }
        LegacyExpandingBottomSheetBehavior.access$1100((LegacyExpandingBottomSheetBehavior)this.a).onNext((Object)Float.valueOf(this.a.currentSlideoffset));
        Iterator iterator = LegacyExpandingBottomSheetBehavior.access$700((LegacyExpandingBottomSheetBehavior)this.a).iterator();
        while (iterator.hasNext()) {
            ((bx)iterator.next()).a(view, this.a.currentSlideoffset);
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(View view, int n) {
        if (LegacyExpandingBottomSheetBehavior.access$500((LegacyExpandingBottomSheetBehavior)this.a)) {
            if (4 == n && LegacyExpandingBottomSheetBehavior.access$600((LegacyExpandingBottomSheetBehavior)this.a) == 2) {
                LegacyExpandingBottomSheetBehavior.access$000((LegacyExpandingBottomSheetBehavior)this.a, (int)1);
            } else if (3 == n && LegacyExpandingBottomSheetBehavior.access$600((LegacyExpandingBottomSheetBehavior)this.a) == 0 && !this.b) {
                LegacyExpandingBottomSheetBehavior.access$000((LegacyExpandingBottomSheetBehavior)this.a, (int)1);
            } else if (3 == n && this.a.currentSlideoffset > 1.0f && this.c) {
                LegacyExpandingBottomSheetBehavior.access$000((LegacyExpandingBottomSheetBehavior)this.a, (int)2);
            }
        }
        Iterator iterator = LegacyExpandingBottomSheetBehavior.access$700((LegacyExpandingBottomSheetBehavior)this.a).iterator();
        while (iterator.hasNext()) {
            ((bx)iterator.next()).a(view, n);
        }
        return;
    }
}

