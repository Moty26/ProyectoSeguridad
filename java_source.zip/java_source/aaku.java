/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState
 *  eqr
 */
import com.uber.model.core.generated.rtapi.models.commute.CommuteOptInState;
import java.lang.reflect.Type;

@eqs(a="commute")
public enum aaku implements eqr
{
    a(CommuteOptInState.class);
    
    private final Class b;

    private <T> aaku(Class<T> class_) {
        this.b = class_;
    }

    public Type a() {
        return this.b;
    }
}

