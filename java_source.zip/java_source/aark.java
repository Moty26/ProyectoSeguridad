/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afg
 *  afp
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  avvd
 *  avxl
 *  com.ubercab.presidio.contacts.dropdown.ContactsDropDownView
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 *  com.ubercab.ui.core.URecyclerView
 *  exl
 *  hie
 *  llg
 *  llw
 */
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.ubercab.presidio.contacts.dropdown.ContactsDropDownView;
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;
import com.ubercab.ui.core.URecyclerView;
import java.util.Collection;

public class aark
extends exl<ContactsDropDownView> {
    private final aart a;
    private final ContactPickerCustomization b;

    aark(ContactPickerCustomization contactPickerCustomization, ContactsDropDownView contactsDropDownView, aart aart2) {
        super((View)contactsDropDownView);
        this.a = aart2;
        this.b = contactPickerCustomization;
        ((ContactsDropDownView)this.i()).b().a((afg)aart2);
        ((ContactsDropDownView)this.i()).b().a(this.a(((ContactsDropDownView)this.i()).getContext()));
    }

    private afp a(Context context) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgg65z4Ahf9SHMBOWv6MRBpDN6WbSYYckv4SDtH+h81A4=", "enc::EY1xcCskNqPxcFs+4y6Iri5c3TCOPoMxksnilaVTNFkszP2m19cGqerzM7GBlmG/YYFhKAq8SinuB953qNp+LnxZ+2DoeMlxYTfZmZt+OpdZaiRxYWfWvQuGauC7Y1pCVKUDJPNpTPLOovLsJ/E4vrIZgMqJ4BUSeIcgpx+nQ2I=", 2819679059983535793L, -9067021762764853300L, 7778606905084403072L, 1953763409102406465L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQYpCCME5BufK37IrGUILOww=", 44);
        }
        context = new avvd(avxl.a((Context)context, (int)aaqp.divider_horizontal_light), 0);
        if (llw2 != null) {
            llw2.i();
        }
        return context;
    }

    void a(hie<aatb> hie2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKvJ2xFTSZaym4c41ZJoXOSAfcCnWmiaESNk6lLHZhOtgg65z4Ahf9SHMBOWv6MRBpDN6WbSYYckv4SDtH+h81A4=", "enc::DWDaF060yc+OGdwJrdRrAFkXxz46E66x7X6xI6R8cLYeMXdTzf+1Jw3Dw5LBkRHk9Z4cY0rTR5s6J4BU3c5e6g==", 2819679059983535793L, -9067021762764853300L, -1697682672963208146L, 1953763409102406465L, null, "enc::EeD8Y/QeIsGuzOnqAAwpQYpCCME5BufK37IrGUILOww=", 40);
        }
        this.a.a((Collection<aatb>)hie2);
        if (llw2 != null) {
            llw2.i();
        }
    }
}

