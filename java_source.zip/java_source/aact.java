/*
 * Decompiled with CFR 0_119.
 */
public abstract class aact {
    public abstract aacs a();
}

