/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.InflateException
 *  android.view.MenuItem
 *  android.view.MenuItem$OnMenuItemClickListener
 */
import android.view.InflateException;
import android.view.MenuItem;
import java.lang.reflect.Method;

class aae
implements MenuItem.OnMenuItemClickListener {
    private static final Class<?>[] a = new Class[]{MenuItem.class};
    private Object b;
    private Method c;

    public aae(Object object, String string) {
        this.b = object;
        Class class_ = object.getClass();
        try {
            this.c = class_.getMethod(string, a);
            return;
        }
        catch (Exception exception) {
            string = new InflateException("Couldn't resolve menu item onClick handler " + string + " in class " + class_.getName());
            string.initCause((Throwable)exception);
            throw string;
        }
    }

    public boolean onMenuItemClick(MenuItem menuItem) {
        try {
            if (this.c.getReturnType() == Boolean.TYPE) {
                return (Boolean)this.c.invoke(this.b, new Object[]{menuItem});
            }
            this.c.invoke(this.b, new Object[]{menuItem});
            return true;
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
}

