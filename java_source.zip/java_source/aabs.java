/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  artc
 *  awdv
 *  axss
 *  com.uber.rib.core.RibActivity
 *  hpz
 */
import com.uber.rib.core.RibActivity;

public final class aabs
implements awdv<aabr> {
    static final /* synthetic */ boolean a;
    private final axss<hpz> b;
    private final axss<artc> c;
    private final axss<RibActivity> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aabs.class.desiredAssertionStatus();
        a = bl;
    }

    public aabs(axss<hpz> axss2, axss<artc> axss3, axss<RibActivity> axss4) {
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.b = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.c = axss3;
        if (!a && axss4 == null) {
            throw new AssertionError();
        }
        this.d = axss4;
    }

    public static awdv<aabr> a(axss<hpz> axss2, axss<artc> axss3, axss<RibActivity> axss4) {
        return new aabs(axss2, axss3, axss4);
    }

    public aabr a() {
        return new aabr(this.b, this.c, this.d);
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

