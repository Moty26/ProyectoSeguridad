/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  awdu
 *  awdv
 *  awdw
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  ewc
 *  ewj
 *  ewq
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public final class aakf
implements aaju {
    static final /* synthetic */ boolean a;
    private axss<OfferResponse> b;
    private axss<aakb> c;
    private axss<aagq> d;
    private awdr<aajz> e;
    private axss<aaju> f;
    private axss<eyq> g;
    private axss<ewc> h;
    private axss<aakd> i;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aakf.class.desiredAssertionStatus();
        a = bl;
    }

    private aakf(aakg aakg2) {
        if (!a && aakg2 == null) {
            throw new AssertionError();
        }
        this.a(aakg2);
    }

    private void a(aakg aakg2) {
        this.b = new aakj(aakg.a(aakg2));
        this.c = awdu.a(aajx.a(aakg.b(aakg2), this.b));
        this.d = new aaki(aakg.a(aakg2));
        this.e = aaka.a(this.c, this.d);
        this.f = awdw.a((Object)this);
        this.g = new aakk(aakg.a(aakg2));
        this.h = new aakh(aakg.a(aakg2));
        this.i = awdu.a(aajy.a(aakg.b(aakg2), this.f, this.g, this.h));
    }

    public static aakg b() {
        return new aakg(null);
    }

    public /* synthetic */ ewq O_() {
        return this.d();
    }

    @Override
    public aakd a() {
        return (aakd)((Object)this.i.get());
    }

    public void a(aajz aajz2) {
        this.e.a((Object)aajz2);
    }

    public aakb d() {
        return (aakb)this.c.get();
    }

}

