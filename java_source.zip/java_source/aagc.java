/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  apap
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView
 *  esc
 *  ewj
 *  ewk
 *  eyq
 */
import android.view.View;
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;
import com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView;

public class aagc
extends ewk<aagl, CobrandCardApplicationView> {
    private final OfferResponse a;

    public aagc(aagl aagl2, CobrandCardApplicationView cobrandCardApplicationView, OfferResponse offerResponse) {
        super((ewj)aagl2, (View)cobrandCardApplicationView);
        this.a = offerResponse;
    }

    static CobrandCardDataTransactions<apap> g() {
        return new aakn(){};
    }

    aagn a() {
        return new aagn((CobrandCardApplicationView)this.c(), (aago)this.d());
    }

    aagp a(aagb aagb2, eyq eyq2) {
        return new aagp((CobrandCardApplicationView)this.c(), (aagl)this.d(), aagb2, eyq2, new aais(aagb2));
    }

    CobrandCardClient<apap> a(esc<apap> esc2, CobrandCardDataTransactions<apap> cobrandCardDataTransactions) {
        return new CobrandCardClient(esc2, cobrandCardDataTransactions);
    }

    aagq b() {
        return new aagq();
    }

    OfferResponse e() {
        if (this.a == null) {
            return ((aagl)this.d()).e();
        }
        return this.a;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    Boolean f() {
        boolean bl;
        if (this.a != null) {
            bl = true;
            do {
                return bl;
                break;
            } while (true);
        }
        bl = false;
        return bl;
    }

}

