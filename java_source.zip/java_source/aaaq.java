/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  zye
 */
public final class aaaq {
    private aaay a;
    private zye b;

    private aaaq() {
    }

    static /* synthetic */ aaay a(aaaq aaaq2) {
        return aaaq2.a;
    }

    static /* synthetic */ zye b(aaaq aaaq2) {
        return aaaq2.b;
    }

    public aaaq a(aaay aaay2) {
        this.a = (aaay)((Object)awec.a((Object)((Object)aaay2)));
        return this;
    }

    public aaaq a(zye zye2) {
        this.b = (zye)awec.a((Object)zye2);
        return this;
    }

    public aaax a() {
        if (this.a == null) {
            throw new IllegalStateException(aaay.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(zye.class.getCanonicalName() + " must be set");
        }
        return new aaap(this);
    }
}

