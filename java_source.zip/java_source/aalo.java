/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 */
import android.view.ViewGroup;

public interface aalo {
    public aaln a();

    public aalo a(aalu var1);

    public aalo a(aalx var1);

    public aalo a(aamb var1);

    public aalo a(aamc var1);

    public aalo a(ViewGroup var1);
}

