/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.widget.ListView
 */
import android.widget.ListView;

class aap {
    public final aey a;
    public final aat b;
    public final int c;

    public aap(aey aey2, aat aat2, int n) {
        this.a = aey2;
        this.b = aat2;
        this.c = n;
    }

    public ListView a() {
        return this.a.g();
    }
}

