/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  ejv
 */
public final class aare
implements awdv<ejv> {
    static final /* synthetic */ boolean a;
    private final aaqx b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aare.class.desiredAssertionStatus();
        a = bl;
    }

    public aare(aaqx aaqx2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
    }

    public static awdv<ejv> a(aaqx aaqx2) {
        return new aare(aaqx2);
    }

    public ejv a() {
        return (ejv)awec.a((Object)this.b.e(), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

