/*
 * Decompiled with CFR 0_119.
 */
public interface aajg {
    public void a();

    public void b();
}

