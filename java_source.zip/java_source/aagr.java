/*
 * Decompiled with CFR 0_119.
 */
public class aagr {
    private final String a;
    private final String b;
    private final String c;
    private final String d;
    private final String e;

    public aagr(String string, String string2, String string3, String string4, String string5) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public String c() {
        return this.c;
    }

    public String d() {
        return this.d;
    }

    public String e() {
        return this.e;
    }
}

