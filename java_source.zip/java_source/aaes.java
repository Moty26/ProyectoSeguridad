/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auhz
 *  awlj
 */
public interface aaes {
    public awlj<auhz> b();
}

