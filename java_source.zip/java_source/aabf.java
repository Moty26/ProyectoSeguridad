/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  axuc
 *  axun
 *  retrofit2.Converter
 */
import java.io.IOException;
import retrofit2.Converter;

class aabf
implements Converter<String, axun> {
    static final aabf a = new aabf();
    private static final axuc b = axuc.a((String)"application/x-www-form-urlencoded; charset=UTF-8");

    private aabf() {
    }

    public static Converter<String, axun> a() {
        return a;
    }

    public axun a(String string) throws IOException {
        return axun.create((axuc)b, (byte[])string.getBytes("UTF-8"));
    }

    public /* synthetic */ Object convert(Object object) throws IOException {
        return this.a((String)object);
    }
}

