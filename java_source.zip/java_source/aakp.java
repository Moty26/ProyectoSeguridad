/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  afg
 *  agi
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  auif
 *  awlj
 *  awlp
 *  com.ubercab.ui.core.UTextView
 *  egr
 *  eij
 *  hie
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.ui.core.UTextView;
import java.util.List;

public class aakp
extends afg<aakq> {
    private hie<String> a = hie.c();
    private eij<String> b = eij.a();

    public int a() {
        return this.a.size();
    }

    public aakq a(ViewGroup viewGroup, int n) {
        return new aakq((UTextView)LayoutInflater.from((Context)viewGroup.getContext()).inflate(aafw.ub__cobrandcard_picker_item, viewGroup, false));
    }

    public void a(aakq aakq2, int n) {
        final String string = (String)this.a.get(n);
        aakq2.n.setText((CharSequence)string);
        egr.c((View)aakq2.n).subscribe((awlp)new auif<Object>(){

            public void a(Object object) throws Exception {
                aakp.this.b.a((Object)string);
            }
        });
    }

    public void a(List<String> list) {
        this.a = hie.a(list);
        this.e();
    }

    public /* synthetic */ agi b(ViewGroup viewGroup, int n) {
        return this.a(viewGroup, n);
    }

    public awlj<String> b() {
        return this.b;
    }

}

