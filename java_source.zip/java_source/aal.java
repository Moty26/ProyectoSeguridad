/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewParent
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;

public abstract class aal
implements abh {
    protected Context a;
    protected Context b;
    protected aat c;
    protected LayoutInflater d;
    protected LayoutInflater e;
    protected abj f;
    private abi g;
    private int h;
    private int i;
    private int j;

    public aal(Context context, int n, int n2) {
        this.a = context;
        this.d = LayoutInflater.from((Context)context);
        this.h = n;
        this.i = n2;
    }

    public abj a(ViewGroup viewGroup) {
        if (this.f == null) {
            this.f = (abj)this.d.inflate(this.h, viewGroup, false);
            this.f.a(this.c);
            this.a(true);
        }
        return this.f;
    }

    /*
     * Enabled aggressive block sorting
     */
    public View a(aax aax2, View object, ViewGroup viewGroup) {
        object = object instanceof abk ? (abk)object : this.b(viewGroup);
        this.a(aax2, (abk)object);
        return (View)object;
    }

    public void a(int n) {
        this.j = n;
    }

    @Override
    public void a(aat aat2, boolean bl) {
        if (this.g != null) {
            this.g.a(aat2, bl);
        }
    }

    public abstract void a(aax var1, abk var2);

    @Override
    public void a(abi abi2) {
        this.g = abi2;
    }

    @Override
    public void a(Context context, aat aat2) {
        this.b = context;
        this.e = LayoutInflater.from((Context)this.b);
        this.c = aat2;
    }

    protected void a(View view, int n) {
        ViewGroup viewGroup = (ViewGroup)view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup)this.f).addView(view, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(boolean bl) {
        int n;
        ViewGroup viewGroup = (ViewGroup)this.f;
        if (viewGroup == null) {
            return;
        }
        if (this.c == null) {
            n = 0;
        } else {
            this.c.j();
            ArrayList<aax> arrayList = this.c.i();
            int n2 = arrayList.size();
            int n3 = 0;
            int n4 = 0;
            do {
                n = n4;
                if (n3 >= n2) break;
                aax aax2 = arrayList.get(n3);
                if (this.a(n4, aax2)) {
                    View view = viewGroup.getChildAt(n4);
                    aax aax3 = view instanceof abk ? ((abk)view).a() : null;
                    View view2 = this.a(aax2, view, viewGroup);
                    if (aax2 != aax3) {
                        view2.setPressed(false);
                        view2.jumpDrawablesToCurrentState();
                    }
                    if (view2 != view) {
                        this.a(view2, n4);
                    }
                    ++n4;
                }
                ++n3;
            } while (true);
        }
        while (n < viewGroup.getChildCount()) {
            if (this.a(viewGroup, n)) continue;
            ++n;
        }
    }

    @Override
    public boolean a() {
        return false;
    }

    public boolean a(int n, aax aax2) {
        return true;
    }

    @Override
    public boolean a(aat aat2, aax aax2) {
        return false;
    }

    @Override
    public boolean a(abp abp2) {
        if (this.g != null) {
            return this.g.a(abp2);
        }
        return false;
    }

    public boolean a(ViewGroup viewGroup, int n) {
        viewGroup.removeViewAt(n);
        return true;
    }

    @Override
    public int b() {
        return this.j;
    }

    public abk b(ViewGroup viewGroup) {
        return (abk)this.d.inflate(this.i, viewGroup, false);
    }

    @Override
    public boolean b(aat aat2, aax aax2) {
        return false;
    }

    public abi d() {
        return this.g;
    }
}

