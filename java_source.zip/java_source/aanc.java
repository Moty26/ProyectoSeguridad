/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  com.ubercab.presidio.consent.primer.PrimerView
 */
import com.ubercab.presidio.consent.primer.PrimerView;

final class aanc
implements aanl {
    private aann a;
    private aanr b;
    private PrimerView c;
    private aanp d;

    private aanc() {
    }

    static /* synthetic */ PrimerView a(aanc aanc2) {
        return aanc2.c;
    }

    static /* synthetic */ aanp b(aanc aanc2) {
        return aanc2.d;
    }

    static /* synthetic */ aann c(aanc aanc2) {
        return aanc2.a;
    }

    static /* synthetic */ aanr d(aanc aanc2) {
        return aanc2.b;
    }

    public aanc a(aann aann2) {
        this.a = (aann)awec.a((Object)aann2);
        return this;
    }

    public aanc a(aanp aanp2) {
        this.d = (aanp)awec.a((Object)aanp2);
        return this;
    }

    public aanc a(aanr aanr2) {
        this.b = (aanr)((Object)awec.a((Object)((Object)aanr2)));
        return this;
    }

    public aanc a(PrimerView primerView) {
        this.c = (PrimerView)awec.a((Object)primerView);
        return this;
    }

    @Override
    public aank a() {
        if (this.a == null) {
            throw new IllegalStateException(aann.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aanr.class.getCanonicalName() + " must be set");
        }
        if (this.c == null) {
            throw new IllegalStateException(PrimerView.class.getCanonicalName() + " must be set");
        }
        if (this.d == null) {
            throw new IllegalStateException(aanp.class.getCanonicalName() + " must be set");
        }
        return new aanb(this);
    }

    @Override
    public /* synthetic */ aanl b(aann aann2) {
        return this.a(aann2);
    }

    @Override
    public /* synthetic */ aanl b(aanp aanp2) {
        return this.a(aanp2);
    }

    @Override
    public /* synthetic */ aanl b(aanr aanr2) {
        return this.a(aanr2);
    }

    @Override
    public /* synthetic */ aanl b(PrimerView primerView) {
        return this.a(primerView);
    }
}

