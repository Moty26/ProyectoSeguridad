/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService
 */
import com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService;

public final class aach
implements aacl {
    static final /* synthetic */ boolean a;
    private axss<aaco> b;
    private awdr<GeofenceTransitionsIntentService> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aach.class.desiredAssertionStatus();
        a = bl;
    }

    private aach(aaci aaci2) {
        if (!a && aaci2 == null) {
            throw new AssertionError();
        }
        this.a(aaci2);
    }

    public static aaci a() {
        return new aaci(null);
    }

    private void a(aaci aaci2) {
        this.b = aacp.a(aaci.a(aaci2));
        this.c = aacq.a(this.b);
    }

    @Override
    public void a(GeofenceTransitionsIntentService geofenceTransitionsIntentService) {
        this.c.a((Object)geofenceTransitionsIntentService);
    }

}

