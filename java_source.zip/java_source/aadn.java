/*
 * Decompiled with CFR 0_119.
 */
public interface aadn {
    public int f();

    public int g();
}

