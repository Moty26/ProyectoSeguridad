/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.contact_driver.edit_number.EditNumberView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.contact_driver.edit_number.EditNumberView;

public class aapo
extends exk<EditNumberView, aapy, aapr> {
    public aapo(aapr aapr2) {
        super((Object)aapr2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aapy b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLQBSowUJrEDwlnJHsPUEF7f3kupxHyjF82jHCJ5CSOrR5xJE09wvc05Ikq/u4Z+OKs=", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2eGNxdwxglj29tSwoSvMIOSg56cue6FxIclB4BUo9g5zci7qm3Z7Y26Vo0vnzEJ+xnfwzwAOVCXpzTye05sn8lg==", -181699143596906491L, -6375925898082488367L, -354248918841952344L, 7185931817553012858L, null, "enc::hd0/qd83kVeT+kfPiATDH3kFIEENP+jpPvG//37omGk=", 40) : null;
        object = (EditNumberView)this.a_((ViewGroup)object);
        aapt aapt2 = new aapt();
        object = new aapy((EditNumberView)object, aapt2, aapj.a().a((aapr)this.bS_()).a(new aapq(aapt2, (EditNumberView)object)).a());
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected EditNumberView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLQBSowUJrEDwlnJHsPUEF7f3kupxHyjF82jHCJ5CSOrR5xJE09wvc05Ikq/u4Z+OKs=", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zPSBDgMkU0Qd74/R+0RWMEyP+bZvrOoAYoEYynJWcJyoPetUEyjY2QOcgJIGErnYs", -181699143596906491L, -6375925898082488367L, -2960527463591415885L, 7185931817553012858L, null, "enc::hd0/qd83kVeT+kfPiATDH3kFIEENP+jpPvG//37omGk=", 52) : null;
        layoutInflater = (EditNumberView)layoutInflater.inflate(aaof.ub_optional__contact_driver_edit_number, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

