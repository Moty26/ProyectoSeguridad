/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apaq
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 *  ewc
 *  eyq
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public interface aaiw {
    public apaq e();

    public aagq f();

    public eyq g();

    public OfferResponse h();

    public ewc i();
}

