/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 */
public final class aapk {
    private aapq a;
    private aapr b;

    private aapk() {
    }

    static /* synthetic */ aapq a(aapk aapk2) {
        return aapk2.a;
    }

    static /* synthetic */ aapr b(aapk aapk2) {
        return aapk2.b;
    }

    public aapk a(aapq aapq2) {
        this.a = (aapq)((Object)awec.a((Object)((Object)aapq2)));
        return this;
    }

    public aapk a(aapr aapr2) {
        this.b = (aapr)awec.a((Object)aapr2);
        return this;
    }

    public aapp a() {
        if (this.a == null) {
            throw new IllegalStateException(aapq.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aapr.class.getCanonicalName() + " must be set");
        }
        return new aapj(this);
    }
}

