/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

class aaiq
implements axss<OfferResponse> {
    private final aaib a;

    aaiq(aaib aaib2) {
        this.a = aaib2;
    }

    public OfferResponse a() {
        return this.a.h();
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

