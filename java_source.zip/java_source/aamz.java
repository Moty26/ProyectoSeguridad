/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  awnk
 */
import android.net.Uri;
import java.util.Map;

final class aamz
extends aanp {
    private final aanw a;
    private final Boolean b;
    private final int c;
    private final int d;
    private final int e;
    private final int f;
    private final int g;
    private final int h;
    private final String i;
    private final String j;
    private final String k;
    private final String l;
    private final String m;
    private final awnk<String, Map<String, String>> n;
    private final awnk<String, Map<String, String>> o;
    private final awnk<String, Map<String, String>> p;
    private final awnk<String, Map<String, String>> q;
    private final awnk<String, Map<String, String>> r;
    private final int s;
    private final int t;
    private final String u;
    private final int v;
    private final Uri w;

    private aamz(aanw aanw2, Boolean bl, int n, int n2, int n3, int n4, int n5, int n6, String string, String string2, String string3, String string4, String string5, awnk<String, Map<String, String>> awnk2, awnk<String, Map<String, String>> awnk3, awnk<String, Map<String, String>> awnk4, awnk<String, Map<String, String>> awnk5, awnk<String, Map<String, String>> awnk6, int n7, int n8, String string6, int n9, Uri uri) {
        this.a = aanw2;
        this.b = bl;
        this.c = n;
        this.d = n2;
        this.e = n3;
        this.f = n4;
        this.g = n5;
        this.h = n6;
        this.i = string;
        this.j = string2;
        this.k = string3;
        this.l = string4;
        this.m = string5;
        this.n = awnk2;
        this.o = awnk3;
        this.p = awnk4;
        this.q = awnk5;
        this.r = awnk6;
        this.s = n7;
        this.t = n8;
        this.u = string6;
        this.v = n9;
        this.w = uri;
    }

    @Override
    public aanw a() {
        return this.a;
    }

    @Override
    public Boolean b() {
        return this.b;
    }

    @Override
    public int c() {
        return this.c;
    }

    @Override
    public int d() {
        return this.d;
    }

    @Override
    public int e() {
        return this.e;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof aanp)) return false;
        if (!this.a.equals((Object)(object = (aanp)object).a())) return false;
        if (!this.b.equals(object.b())) return false;
        if (this.c != object.c()) return false;
        if (this.d != object.d()) return false;
        if (this.e != object.e()) return false;
        if (this.f != object.f()) return false;
        if (this.g != object.g()) return false;
        if (this.h != object.h()) return false;
        if (this.i == null) {
            if (object.i() != null) return false;
        } else if (!this.i.equals(object.i())) return false;
        if (this.j == null) {
            if (object.j() != null) return false;
        } else if (!this.j.equals(object.j())) return false;
        if (this.k == null) {
            if (object.k() != null) return false;
        } else if (!this.k.equals(object.k())) return false;
        if (this.l == null) {
            if (object.l() != null) return false;
        } else if (!this.l.equals(object.l())) return false;
        if (this.m == null) {
            if (object.m() != null) return false;
        } else if (!this.m.equals(object.m())) return false;
        if (this.n == null) {
            if (object.n() != null) return false;
        } else if (!this.n.equals(object.n())) return false;
        if (this.o == null) {
            if (object.o() != null) return false;
        } else if (!this.o.equals(object.o())) return false;
        if (this.p == null) {
            if (object.p() != null) return false;
        } else if (!this.p.equals(object.p())) return false;
        if (this.q == null) {
            if (object.q() != null) return false;
        } else if (!this.q.equals(object.q())) return false;
        if (this.r == null) {
            if (object.r() != null) return false;
        } else if (!this.r.equals(object.r())) return false;
        if (this.s != object.s()) return false;
        if (this.t != object.t()) return false;
        if (this.u == null) {
            if (object.u() != null) return false;
        } else if (!this.u.equals(object.u())) return false;
        if (this.v != object.v()) return false;
        if (this.w == null) {
            if (object.w() == null) return true;
            return false;
        }
        if (!this.w.equals((Object)object.w())) return false;
        return true;
    }

    @Override
    public int f() {
        return this.f;
    }

    @Override
    public int g() {
        return this.g;
    }

    @Override
    public int h() {
        return this.h;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int hashCode() {
        int n = 0;
        int n2 = this.a.hashCode();
        int n3 = this.b.hashCode();
        int n4 = this.c;
        int n5 = this.d;
        int n6 = this.e;
        int n7 = this.f;
        int n8 = this.g;
        int n9 = this.h;
        int n10 = this.i == null ? 0 : this.i.hashCode();
        int n11 = this.j == null ? 0 : this.j.hashCode();
        int n12 = this.k == null ? 0 : this.k.hashCode();
        int n13 = this.l == null ? 0 : this.l.hashCode();
        int n14 = this.m == null ? 0 : this.m.hashCode();
        int n15 = this.n == null ? 0 : this.n.hashCode();
        int n16 = this.o == null ? 0 : this.o.hashCode();
        int n17 = this.p == null ? 0 : this.p.hashCode();
        int n18 = this.q == null ? 0 : this.q.hashCode();
        int n19 = this.r == null ? 0 : this.r.hashCode();
        int n20 = this.s;
        int n21 = this.t;
        int n22 = this.u == null ? 0 : this.u.hashCode();
        int n23 = this.v;
        if (this.w == null) {
            return ((n22 ^ (((n19 ^ (n18 ^ (n17 ^ (n16 ^ (n15 ^ (n14 ^ (n13 ^ (n12 ^ (n11 ^ (n10 ^ ((((((((n2 ^ 1000003) * 1000003 ^ n3) * 1000003 ^ n4) * 1000003 ^ n5) * 1000003 ^ n6) * 1000003 ^ n7) * 1000003 ^ n8) * 1000003 ^ n9) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003 ^ n20) * 1000003 ^ n21) * 1000003) * 1000003 ^ n23) * 1000003 ^ n;
        }
        n = this.w.hashCode();
        return ((n22 ^ (((n19 ^ (n18 ^ (n17 ^ (n16 ^ (n15 ^ (n14 ^ (n13 ^ (n12 ^ (n11 ^ (n10 ^ ((((((((n2 ^ 1000003) * 1000003 ^ n3) * 1000003 ^ n4) * 1000003 ^ n5) * 1000003 ^ n6) * 1000003 ^ n7) * 1000003 ^ n8) * 1000003 ^ n9) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003) * 1000003 ^ n20) * 1000003 ^ n21) * 1000003) * 1000003 ^ n23) * 1000003 ^ n;
    }

    @Override
    public String i() {
        return this.i;
    }

    @Override
    public String j() {
        return this.j;
    }

    @Override
    public String k() {
        return this.k;
    }

    @Override
    public String l() {
        return this.l;
    }

    @Override
    public String m() {
        return this.m;
    }

    @Override
    public awnk<String, Map<String, String>> n() {
        return this.n;
    }

    @Override
    public awnk<String, Map<String, String>> o() {
        return this.o;
    }

    @Override
    public awnk<String, Map<String, String>> p() {
        return this.p;
    }

    @Override
    public awnk<String, Map<String, String>> q() {
        return this.q;
    }

    @Override
    public awnk<String, Map<String, String>> r() {
        return this.r;
    }

    @Override
    public int s() {
        return this.s;
    }

    @Override
    public int t() {
        return this.t;
    }

    public String toString() {
        return "PrimerConfig{type=" + (Object)((Object)this.a) + ", " + "deferrable=" + this.b + ", " + "title=" + this.c + ", " + "message=" + this.d + ", " + "acceptButtonText=" + this.e + ", " + "acceptButtonPermissionGrantedText=" + this.f + ", " + "deferButtonText=" + this.g + ", " + "cancelButtonText=" + this.h + ", " + "primerImpressionAnalyticsUuid=" + this.i + ", " + "acceptButtonAnalyticsUuid=" + this.j + ", " + "deferButtonAnalyticsUuid=" + this.k + ", " + "cancelButtonAnalyticsUuid=" + this.l + ", " + "learnMoreLinkAnalyticsUuid=" + this.m + ", " + "primerImpressionAnalyticsMetadataFunc=" + this.n + ", " + "acceptButtonAnalyticsMetadataFunc=" + this.o + ", " + "deferButtonAnalyticsMetadataFunc=" + this.p + ", " + "cancelButtonAnalyticsMetadataFunc=" + this.q + ", " + "learnMoreLinkAnalyticsMetadataFunc=" + this.r + ", " + "legalText=" + this.s + ", " + "learnMoreLinkText=" + this.t + ", " + "learnMoreLinkSupportNodeUuid=" + this.u + ", " + "illustration=" + this.v + ", " + "illustrationUri=" + (Object)this.w + "}";
    }

    @Override
    public String u() {
        return this.u;
    }

    @Override
    public int v() {
        return this.v;
    }

    @Override
    public Uri w() {
        return this.w;
    }

    @Override
    public aanq x() {
        return new aana(this, null);
    }

}

