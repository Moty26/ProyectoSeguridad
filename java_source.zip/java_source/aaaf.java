/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  awdv
 *  awec
 *  axss
 *  bgl
 */
import android.content.Context;

public final class aaaf
implements awdv<aaai> {
    static final /* synthetic */ boolean a;
    private final aaad b;
    private final axss<Context> c;
    private final axss<bgl> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaaf.class.desiredAssertionStatus();
        a = bl;
    }

    public aaaf(aaad aaad2, axss<Context> axss2, axss<bgl> axss3) {
        if (!a && aaad2 == null) {
            throw new AssertionError();
        }
        this.b = aaad2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aaai> a(aaad aaad2, axss<Context> axss2, axss<bgl> axss3) {
        return new aaaf(aaad2, axss2, axss3);
    }

    public aaai a() {
        return (aaai)awec.a((Object)this.b.a((Context)this.c.get(), (bgl)this.d.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

