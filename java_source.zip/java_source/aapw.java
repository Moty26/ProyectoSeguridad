/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  auhz
 *  auif
 *  awlj
 *  awlp
 *  awnk
 *  com.ubercab.presidio.contact_driver.edit_number.EditNumberView
 *  eot
 *  eov
 *  eox
 *  exl
 *  gsq
 *  llg
 *  llw
 */
import android.content.Context;
import android.view.View;
import com.ubercab.presidio.contact_driver.edit_number.EditNumberView;

public class aapw
extends exl<EditNumberView> {
    private final aapx a;

    aapw(EditNumberView editNumberView, aapx aapx2) {
        super((View)editNumberView);
        this.a = aapx2;
    }

    public void a() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLQBSowUJrEDwlnJHsPUEF7foOysjutRxAipS5auSa5psOS7pAasHMqEpgHUZKR/0DY=", "enc::l8FfuXWs4U9okdTbcl55pCyGfRN+jNK/5jEj7W4FrxI=", -181699143596906491L, -1306123658270602657L, -2422322744111397663L, 1953763409102406465L, null, "enc::I35zU7xKSYc94Y+6ifViMhOkQtV1nE7hyDm9VtW28d8=", 57);
        }
        gsq.b((Context)((EditNumberView)this.i()).getContext(), (View)this.i());
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(String string) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLQBSowUJrEDwlnJHsPUEF7foOysjutRxAipS5auSa5psOS7pAasHMqEpgHUZKR/0DY=", "enc::oQpgw2FOJtP38DOIKSWcIF6wvtgNRtL3RNDBwGyvbYLbMD1n9sIX6ntd1K7Sh+IgdV8zyrueVQ8VtPMmWkQt8g==", -181699143596906491L, -1306123658270602657L, 722995883405170024L, 1953763409102406465L, null, "enc::I35zU7xKSYc94Y+6ifViMhOkQtV1nE7hyDm9VtW28d8=", 64) : null;
        ((EditNumberView)this.i()).a(string);
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void b() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLQBSowUJrEDwlnJHsPUEF7foOysjutRxAipS5auSa5psOS7pAasHMqEpgHUZKR/0DY=", "enc::TP5fG2QMEc2SSfIWyOwinMKKMJfCK6xap/fzcCWrB8w5R962NZiP/4zI/9MVCh+H", -181699143596906491L, -1306123658270602657L, 3005462699672969350L, 1953763409102406465L, null, "enc::I35zU7xKSYc94Y+6ifViMhOkQtV1nE7hyDm9VtW28d8=", 79);
        }
        ((EditNumberView)this.i()).b(((EditNumberView)this.i()).getContext().getString(aaog.edit_number_invalid_number));
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKkIFgmmuJxSkfBthxcp8fLQBSowUJrEDwlnJHsPUEF7foOysjutRxAipS5auSa5psOS7pAasHMqEpgHUZKR/0DY=", "enc::mHjNXpidAhZ1UI8Bj9wOhNESYLsWWaNS+Ga0pIiMDWk=", -181699143596906491L, -1306123658270602657L, 8792004404122595672L, 1953763409102406465L, null, "enc::I35zU7xKSYc94Y+6ifViMhOkQtV1nE7hyDm9VtW28d8=", 28);
        }
        super.f();
        ((eov)((EditNumberView)this.i()).f().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz auhz2) {
                aapw.this.a.d();
            }
        });
        ((eov)((EditNumberView)this.i()).g().to((awnk)new eot((eox)this))).a((awlp)new auif<auhz>(){

            public void a(auhz object) {
                object = ((EditNumberView)aapw.this.i()).h();
                if (object != null) {
                    aapw.this.a.a((String)object);
                }
            }
        });
        gsq.a((Context)((EditNumberView)this.i()).getContext(), (View)this.i());
        if (llw2 != null) {
            llw2.i();
        }
    }

}

