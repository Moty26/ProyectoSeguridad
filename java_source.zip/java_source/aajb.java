/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apaq
 *  auif
 *  awlj
 *  awln
 *  awlp
 *  awlq
 *  awmh
 *  awnf
 *  awnk
 *  com.uber.model.core.generated.rtapi.models.rider.Rider
 *  com.ubercab.presidio.countrypicker.core.model.Country
 *  eop
 *  eot
 *  eov
 *  ewe
 *  ewj
 *  ewz
 *  hhy
 *  llg
 *  llw
 */
import com.uber.model.core.generated.rtapi.models.rider.Rider;
import com.ubercab.presidio.countrypicker.core.model.Country;

public class aajb
extends ewj<aajd, aajf>
implements aaje,
abua {
    aajd a;
    aagq b;
    apaq c;

    private void f() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::i3QjaNV65HYUV0vC0SkK6cQmWTjlnisrCVVL4scrEruxqsqvCSm9k+hQkiXa8gr8", -874676037324681323L, -1956632878226270289L, 9070990917419372137L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 53);
        }
        awlj awlj2 = this.b.b().map((awnk)new awnk<aags, hhy<aags>>(){

            public hhy<aags> a(aags aags2) throws Exception {
                return hhy.b((Object)aags2);
            }
        }).startWith((Object)hhy.e());
        ((eov)awlj.combineLatest((awln)this.c.d(), (awln)awlj2, (awnf)new awnf<hhy<Rider>, hhy<aags>, hhy<aags>>(){

            public hhy<aags> a(hhy<Rider> rider, hhy<aags> hhy2) throws Exception {
                if (!hhy2.b() && rider.b()) {
                    rider = (Rider)rider.c();
                    return hhy.b((Object)new aags(rider.firstName(), rider.lastName(), rider.email(), rider.mobileDigits(), null, Country.DEFAULT_COUNTRY));
                }
                return hhy.e();
            }
        }).take(1).observeOn(awmh.a()).to((awnk)new eot((eop)this))).a((awlp)new auif<hhy<aags>>(){

            public void a(hhy<aags> hhy2) throws Exception {
                if (hhy2.b()) {
                    aajb.this.b.a((aags)hhy2.c());
                }
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void a(Country country) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::RwFgXp2pky4ac6/vDUW+LZEaK9y2yeY28asVojUVhrV/uHMqktr5MhJh3ZOircTDj+5o3v8177uIakfhNiXu4Ee9xPnkA0tJwTmFpx1y5Q2Ym0WpAveZ5FzMAQGO8M4a", -874676037324681323L, -1956632878226270289L, 3366708193989875846L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 114) : null;
        ((aajf)this.h()).k();
        this.a.a(country);
        if (llw2 != null) {
            llw2.i();
        }
    }

    protected void a(ewe ewe2) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", -874676037324681323L, -1956632878226270289L, -8133349418566419115L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 48);
        }
        super.a(ewe2);
        this.f();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::y1rpnWj87C64E0bWK5Ms9ou/kjjEhPsLewGBaStdNbw=", -874676037324681323L, -1956632878226270289L, 9091970710563555742L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 38);
        }
        ((aajf)this.h()).j();
        if (llw2 != null) {
            llw2.i();
        }
    }

    @Override
    public void e() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::+h1tLDd02ucW+8SvFzR689JhHVZQdd0iQ71kCU3Rz8c=", -874676037324681323L, -1956632878226270289L, -4799188229996393328L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 43);
        }
        ((aajf)this.h()).l();
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", -874676037324681323L, -1956632878226270289L, -6923720291955140451L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 108);
        }
        ((aajf)this.h()).i();
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }

    @Override
    public void n() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gny+uh0PnpWFSC0f30JuvM07lOocd+oqIJXQiFbf/K47cp/Go13aQmjd+f2r3Wo7wi0ub3xg0mIquO4lkSfg+tT", "enc::RwFgXp2pky4ac6/vDUW+LU5IftWgUtfhtE49coR6grFj/yfcckAM3KJGDNwxoGjt", -874676037324681323L, -1956632878226270289L, -8866173826281561521L, 6165381391493657874L, null, "enc::GGnQ/DmzriVCDvUcUBgL3dE5nSU477NKb/o00po+pdGmiOFlJ/6yvw/YNFPnSNVp", 120);
        }
        ((aajf)this.h()).k();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

