/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  com.uber.rib.core.RibActivity
 */
import com.uber.rib.core.RibActivity;

class aapg
implements axss<RibActivity> {
    private final aaow a;

    aapg(aaow aaow2) {
        this.a = aaow2;
    }

    public RibActivity a() {
        return (RibActivity)awec.a((Object)this.a.i(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

