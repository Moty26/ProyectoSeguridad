/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ShortcutInfo
 *  android.graphics.drawable.Icon
 *  com.uber.model.core.generated.ms.search.generated.GeolocationResult
 *  hhy
 */
import android.content.Context;
import android.content.pm.ShortcutInfo;
import android.graphics.drawable.Icon;
import com.uber.model.core.generated.ms.search.generated.GeolocationResult;

public interface aabq {
    public Icon a(Context var1, int var2);

    public hhy<ShortcutInfo> a(Context var1, GeolocationResult var2, String var3, String var4, Icon var5, String var6);

    public String a(Context var1, String var2);

    public String b(Context var1, int var2);
}

