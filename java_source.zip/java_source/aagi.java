/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

public final class aagi
implements awdv<OfferResponse> {
    static final /* synthetic */ boolean a;
    private final aagc b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aagi.class.desiredAssertionStatus();
        a = bl;
    }

    public aagi(aagc aagc2) {
        if (!a && aagc2 == null) {
            throw new AssertionError();
        }
        this.b = aagc2;
    }

    public static awdv<OfferResponse> a(aagc aagc2) {
        return new aagi(aagc2);
    }

    public OfferResponse a() {
        return this.b.e();
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

