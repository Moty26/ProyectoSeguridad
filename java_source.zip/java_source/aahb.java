/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.address.CobrandCardAddressView;

public class aahb
extends exk<CobrandCardAddressView, aahn, aahf> {
    public aahb(aahf aahf2) {
        super((Object)aahf2);
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aahn b(ViewGroup object) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPqhW1jdH+l1E0/cWHaeD7dk=", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Ymm2T1SB+EZOzruz3Me6SDX2R1PLk5O/qE8q7J20F2raPlZLQd6a5FAvuXUpOS4R+AvL0HEqPR22NB3WQZG+REXneoJPyGnF9M6PBF2mPjFKd3tEWW8ZkRDq4CU3xUGp9Iw=", -1445367778186893929L, 4066732540520797603L, 9016671131350701661L, 7185931817553012858L, null, "enc::Rw2kQHiSRuVukVtkMBkEvQ7/FVhVzyj/K4UgGeYuOpE=", 47) : null;
        object = (CobrandCardAddressView)this.a_((ViewGroup)object);
        aahj aahj2 = new aahj();
        object = aahp.b().a((aahf)this.bS_()).a(new aahe(aahj2, (CobrandCardAddressView)object)).a().a();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected CobrandCardAddressView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gm5sDQpyL+QKtBhmeKj3CMFtGzlwdAN+xp7v9wtmnINPqhW1jdH+l1E0/cWHaeD7dk=", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zMmvnVZyy2ZVqacok3gBZFoBbc8bexjxyiGlzmXJjN1j7zFKvy3CTaY3i/nZ/pusRS9hpODGe2dS/L5xPW+USig==", -1445367778186893929L, 4066732540520797603L, -6746209807985054837L, 7185931817553012858L, null, "enc::Rw2kQHiSRuVukVtkMBkEvQ7/FVhVzyj/K4UgGeYuOpE=", 58) : null;
        layoutInflater = (CobrandCardAddressView)layoutInflater.inflate(aafw.ub__cobrandcard_address, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

