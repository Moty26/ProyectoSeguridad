/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  eyq
 */
public final class aagk
implements awdv<aagp> {
    static final /* synthetic */ boolean a;
    private final aagc b;
    private final axss<aagb> c;
    private final axss<eyq> d;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aagk.class.desiredAssertionStatus();
        a = bl;
    }

    public aagk(aagc aagc2, axss<aagb> axss2, axss<eyq> axss3) {
        if (!a && aagc2 == null) {
            throw new AssertionError();
        }
        this.b = aagc2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
        if (!a && axss3 == null) {
            throw new AssertionError();
        }
        this.d = axss3;
    }

    public static awdv<aagp> a(aagc aagc2, axss<aagb> axss2, axss<eyq> axss3) {
        return new aagk(aagc2, axss2, axss3);
    }

    public aagp a() {
        return (aagp)((Object)awec.a((Object)((Object)this.b.a((aagb)this.c.get(), (eyq)this.d.get())), (String)"Cannot return null from a non-@Nullable @Provides method"));
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

