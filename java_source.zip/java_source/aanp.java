/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  awnk
 */
import android.net.Uri;
import java.util.Map;

public abstract class aanp {
    public static aanq y() {
        return new aana().a(aanw.a).d(0).h(0).g(0).i(0);
    }

    public abstract aanw a();

    public abstract Boolean b();

    public abstract int c();

    public abstract int d();

    public abstract int e();

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract String i();

    public abstract String j();

    public abstract String k();

    public abstract String l();

    public abstract String m();

    public abstract awnk<String, Map<String, String>> n();

    public abstract awnk<String, Map<String, String>> o();

    public abstract awnk<String, Map<String, String>> p();

    public abstract awnk<String, Map<String, String>> q();

    public abstract awnk<String, Map<String, String>> r();

    public abstract int s();

    public abstract int t();

    public abstract String u();

    public abstract int v();

    public abstract Uri w();

    public abstract aanq x();
}

