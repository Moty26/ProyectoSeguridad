/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  hqg
 */
public enum aabv implements hqg
{
    AIRPORT_ARRIVAL_NOTIFICATION_MASTER,
    AIRPORT_ARRIVAL_NOTIFICATION_VIBRATE,
    AIRPORT_ARRIVAL_NOTIFICATION_NO_NEARBY,
    GEOFENCE_REGISTRATION_QUOTA;
    

    private aabv() {
    }
}

