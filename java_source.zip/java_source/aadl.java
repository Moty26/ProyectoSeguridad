/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  com.ubercab.presidio.behaviors.core.LegacyExpandingBottomSheetBehavior
 *  com.ubercab.presidio.behaviors.core.LegacyExpandingBottomSheetBehavior$1
 */
import android.animation.Animator;
import com.ubercab.presidio.behaviors.core.LegacyExpandingBottomSheetBehavior;

public class aadl
implements Animator.AnimatorListener {
    private aadl() {
    }

    public void onAnimationCancel(Animator animator) {
    }

    public void onAnimationEnd(Animator animator) {
    }

    public void onAnimationRepeat(Animator animator) {
    }

    public void onAnimationStart(Animator animator) {
    }
}

