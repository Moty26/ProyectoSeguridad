/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdv
 *  awec
 *  axss
 *  com.ubercab.presidio.contacts.model.ContactPickerCustomization
 */
import com.ubercab.presidio.contacts.model.ContactPickerCustomization;

public final class aara
implements awdv<aaqh> {
    static final /* synthetic */ boolean a;
    private final aaqx b;
    private final axss<ContactPickerCustomization> c;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aara.class.desiredAssertionStatus();
        a = bl;
    }

    public aara(aaqx aaqx2, axss<ContactPickerCustomization> axss2) {
        if (!a && aaqx2 == null) {
            throw new AssertionError();
        }
        this.b = aaqx2;
        if (!a && axss2 == null) {
            throw new AssertionError();
        }
        this.c = axss2;
    }

    public static awdv<aaqh> a(aaqx aaqx2, axss<ContactPickerCustomization> axss2) {
        return new aara(aaqx2, axss2);
    }

    public aaqh a() {
        return (aaqh)awec.a((Object)this.b.b((ContactPickerCustomization)this.c.get()), (String)"Cannot return null from a non-@Nullable @Provides method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

