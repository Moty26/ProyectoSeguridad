/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  ewm
 */
interface aaju
extends aajt,
ewm<aakb, aajz> {
}

