/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineOtpModel
 */
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.ubercab.presidio.app_onboarding.plugin.onboard.social.line.model.LineOtpModel;

public class aabg {
    private final Context a;

    aabg(Context context) {
        this.a = context;
    }

    private String a(String string) {
        return "line." + string;
    }

    static boolean a(Context context) {
        context = context.getPackageManager();
        try {
            context.getPackageInfo("jp.naver.line.android", 1);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    public Intent a(LineOtpModel lineOtpModel, String string, String string2) {
        Intent intent = new Intent("jp.naver.line.android.intent.action.APPAUTH");
        intent.putExtra("channelId", string);
        intent.putExtra("otpId", lineOtpModel.otpId());
        intent.putExtra("appPackage", string2);
        intent.putExtra("authScheme", this.a(string));
        intent.addFlags(65536);
        return intent;
    }
}

