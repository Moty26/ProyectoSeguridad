/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  axss
 *  com.uber.model.core.generated.crack.cobrandcard.OfferResponse
 */
import com.uber.model.core.generated.crack.cobrandcard.OfferResponse;

class aakj
implements axss<OfferResponse> {
    private final aajw a;

    aakj(aajw aajw2) {
        this.a = aajw2;
    }

    public OfferResponse a() {
        return this.a.g();
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

