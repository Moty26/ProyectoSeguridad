/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agi
 */
public interface aaee {
    public void a(agi var1);
}

