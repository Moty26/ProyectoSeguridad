/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 */
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

final class aafj
implements aaew {
    private aaey a;
    private aafc b;
    private CobrandCardOfferView c;

    private aafj() {
    }

    static /* synthetic */ CobrandCardOfferView a(aafj aafj2) {
        return aafj2.c;
    }

    static /* synthetic */ aaey b(aafj aafj2) {
        return aafj2.a;
    }

    static /* synthetic */ aafc c(aafj aafj2) {
        return aafj2.b;
    }

    @Override
    public aaev a() {
        if (this.a == null) {
            throw new IllegalStateException(aaey.class.getCanonicalName() + " must be set");
        }
        if (this.b == null) {
            throw new IllegalStateException(aafc.class.getCanonicalName() + " must be set");
        }
        if (this.c == null) {
            throw new IllegalStateException(CobrandCardOfferView.class.getCanonicalName() + " must be set");
        }
        return new aafi(this);
    }

    @Override
    public /* synthetic */ aaew a(aaey aaey2) {
        return this.b(aaey2);
    }

    @Override
    public /* synthetic */ aaew a(aafc aafc2) {
        return this.b(aafc2);
    }

    @Override
    public /* synthetic */ aaew a(CobrandCardOfferView cobrandCardOfferView) {
        return this.b(cobrandCardOfferView);
    }

    public aafj b(aaey aaey2) {
        this.a = (aaey)awec.a((Object)aaey2);
        return this;
    }

    public aafj b(aafc aafc2) {
        this.b = (aafc)awec.a((Object)aafc2);
        return this;
    }

    public aafj b(CobrandCardOfferView cobrandCardOfferView) {
        this.c = (CobrandCardOfferView)awec.a((Object)cobrandCardOfferView);
        return this;
    }
}

