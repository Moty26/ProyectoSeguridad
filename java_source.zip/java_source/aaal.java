/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  ewc
 *  ewj
 *  ewl
 *  ewz
 *  llg
 *  llw
 */
import android.content.Intent;

class aaal
extends ewz<aaaj, aaac> {
    private final ewc a;
    private final aaai b;

    aaal(aaaj aaaj2, aaac aaac2) {
        super((ewj)aaaj2, (ewl)aaac2);
        this.a = aaac2.d();
        this.b = aaac2.e();
    }

    void h() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKrYY02ewt63illF9HkiSTNDAPnltlUdbHaSjU9mQBQ1T5Fkc2AyN831TSN0napO55CN2/F3v2/cPMqFZOpiQfPg=", "enc::63YcUZRexjXSatE7ucI4aJnUpLj8Da5JlWfIlkDGQPw=", -5263566877833729371L, -657858280821338343L, 4623291339893257299L, 4285526870058266813L, null, "enc::qO2hN52205c3SQyYojod/tG2OCMLGn7tBKlquzT9Pfc=", 28);
        }
        this.a.startActivityForResult(this.b.b(), 50002);
        if (llw2 != null) {
            llw2.i();
        }
    }
}

