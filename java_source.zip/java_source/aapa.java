/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awec
 *  axss
 *  hpz
 */
class aapa
implements axss<hpz> {
    private final aaow a;

    aapa(aaow aaow2) {
        this.a = aaow2;
    }

    public hpz a() {
        return (hpz)awec.a((Object)this.a.c(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

