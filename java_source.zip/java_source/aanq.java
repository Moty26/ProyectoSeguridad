/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awnk
 */
import java.util.Map;

public abstract class aanq {
    public abstract aanp a();

    public abstract aanq a(int var1);

    public abstract aanq a(aanw var1);

    public abstract aanq a(awnk<String, Map<String, String>> var1);

    public abstract aanq a(Boolean var1);

    public abstract aanq a(String var1);

    public abstract aanq b(int var1);

    public abstract aanq b(awnk<String, Map<String, String>> var1);

    public abstract aanq b(String var1);

    public abstract aanq c(int var1);

    public abstract aanq c(awnk<String, Map<String, String>> var1);

    public abstract aanq c(String var1);

    public abstract aanq d(int var1);

    public abstract aanq d(awnk<String, Map<String, String>> var1);

    public abstract aanq d(String var1);

    public abstract aanq e(int var1);

    public abstract aanq e(awnk<String, Map<String, String>> var1);

    public abstract aanq e(String var1);

    public abstract aanq f(int var1);

    public abstract aanq f(String var1);

    public abstract aanq g(int var1);

    public abstract aanq h(int var1);

    public abstract aanq i(int var1);
}

