/*
 * Decompiled with CFR 0_119.
 */
interface aahy {
    public aaij a();
}

