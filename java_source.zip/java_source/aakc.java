/*
 * Decompiled with CFR 0_119.
 */
interface aakc {
    public void a(String var1);

    public void d();

    public void e();

    public void f();

    public void m();
}

