/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.uber.model.core.generated.rtapi.services.marketplacerider.Driver
 *  com.uber.model.core.generated.rtapi.services.marketplacerider.DriverFlowType
 *  com.uber.model.core.generated.rtapi.services.marketplacerider.Trip
 *  hpz
 *  hqg
 */
import com.uber.model.core.generated.rtapi.services.marketplacerider.Driver;
import com.uber.model.core.generated.rtapi.services.marketplacerider.DriverFlowType;
import com.uber.model.core.generated.rtapi.services.marketplacerider.Trip;

public final class aaky {
    public static boolean a(Trip trip) {
        if (trip != null && trip.driver() != null && DriverFlowType.COMMUTE.equals((Object)trip.driver().flowType())) {
            return true;
        }
        return false;
    }

    public static boolean a(hpz hpz2) {
        return hpz2.a((hqg)aakt.DXC_COMMUTE_RIDER_MASTER);
    }
}

