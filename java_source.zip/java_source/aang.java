/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  atvd
 *  awec
 *  axss
 */
class aang
implements axss<atvd> {
    private final aann a;

    aang(aann aann2) {
        this.a = aann2;
    }

    public atvd a() {
        return (atvd)awec.a((Object)this.a.e(), (String)"Cannot return null from a non-@Nullable component method");
    }

    public /* synthetic */ Object get() {
        return this.a();
    }
}

