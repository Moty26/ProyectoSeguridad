/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView
 *  ewj
 *  ewl
 *  ewz
 *  exm
 *  eyq
 *  llg
 *  llw
 */
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.cobrandcard.application.CobrandCardApplicationView;

public class aagp
extends exm<CobrandCardApplicationView, aagl, aagb> {
    private final eyq a;
    private final aais b;

    public aagp(CobrandCardApplicationView cobrandCardApplicationView, aagl aagl2, aagb aagb2, eyq eyq2, aais aais2) {
        super((View)cobrandCardApplicationView, (ewj)aagl2, (ewl)aagb2);
        this.a = eyq2;
        this.b = aais2;
    }

    public void i() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm5reAs91U7dztr4qEs5vwVA=", "enc::MW1qpwovHmeQo3067P3+5lc0PUnPWwDzd8Vuy8gcISQ=", 7963966960560010407L, -3720113108403587562L, -2859438141256472459L, 4285526870058266813L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcM9OlxQLRHbMWlSoLDgFDilxlvNw9wRb7t35uogZmoj1", 30);
        }
        this.a.a(false);
        if (llw2 != null) {
            llw2.i();
        }
    }

    public void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKpEETJ7/lZoZXyUHH7h02gmDA8jtl46Hl1nPk0mbCVQI/wK7x3IbhsyLdYB7hC4Qm5reAs91U7dztr4qEs5vwVA=", "enc::3STOaptO6xbQP1wVVRzQjd6WFJRExp1dvWztTh80weE=", 7963966960560010407L, -3720113108403587562L, 732373300231228110L, 4285526870058266813L, null, "enc::qmxKIMe7wJW/Ayy0UBwZcM9OlxQLRHbMWlSoLDgFDilxlvNw9wRb7t35uogZmoj1", 34);
        }
        aajf aajf2 = this.b.b((ViewGroup)this.h());
        this.a((ewz)aajf2);
        ((CobrandCardApplicationView)this.h()).a(aajf2.h());
        if (llw2 != null) {
            llw2.i();
        }
    }
}

