/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  com.ubercab.presidio.consent.primer.PrimerView
 *  com.ubercab.presidio.consent.primer.fullscreen.PrimerFullScreenView
 *  com.ubercab.presidio.consent.primer.modal.PrimerModalView
 *  exk
 *  llg
 *  llw
 */
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.ubercab.presidio.consent.primer.PrimerView;
import com.ubercab.presidio.consent.primer.fullscreen.PrimerFullScreenView;
import com.ubercab.presidio.consent.primer.modal.PrimerModalView;

public class aani
extends exk<PrimerView, aanv, aann> {
    private aanp a;

    public aani(aann aann2) {
        super((Object)aann2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public aanv a(ViewGroup object, aanp aanp2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM1EUiPZDgeXkAEHiv1nU9KeU/AFy/1NthqJ8Iu1IDJvjA==", "enc::tvPkdc4YLvDZOyc6kVDM/5C32pC1EHPH3SeQLab4Yml/+FqMVuRigd204NC9oHkAVjYxG9nC+lQmPnWBHTP2jbT9VpuS2SYpzsMh5AWtJENPtcQEW5gY6WOn00ust2Z7isCA9x1a80rEC5mMUTaNG/f+2e7LiFswBb9pwceu9qSgykOb4L5u1QnZluNWBreZ", -1924344159138755995L, -7847615470716166372L, 4141229204624356511L, 7185931817553012858L, null, "enc::HIKo3VZZ3hiv3m26pCWD460dJWzU3xXtFP0SjBQY8FY=", 48) : null;
        this.a = aanp2;
        object = (PrimerView)this.a_((ViewGroup)object);
        aanr aanr2 = new aanr();
        object = aanb.a().b((aann)this.bS_()).b((PrimerView)object).b(aanp2).b(aanr2).a().b();
        if (llw2 != null) {
            llw2.i();
        }
        return object;
    }

    protected /* synthetic */ View a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return this.b(layoutInflater, viewGroup);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected PrimerView b(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM1EUiPZDgeXkAEHiv1nU9KeU/AFy/1NthqJ8Iu1IDJvjA==", "enc::HaOuYd3+Co0lhtuct1Qq4H/0NMgKpohwP7KRSF4d6sMFcWZA0rNmHonf2FX/IflpVAOBxYI4ARKYA4pknxY7wpduiH93g0MP1aTTqzt374IAuR1XGG1AMijIKXmX0++zuVwZmkiWruZsCrQW0wu+rjoXkpV3vTZRTfaL4RSdfyg=", -1924344159138755995L, -7847615470716166372L, 90961099190467001L, 7185931817553012858L, null, "enc::HIKo3VZZ3hiv3m26pCWD460dJWzU3xXtFP0SjBQY8FY=", 64) : null;
        layoutInflater = this.a == null || this.a.a() == aanw.a ? (PrimerFullScreenView)layoutInflater.inflate(PrimerFullScreenView.a, viewGroup, false) : (PrimerModalView)layoutInflater.inflate(PrimerModalView.a, viewGroup, false);
        if (llw2 != null) {
            llw2.i();
        }
        return layoutInflater;
    }
}

