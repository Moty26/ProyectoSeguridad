/*
 * Decompiled with CFR 0_119.
 */
public interface aaff {
    public void a();

    public void a(aafg var1);

    public void a(aafo var1, aafo var2);

    public void a(String var1, String var2, String var3, String var4, CharSequence var5, String var6, CharSequence var7);

    public void b();
}

