/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  apap
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient
 *  com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 *  esc
 *  ewc
 *  eyq
 */
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardClient;
import com.uber.model.core.generated.rtapi.services.cobrandcard.CobrandCardDataTransactions;
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

public abstract class aaex {
    static aafh a(aaev aaev2, CobrandCardOfferView cobrandCardOfferView, aafc aafc2, eyq eyq2, ewc ewc2) {
        return new aafh(new aafz(aaev2), cobrandCardOfferView, aafc2, aaev2, eyq2, ewc2);
    }

    static CobrandCardClient<apap> a(esc<apap> esc2, CobrandCardDataTransactions<apap> cobrandCardDataTransactions) {
        return new CobrandCardClient(esc2, cobrandCardDataTransactions);
    }

    static CobrandCardDataTransactions<apap> a() {
        return new aakn(){};
    }

}

