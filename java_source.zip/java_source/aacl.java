/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService
 */
import com.ubercab.presidio.arrival_notification.geofence.GeofenceTransitionsIntentService;

public interface aacl {
    public void a(GeofenceTransitionsIntentService var1);
}

