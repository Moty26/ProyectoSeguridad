/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.support.v4.util.ArrayMap
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  ne
 *  nf
 */
import android.content.Context;
import android.support.v4.util.ArrayMap;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

abstract class aam<T>
extends aan<T> {
    final Context a;
    private Map<ne, MenuItem> c;
    private Map<nf, SubMenu> d;

    aam(Context context, T t) {
        super(t);
        this.a = context;
    }

    final MenuItem a(MenuItem menuItem) {
        if (menuItem instanceof ne) {
            MenuItem menuItem2;
            ne ne2 = (ne)menuItem;
            if (this.c == null) {
                this.c = new ArrayMap();
            }
            menuItem = menuItem2 = this.c.get((Object)menuItem);
            if (menuItem2 == null) {
                menuItem = abl.a(this.a, ne2);
                this.c.put(ne2, menuItem);
            }
            return menuItem;
        }
        return menuItem;
    }

    final SubMenu a(SubMenu subMenu) {
        if (subMenu instanceof nf) {
            SubMenu subMenu2;
            nf nf2 = (nf)subMenu;
            if (this.d == null) {
                this.d = new ArrayMap();
            }
            subMenu = subMenu2 = this.d.get((Object)nf2);
            if (subMenu2 == null) {
                subMenu = abl.a(this.a, nf2);
                this.d.put(nf2, subMenu);
            }
            return subMenu;
        }
        return subMenu;
    }

    final void a() {
        if (this.c != null) {
            this.c.clear();
        }
        if (this.d != null) {
            this.d.clear();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final void a(int n) {
        if (this.c != null) {
            Iterator<ne> iterator = this.c.keySet().iterator();
            while (iterator.hasNext()) {
                if (n != ((MenuItem)iterator.next()).getGroupId()) continue;
                iterator.remove();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void b(int n) {
        if (this.c == null) {
            return;
        }
        Iterator<ne> iterator = this.c.keySet().iterator();
        do {
            if (!iterator.hasNext()) return;
        } while (n != ((MenuItem)iterator.next()).getItemId());
        iterator.remove();
    }
}

