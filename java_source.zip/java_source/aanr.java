/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  auhz
 *  auif
 *  auig
 *  awlc
 *  awle
 *  awlj
 *  awln
 *  awlp
 *  awlq
 *  awmh
 *  awnk
 *  eij
 *  eoc
 *  eop
 *  eoq
 *  eos
 *  eot
 *  eov
 *  ewe
 *  ewj
 *  ewz
 *  fbz
 *  llg
 *  llw
 */
import java.util.Map;
import java.util.Set;

public class aanr
extends ewj<aant, aanv> {
    aant a;
    aanp b;
    aans c;
    fbz d;
    private final String e = "primer_interactor";
    private final eij<auhz> f = eij.a();

    private void a(String string, awnk<String, Map<String, String>> object) {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM2k1aBK1TRSZTSsqpGlXMJ50196Wyjsw3DpbJ/WMA/IGQ==", "enc::olrPsukRNbHjazUXDNSaQn6Qje0uqev/L+SZFRW+LsH+Bp0Hf75uFVoIT9pgAX2PnyW0A1+PsfWZC1C1kEDtocYtFe5TV0CxxsvzVQ6Q4cQ=", -1924344159138755995L, -5972597517305516417L, 2454465106518012947L, 6165381391493657874L, null, "enc::7cxqzL37dVJJGEc3i8vgt972eju71wxjieb6NKzEJ2k=", 126);
        }
        object = this.b(string, (awnk<String, Map<String, String>>)object);
        this.d.c(string, new eoc((Map)object){
            final /* synthetic */ Map a;

            /*
             * Enabled aggressive block sorting
             */
            public void a(String string, Map<String, String> map) {
                if (this.a != null) {
                    for (Map.Entry entry : this.a.entrySet()) {
                        map.put(string + (String)entry.getKey(), (String)entry.getValue());
                    }
                }
            }

            public void addToMap(Map<String, String> map) {
                this.a("", map);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Map<String, String> b(String var1_1, awnk<String, Map<String, String>> var2_3) {
        var3_4 = llg.b() != false ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM2k1aBK1TRSZTSsqpGlXMJ50196Wyjsw3DpbJ/WMA/IGQ==", "enc::X/i3Ui3XDFg1rtTw+9z64X7DhTmUcNRphEDk/HmWhM6s/nugbHyvBj9/LtT+le7sU7DvlWn55WQ+pUWLzF5GsQFSHuKI/2XVHojRa+iauk/U2uti/Z67cQHAZv8kISkd", -1924344159138755995L, -5972597517305516417L, -6039854694180421591L, 6165381391493657874L, null, "enc::7cxqzL37dVJJGEc3i8vgt972eju71wxjieb6NKzEJ2k=", 152) : null;
        if (var2_3 != null) {
            var1_1 = (Map)var2_3.a(var1_1);
            ** GOTO lbl11
        } else {
            var1_1 = null;
        }
        ** GOTO lbl11
        catch (Exception var1_2) {
            kly.a("primer_interactor").a(var1_2, "error calling analytics metadata func", new Object[0]);
            var1_1 = null;
        }
lbl11: // 3 sources:
        if (var3_4 == null) return var1_1;
        var3_4.i();
        return var1_1;
    }

    private awlc<aanh> d() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM2k1aBK1TRSZTSsqpGlXMJ50196Wyjsw3DpbJ/WMA/IGQ==", "enc::pKlzCBx5X+oNalVN90VgfrYeahqeEhk126FZH7H8aFlsVRa5KjLryJyfKKaeXjpc", -1924344159138755995L, -5972597517305516417L, 6207436577533513403L, 6165381391493657874L, null, "enc::7cxqzL37dVJJGEc3i8vgt972eju71wxjieb6NKzEJ2k=", 97);
        }
        awlc awlc2 = this.a.i().e().mergeWith(this.a.a()).mergeWith(this.f).map((awnk)new awnk<auhz, aanh>(){

            public aanh a(auhz object) throws Exception {
                object = aanr.this.b.l();
                if (object != null && !object.isEmpty()) {
                    awnk<String, Map<String, String>> awnk2 = aanr.this.b.q();
                    aanr.this.a((String)object, awnk2);
                }
                return aanh.c;
            }
        }).mergeWith((awln)this.a.d().map((awnk)new awnk<auhz, aanh>(){

            public aanh a(auhz auhz2) throws Exception {
                if (aanr.this.b.b().booleanValue()) {
                    return aanh.b;
                }
                return aanh.c;
            }
        })).mergeWith((awln)this.a.c().map((awnk)new awnk<auhz, aanh>(){

            public aanh a(auhz auhz2) throws Exception {
                return aanh.a;
            }
        })).firstElement();
        if (llw2 != null) {
            llw2.i();
        }
        return awlc2;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ewe ewe2) {
        llw llw2 = llg.b() ? llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM2k1aBK1TRSZTSsqpGlXMJ50196Wyjsw3DpbJ/WMA/IGQ==", "enc::dW9X5/bjdvnORYNMCDtShg5xzgBQoGbRU3IWi5MmeKM7/HI2lrmYd/GR/HNsI8S4rKaXAZA0uzJvO3SEmEM6fA==", -1924344159138755995L, -5972597517305516417L, -8133349418566419115L, 6165381391493657874L, null, "enc::7cxqzL37dVJJGEc3i8vgt972eju71wxjieb6NKzEJ2k=", 48) : null;
        super.a(ewe2);
        this.a.a(this.b);
        if (this.b.a() == aanw.b) {
            this.a.e();
        }
        ((eos)this.d().a(awmh.a()).g((awnk)new eoq((eop)this))).a((awle)new auig<aanh>(){

            public void a(aanh aanh2) throws Exception {
                aanr.this.a.a(true);
                aanr.this.c.a(aanh2);
            }

            public /* synthetic */ void b(Object object) throws Exception {
                this.a((aanh)((Object)object));
            }
        });
        ((eov)this.a.b().observeOn(awmh.a()).to((awnk)new eot((eop)this))).a((awlp)new auif<auhz>(){

            public void a(auhz object) throws Exception {
                object = aanr.this.b.m();
                if (object != null && !object.isEmpty()) {
                    awnk<String, Map<String, String>> awnk2 = aanr.this.b.r();
                    aanr.this.a((String)object, awnk2);
                }
                ((aanv)aanr.this.h()).a(aanr.this.b);
            }
        });
        if (llw2 != null) {
            llw2.i();
        }
    }

    public boolean g() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM2k1aBK1TRSZTSsqpGlXMJ50196Wyjsw3DpbJ/WMA/IGQ==", "enc::Iz+INwt3TXY78KcnWq0/d7x0QqtMVLpztZ0VTjql6NI=", -1924344159138755995L, -5972597517305516417L, -6923720291955140451L, 6165381391493657874L, null, "enc::7cxqzL37dVJJGEc3i8vgt972eju71wxjieb6NKzEJ2k=", 89);
        }
        this.f.a((Object)auhz.a);
        if (llw2 != null) {
            llw2.i();
        }
        return true;
    }

    protected void j() {
        llw llw2 = null;
        if (llg.b()) {
            llw2 = llg.a().a("enc::7VsjMTtrifBTToI4Uo8rKlnITiWb5te99hDFeOqhOM2k1aBK1TRSZTSsqpGlXMJ50196Wyjsw3DpbJ/WMA/IGQ==", "enc::WD/7tN4wkeSoBb9ZkEP7FDkPfmQPXKZAVeV40pbq6/I=", -1924344159138755995L, -5972597517305516417L, -6590376132571480863L, 6165381391493657874L, null, "enc::7cxqzL37dVJJGEc3i8vgt972eju71wxjieb6NKzEJ2k=", 83);
        }
        super.j();
        this.a.h();
        if (llw2 != null) {
            llw2.i();
        }
    }

}

