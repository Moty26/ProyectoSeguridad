/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.webkit.CookieManager
 *  awlv
 *  awlz
 *  awnk
 *  com.uber.model.core.generated.rtapi.models.exception.ServerError
 *  com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenErrors
 *  com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenRequest
 *  com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenRequest$Builder
 *  com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenResponse
 *  com.uber.model.core.generated.rtapi.services.webauth.WebAuthClient
 *  erj
 *  esi
 *  esm
 *  esn
 */
import android.webkit.CookieManager;
import com.uber.model.core.generated.rtapi.models.exception.ServerError;
import com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenErrors;
import com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenRequest;
import com.uber.model.core.generated.rtapi.services.webauth.ArchSigninTokenResponse;
import com.uber.model.core.generated.rtapi.services.webauth.WebAuthClient;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

public class aacw {
    private aacx a;
    private WebAuthClient<? extends erj> b;

    public aacw(WebAuthClient<? extends erj> webAuthClient, aacx aacx2) {
        this.b = webAuthClient;
        this.a = aacx2;
    }

    private void a(String string, String string2) {
        try {
            if (this.a.c()) {
                this.a.a();
            }
            this.a.b().setCookie(string2, aacw.c(string));
            return;
        }
        catch (Throwable throwable) {
            kly.d(throwable, "Can't set cookie", new Object[0]);
            return;
        }
    }

    private static String c(String string) {
        Object object = Calendar.getInstance();
        object.add(12, 2);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, MMM dd yyyy HH:mm:ss z");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        object = simpleDateFormat.format(object.getTime());
        return String.format(Locale.getDefault(), "%s=%s;domain=%s;expires=%s;path=/", "wstate", string, "uber.com", object);
    }

    public awlv<String> a(final String string) {
        String string2 = UUID.randomUUID().toString();
        ArchSigninTokenRequest archSigninTokenRequest = ArchSigninTokenRequest.builder().stateToken(string2).nextURL(string).build();
        this.a(string2, string);
        return this.b.archSigninToken(archSigninTokenRequest).a((awnk)new awnk<esi<ArchSigninTokenResponse, ArchSigninTokenErrors>, awlz<esi<ArchSigninTokenResponse, ArchSigninTokenErrors>>>(){

            public awlz<esi<ArchSigninTokenResponse, ArchSigninTokenErrors>> a(esi<ArchSigninTokenResponse, ArchSigninTokenErrors> serverError) throws Exception {
                if (serverError.b() != null) {
                    return awlv.a((Throwable)serverError.b());
                }
                ArchSigninTokenErrors archSigninTokenErrors = (ArchSigninTokenErrors)serverError.c();
                if (archSigninTokenErrors != null) {
                    serverError = archSigninTokenErrors.serverError();
                    if (serverError != null) {
                        return awlv.a((Throwable)serverError);
                    }
                    return awlv.a((Throwable)new Throwable("Unknown error"));
                }
                return awlv.b(serverError);
            }
        }).e((awnk)new awnk<esi<ArchSigninTokenResponse, ArchSigninTokenErrors>, String>(){

            public String a(esi<ArchSigninTokenResponse, ArchSigninTokenErrors> object) throws Exception {
                if (object.a() != null && (object = ((ArchSigninTokenResponse)object.a()).redirectURL()) != null) {
                    return object;
                }
                return string;
            }
        });
    }

    public boolean b(String string) {
        try {
            boolean bl = new URL(string).getHost().contains("uber.com");
            return bl;
        }
        catch (Exception exception) {
            return false;
        }
    }

}

