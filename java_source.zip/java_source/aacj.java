/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awlv
 *  eqc
 *  eqr
 *  hhy
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

public class aacj {
    public static final Long a = 12;
    private static final List<HashSet<String>> c = Arrays.asList(new HashSet<String>(Arrays.asList("DFW", "DAL")), new HashSet<String>(Arrays.asList("IAH", "HOU")), new HashSet<String>(Arrays.asList("LGB", "LAX", "BUR")), new HashSet<String>(Arrays.asList("MIA", "FLL", "PBI")), new HashSet<String>(Arrays.asList("JFK", "LGA", "HPN", "EWR")), new HashSet<String>(Arrays.asList("CDG", "ORY")), new HashSet<String>(Arrays.asList("SFO", "OAK", "SJC")), new HashSet<String>(Arrays.asList("DCA", "IAD")));
    final eqc b;

    public aacj(eqc eqc2) {
        this.b = eqc2;
    }

    public void a(long l) {
        this.b.a((eqr)aack.e, l);
    }

    public void a(String string) {
        eqc eqc2 = this.b;
        aack aack2 = aack.d;
        String string2 = string;
        if (string == null) {
            string2 = "";
        }
        eqc2.a((eqr)aack2, string2);
    }

    public void a(String string, Long l) {
        this.b.a((eqr)aack.b, string);
        this.b.a((eqr)aack.c, l.longValue());
    }

    public void a(boolean bl) {
        this.b.a((eqr)aack.a, bl);
    }

    public boolean a() {
        return (Boolean)this.b.b((eqr)aack.a, false).b();
    }

    public String b() {
        return (String)((hhy)this.b.c((eqr)aack.b).b()).d();
    }

    public void b(long l) {
        this.b.a((eqr)aack.f, l);
    }

    public Long c() {
        return (Long)this.b.b((eqr)aack.c, 0).b();
    }

    public List<String> d() {
        ArrayList<String> arrayList = new ArrayList<String>();
        String[] arrstring = this.b.d((eqr)aack.d);
        if (arrstring != null && !arrstring.isEmpty()) {
            arrstring = arrstring.split(",");
            for (int i = 0; i < arrstring.length; ++i) {
                String string = arrstring[i].trim();
                if (string.isEmpty()) continue;
                arrayList.add(string);
            }
        }
        return arrayList;
    }

    public long e() {
        return (Long)this.b.b((eqr)aack.e, 1).b();
    }

    public awlv<Long> f() {
        return this.b.b((eqr)aack.f, a.longValue());
    }

    public List<HashSet<String>> g() {
        return c;
    }
}

