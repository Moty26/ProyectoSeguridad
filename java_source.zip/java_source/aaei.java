/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  awdr
 *  axss
 *  ewo
 */
public final class aaei<Presenter extends aaej, Router extends aaek>
implements awdr<aaeh<Presenter, Router>> {
    static final /* synthetic */ boolean a;
    private final axss<Presenter> b;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !aaei.class.desiredAssertionStatus();
        a = bl;
    }

    public static <Presenter extends aaej, Router extends aaek> void a(aaeh<Presenter, Router> aaeh2, axss<Presenter> axss2) {
        aaeh2.g = (aaej)((Object)axss2.get());
    }

    public void a(aaeh<Presenter, Router> aaeh2) {
        if (aaeh2 == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        ewo.a(aaeh2, this.b);
        aaeh2.g = (aaej)((Object)this.b.get());
    }
}

