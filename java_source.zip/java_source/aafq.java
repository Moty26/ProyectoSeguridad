/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  agq
 *  android.text.Html
 *  android.text.method.LinkMovementMethod
 *  android.text.method.MovementMethod
 *  android.view.View
 *  android.widget.ImageView
 *  aspo
 *  avyj
 *  com.uber.model.core.generated.crack.cobrandcard.LinkText
 *  com.uber.model.core.generated.crack.cobrandcard.OfferBenefit
 *  com.ubercab.presidio.cobrandcard.data.LinkTextUtils
 *  com.ubercab.ui.core.UImageView
 *  com.ubercab.ui.core.UTextView
 *  ejv
 *  ekh
 */
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.view.View;
import android.widget.ImageView;
import com.uber.model.core.generated.crack.cobrandcard.LinkText;
import com.uber.model.core.generated.crack.cobrandcard.OfferBenefit;
import com.ubercab.presidio.cobrandcard.data.LinkTextUtils;
import com.ubercab.ui.core.UImageView;
import com.ubercab.ui.core.UTextView;

public class aafq
extends agq {
    private UImageView n;
    private UTextView o;
    private UTextView p;
    private View q;
    private UTextView r;

    public aafq(View view) {
        super(view);
        this.n = (UImageView)avyj.a((View)view, (int)aafv.ub__cobrandcard_offer_benefit_item_image);
        this.q = avyj.a((View)view, (int)aafv.ub__cobrandcard_benefit_percent);
        this.r = (UTextView)avyj.a((View)view, (int)aafv.ub__cobrandcard_benefit_item_percent_amount);
        this.o = (UTextView)avyj.a((View)view, (int)aafv.ub__cobrandcard_benefit_item_title);
        this.p = (UTextView)avyj.a((View)view, (int)aafv.ub__cobrandcard_benefit_item_description);
        this.p.setMovementMethod(LinkMovementMethod.getInstance());
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(ejv ejv2, OfferBenefit offerBenefit, aako aako2) {
        this.o.setText((CharSequence)Html.fromHtml((String)offerBenefit.title()));
        this.p.setVisibility(8);
        if (!aspo.a((String)offerBenefit.description().template())) {
            this.p.setText((CharSequence)LinkTextUtils.a((LinkText)offerBenefit.description(), (aako)aako2));
            this.p.setVisibility(0);
        }
        this.q.setVisibility(8);
        this.n.setVisibility(8);
        if (!aspo.a((String)offerBenefit.rewardPercent())) {
            this.q.setVisibility(0);
            this.r.setText((CharSequence)offerBenefit.rewardPercent());
            return;
        } else {
            if (aspo.a((String)offerBenefit.imageUrl())) return;
            {
                this.n.setVisibility(0);
                ejv2.a(offerBenefit.imageUrl()).a((ImageView)this.n);
                return;
            }
        }
    }
}

