/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  android.support.v7.view.menu.ActionMenuItemView
 *  android.view.View
 */
import android.support.v7.view.menu.ActionMenuItemView;
import android.view.View;

public class aaj
extends aed {
    final /* synthetic */ ActionMenuItemView a;

    public aaj(ActionMenuItemView actionMenuItemView) {
        this.a = actionMenuItemView;
        super((View)actionMenuItemView);
    }

    @Override
    public abn a() {
        if (this.a.c != null) {
            return this.a.c.a();
        }
        return null;
    }

    @Override
    protected boolean b() {
        boolean bl;
        boolean bl2 = bl = false;
        if (this.a.b != null) {
            bl2 = bl;
            if (this.a.b.a(this.a.a)) {
                abn abn2 = this.a();
                bl2 = bl;
                if (abn2 != null) {
                    bl2 = bl;
                    if (abn2.f()) {
                        bl2 = true;
                    }
                }
            }
        }
        return bl2;
    }
}

