/*
 * Decompiled with CFR 0_119.
 * 
 * Could not load the following classes:
 *  com.ubercab.presidio.cobrandcard.CobrandCardOfferView
 */
import com.ubercab.presidio.cobrandcard.CobrandCardOfferView;

public interface aaew {
    public aaev a();

    public aaew a(aaey var1);

    public aaew a(aafc var1);

    public aaew a(CobrandCardOfferView var1);
}

